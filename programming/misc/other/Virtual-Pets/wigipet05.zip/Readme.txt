                   Wigipet v0.5 Beta
                  Nebsoft Software Inc
                      Jeff Hearn

Http://Nebsoft.base.org
NebsoftInc@aol.com

********************************************************

About:

The first virtual-pet PRODUCT!  Nurture your product to the final version while overcoming low morale, lack of money, and MEAN FOCUS TESTERS!  Easy interface, no-stress gameplay, and cool graphics!  The perfect game at only $5!!!

Beta Version.  Send comments and suggestions to NebsoftInc@aol.com.

Register now and get ALL future versions for FREE!

Jeff
:)

********************************************************

This is shareware!  If you do not register or remove this application from your system within 30 days, you will be subject to The Software Piracy Act of 1993.  All offenders will be prosicuted to the full extent of the law.

********************************************************

To register:

Send $5.00 US Dollars with a E-mail or return address inclosed in a envelope addressed to:

Nebsoft
c/o  Jeff Hearn
2302 McAuliffe Dr.
Rockville, MD 20851
USA

********************************************************

Legal Disclaimer:

I am in no way responsible for any harm or changes that come to your system.  All similarities to any other application are purely coincidental.

********************************************************

Trobleshooting:

Make sure that you have all of the image files.  If not, go to Http://Nebsoft.base.org

The only other possible reason for this program not working is  if you don't have the VB 5.0 Runtime Modules.  Download them here:

ftp://ftp.cdrom.com/pub/simtelnet/win95/dll/vb5_run.zip

********************************************************

Smiley:

:)