Pikachu for Neko

First of all this was not made by Pokemon. It was created by some one that is a fan of the game and show and wanted to have a neat virtual pet.

System Requirements:
Windows 95
The newest Neko version (Can be found at winfiles.com)

To use this go to the place you extracted Neko. There is a program called NekoCFG.exe. Run it. Change the character to Pikachu. Close NekoCFG.exe. Run the Neko program. There it is!

Pikachu made by Charlie Chai.