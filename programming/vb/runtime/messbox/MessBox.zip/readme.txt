MessageBoxControl.dll By slushie

README File --------------------

* NOTICE: This Archive may not be copied or distributed
without credit to programmer, Josh Leder. You may not
distribute this program if any of the files have altered
or changed in any way. Enough of that!

What this is:
 This is an OLE (pronounced Oh-Lay) automated DLL file. 
That means it will work with any development language 
that supports OLE automation, such as:

 .Office 97
 .VB4, 32 bit
 .VB5
 .Visual C++

 This DLL was created in Vb5 so i guess you should have
the VB5 runtime DLLs available. There are demos of use
for the dll included for both VB5 and VB4 32bit. If you
use Vb4 16-bit, well.. this wont work. I don't have VB4
16 bit so I can't compiled the needed OLE extensions, as
you can't make DLLs in 16bit VB4. So there, tough luck
kiddies. Besides, Vb5 is much more powerful than 4. :)

How to use this DLL:
 You may have used C or C++ DLLs before such as the
Windows API, the WinMM DLL for playing sounds, etc. Those
all work well for what they are made for. But in the
ever-extensive world of OLE, we have ways of making things
so much EASIER! :) To add this to your VB Project...
---
VB5:
Go to the Project menu and choose References... then click 
the Browse... button. Now choose the MessageBoxControl.DLL 
file. There you go! Click OK in the References window and 
the library will be refrenced to your project, and you can
begin using the MessBox class.

VB4:
Go to the Tools menu and click References... and then click
the Browse... Button. Find the MessageBoxControl.DLL file
and click Open. Now you should see the Message Box Control
DLL file By slushie checked, at the bottom of the list.
Good Job! Click OK in the References window and you have
just added a reference to the DLL into your project.
---
To see the newly added library, go to the View menu and 
choose Object Viewer. Now choose the MessageBoxControl
library from the first combo-box. You should see the class
named MessBox in the left-most list box. Click
on it to reveal all of the available properties in the 
MessBox class. Now you can close the Object viewer if you'd
like, but wasnt it fun seeing the DLL in your project? :)

Coding with the DLL:
 As with all OLE-based DLLs, the contained data is Object-Based,
as opposed to procedure-based. This is good, but it means 
dimensioning your object before it is used. To do this, you use
the Dim statement just as you would Dim any variable. This Dim
statement, however, looks slightly different. Heres and example:

Dim MessBoxObj As New MessBox

Simple! (You can replace MessBoxObj with any variable name you want)
This statement is used to give a memory address to the object 
and allow it to be used in your project. After this, you can use
it just as if it was a pre-programmed part of the Visual Basic 
language. Try it! After adding a Dim statement like the one above
to a command button, add the following code:

MessBoxObj.Title = "Testing!"
MessBoxObj.Message = "Testing!"
MessBoxObj.ShowBox

Of course, Replace MessBoxObj with the name of your object variable.
Run the program and click the Command Button. You should get a message
box with the title and message set to "Testing!". Its that simple. After
you've finished with the object, make sure to use the code

Set MessBoxObj = Nothing

before Dim-ing it again. See how easy that is? Need extra help? Email me
at slushiee@hotmail.com :) Have Fun! 

How to use the Demo Programs:
 The demo programs included with the library are useful for learning how 
to use objects in your programs, specifically Forms and of course, the
MessBox class. Need more help with Objects or DLLs? Check out 
msdn.microsoft.com for tutorials, help, or ANYTHING you could ever need to
know about Visual Basic. It is a VERY complete source :)

Finally, I'd liek to thank Josh for not helping me, and X who would have if
he was online! :) Goodnight everybody.


Contact Info:

slushie@hotmail.com
http://dominion.excaliber.net/~slushie (not even started making yet :)
