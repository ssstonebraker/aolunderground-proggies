 ****************************************************
*                                                    *
* exodus.ocx - fully functional aol active x control *
*            - version.one final build               *
*                                                    *
 ****************************************************
*                                                    *
* created by:    accel (cirax)                       *
* created on:    sept. 9th 2003                      *
* contact me:    tdc@raves.com                       *
* aol versions:  us/uk aol4.0 - 9.0                  *
* win versions:  win95 - win2000/winXP               *
*                                                    *
 ****************************************************
*                                                    *
* how to use:                                        *
*                                                    *
* 1. make sure you are on a windows environment      *
* 2. load up a compatible aol as stated above        *
* 3. right-click visual basic toolbar and add an     *
*    additional component.                           *
* 4. double-click to add it to the topmost form      *
* 5. call upon it using any of these functions       *
*    - note 'chat1' is the example name for it       *
*                                                    *
*   - chat1.Info   (this will show its info)         *
*   - chat1.Functions (this will show its functions) *
*   - chat1.ScanON (will enable the chatscan)        *
*   - chat1.ScanOFF (will disable the chatscan)      *
*   - chat1.AOLVersion (will get your aol version)   *
*   - chat1.AOLUser (will get your aol screenname)   *
*   - chat1.WINVersion (will get your windows ver)   *
*   - chat1.WINBuild (will get your windows build#)  *
*                                                    *
 ****************************************************