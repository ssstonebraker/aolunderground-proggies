Christian's Subclassing DLL
===========================

Hi there...

this is my first attempt at writing something "useful" in VB. I've been toying around a bit, but just had no real idea what to do.

I am programming in Centura Team Developer (CTD). In CTD it's very easy to subclass windows. Just define a constant in your code and that's pretty much it. Not so in VB. I read through a couple of paragraphs in books and some articles on MSDN. Then I came up with the idea for this little util.

It should be very easy to use:

1.) Copy the dll to your VB folder ( e.g. c:\Program Files\DevStudio\vb)
2.) Open DOS-Prompt. cd to your VB folder.
3.) Register the Dll in the registry (regsvr32 SubClDll.dll).
4.) Fire up the VB IDE.
5.) Begin a new standard EXE project.
6.) Add a reference to "Christian's Subclassing Dll" to your project.
7.) Dim WithEvents sc As SubClDll
8.) Set sc = New SubClDll

The following methods are available:
	
	AddMessage( uMsg as Long ) - Add a message to the list of messages you wish to interecept.
	RemoveMessage( uMsg as Long ) - Remove a message from the list.
	About() - Displays an About-Box

The following property is available:

	hWnd As Long - Set to the hWnd property of the window you wish to subclass. Set to 0 to stop subclassing.

The following Event is available:

	WndProc (hWnd As Long, uMsg As Long, wParam As Long, lParam As Long, Processed As CSSubDll.Processing) - When you're done with your code, you can set 'Processed' to either 'EatMsg' (0) to prevent the message to be processed by the standard window procedure. Or you may set it to 'ProcessMsg' (1) to have he message processed by the standard procedure.

For a sample see the enclosed sample.frm.

OK, that's about it. If you have questions, comments etc. feel free to drop me a note. My E-Mail address is: Schmitt.Christian@gmx.de



Disclaimer
==========
This program is freeware. You may use it at no cost whatsoever. But, I am not responsible for any damage the program may do to your computer, software and data. If, by any chance, this piece of software thrashes your system, you're on your own.
