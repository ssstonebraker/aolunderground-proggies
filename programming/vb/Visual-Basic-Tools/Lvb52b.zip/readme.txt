Learning Microsoft Visual Basic 5.0 Ver 2.0 Beta readme file

First of all we thank you for using our program. This version has only 3 lessons for you.
WARNING : You will see many differences between beta versions and full version!
WARNING : Do not make any copies of this program!
 
If you have any problems please e-mail me at jimmy84@otenet.gr or visit my homepage 
http://lvb5.cjb.net
VB40032.dll file is included in .zip file. 
NOTE : You have to copy the file vb4003.dll to your windows system directory in order to run Lvb5 Ver 2.0 
Beta. 

CopyRight 1998-99 
 