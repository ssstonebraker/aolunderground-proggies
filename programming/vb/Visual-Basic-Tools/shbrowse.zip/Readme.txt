
What is SHBrowse.dll?
-----------------------

SHBrowse.dll is a small dll that allows a VB5 program to easily use the Shell
Browse dialog that is available in Win95 / NT4.


How to use SHBrowse.dll?
-------------------------

Sample VB5 program demonstrates how to use the dll. Basically, you need to:

	* declare the function "GetFolder"

    * Allocate enough space in a string variable to receive the selected
      path that is returned from the Browse dialog.

    * Set the caption of the label that appears just above the tree control
      on the Browse dialog (optional).

    * Call the function GetFolder with the required parameters.

    * The selected folder path is returned in the "SelectedPath" parameter.

What does it cost?
--------------------

Nothing - it's free. If you feel really grateful, you may send me an e-mail
with any comments/requests.

---------------------------------
Warning - Use at your own risk!
---------------------------------

Although I know of no problems arising out of the use of this dll, I make
no claims of perfection either.

e-mail:  JimJanelle@bigfoot.com
website: www.bigfoot.com/~JimJanelle
