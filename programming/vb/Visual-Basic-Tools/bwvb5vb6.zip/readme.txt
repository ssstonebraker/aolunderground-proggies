BinaryWork VB5 to VB6 Converter 1.0.0

Application to convert VB5 compiled applications to VB6 application 
without recompiling it ( your application will use the msvbvm60.dll 
instead the msvbvm50.dll )

This application is the result of some tests inside exes, dlls, and 
ocxs compileds in VB5 , and I have tested it a lot before trying to 
send it over the internet , but you are welcome to test it also , send 
your comments to Maquisistem@geocities.com .

(This applications wasnot tested in Winnt)

This application have two parts :

First part : Verify if your file is a valid VB5 file 

Second part : This part show to you the original file and the modified 
file , the modified file its a copy of the original but with some 
modifications inside to make it run with the msvbvm60.dll 
(vb6 runtime ) , this file now dont require the original vb5 
runtime anymore , to make this file work you need the msvbvm60.dll 
in the same dir or in the system directory

Installation

To install the application , run the setup.exe file , and follow 
the instructions

If you arenot using Win98 , then maybe you need to install the 
latest vb5 runtimes with service pack 3 , if an error occur when 
you try to start the application , then you really need to 
install the VB5 runtimes .

To uninstall , search for it in the panel control , add remove 
programs , BinaryWork VB5 to VB6 Converter 1.0.0

Homepage : http://come.to/BinaryWork
email : maquisistem@geocities.com


This application is freeware

BinaryWork Corp. (the new name of Maquisistem Ltda)
