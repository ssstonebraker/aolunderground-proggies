VB Workshop - Freeware

This Helpfile contains a number of tips, tricks and samples for
VB 4,5 and 6 (mostly 32-bit).
Some examples are for advanced use only and requieres some
modification(s) to run properly.

No warranty of any kind is expressed or implied.
You use it at your own risk.
The author will not be liable for data loss, damages, 
loss of profits or any other kind of loss while using 
or misusing this software.

Most of the code samples come from public newsletters and from
several different internet sites.
See inside help file for more details.

All trademarks and copyrights belongs to their owners.

Get latest issue at
  http://user.tninet.se/~fgo483j/

or via mirror at
  http://home.bip.net/mjp/

// Joakim P. - Author