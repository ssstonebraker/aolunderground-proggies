BooWare Rapid Menu V1.0
Copyright(c) 1998 BooWare
All Rights Reserved.
V1.0 Released 30-July-1998
-----------------------

BooWare Rapid Menu is designed to make menu design alot easier than using the Visual Basic built in editor. It does this by visually showing the menu that you are creating. So you can now spend more time writing the code than trying to work out menu structures.

Contents
--------
- System Requirements
- Installation
- Distribution
- How To Use
- Contact Information
- Registering
- How To Order


=========================
** System Requirements **
=========================
Visual Basic 5


==================
** Installation **
==================
Run the Setup.exe file included in this zip file to install.

The line "BWRapidMenu.Connect=0" (without the quotes) should have been addes to your vbaddin.ini file, and the BWRapidMenu.DLL file copied into your system directory.

From the visual basic menu select Add-ins -> Add-in Manager..., Check the box next to the item "BooWare Rapid Menu", then click OK.
BooWare Rapid Menu can now be loaded by clicking on the Rapid Menu button on the toolbar.


==================
** Distribution **
==================
BooWare Rapid Menu shareware can be freely distributed to anyone as long as all files (including this read me) are included. If you want to include BooWare Rapid Menu on any CD-ROMs, Web-Site, FTP, etc, please e-mail me so that I am aware of its distribution locations.


================
** How to use **
================
Rapid Menu is very easy to use. The best way to learn to is to open a project that you have already created a menu structure for and experimenting.

The interface is setup similar to VB's Menu Editor but current menu is displayed on the left and the top shows the menu path to the current menu (Drill Menu).

Double clicking on a menu item in the current menu will take you into its sub-menu (if it has one) and the menu item you clicked will be added to the Drill Menu.

Clicking on an item in the Drill Menu will take you back up to that sub-menu.

On the current menu, clicking an item will select it. You can then change any of its properties.


=========================
** Contact Information **
=========================
E-Mail:		bruce@thevortex.com
WEB:		www.mpx.com.au/~bsmyth/

All constructive suggestions, comments or bug finds are welcome.


=================
** Registering **
=================
This program is shareware.
You may use this program for 30 days free as a trial. After that time you are expected to either register this program, or remove it from your computer.



What registering will get you:
- Removal of the Shareware reminder popups.
- Information on upgrades.
- Free updates
- You'll be supporting good software
- Provide feedback and incentives to make it an even better program.


==================
** How To Order **
==================


After sending the order form a Code will be sent to you that will unlock the full version of the BooWare Rapid Menu. The latest version is available from usrwww.mpx.com.au/~bsmyth

E-mail / Fax Order Form
==============================================================

One (1) copy of Rapid Menu

* = Required

*Name :     _________________________________________________________

Company :   _________________________________________________________

Country :            _______________________

*E-Mail Address :    _______________________



*Card Number :  __________________________  *Expiry Date : __________

*Name On Card : __________________________

*Card Type (choose one) :   [ ] VISA    [ ] MasterCard

*Date: _________________




E-Mail to: bruce@thevortex.com

Fax to :   Bruce Bowyer-Smyth.
           Within Australia: 02-6025-4009
           Other Countries:  OVERSEAS + 61-2-6025-4009

Price :    $15.00 (US)

==============================================================