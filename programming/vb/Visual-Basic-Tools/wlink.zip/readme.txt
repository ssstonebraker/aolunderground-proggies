Installation
------------
	Unzip all the file into a folder (eg C:\Folder ) and run the install.bat file. This will register the controls to the REGISTRY.

What is ActiveLink Wordlink Control ?
-------------------------------------
	ActiveLink Wordlink Control is an Active X Control that offer you to put a hyperlink on you application. It support any kind of URL (http://, ftp://...), also it support email when you put mailto:aaaaa@aaaaa.aaa ! 

What's new in Version 1.6 (27 Nov 98)
------------------------------------
 -Auto-resizing
 -Font,Bold,Italic,Underline,Strikrout is changable.
 -Improved Hover by let you choose hover or not
 -You can change the Color when the user mover the mouse on the link by a new properly - 	ColorOnMouseOver.
 -BackColor let Wordlink fit in anycolor of the form.
 -A new finger-shaped cursor like the one in Internet Explorer.

Registration
------------
	Both of the controls are not freeware! So please register if you want to use it. To register, just goto http://home.netteens.net/~chunting/reg.html and the page will let you go to the SSL server of RegNow! . Then after you made the payment, you can download it IMMEDIATELY.

Support
-------
	We support you to have the NEWEST version of ANY CONTROL YOU HAVE REGISTERED. When a new product is borned, we will send you AT ONCE.

Leo Chan
Chunting Software
---------
http://home.netteens.net/~chunting/
