BinaryWork Time Machine OCX 1.0

OCX to fix a international date bug inside VB , to 
set and get directly the date of the system , to 
solve part of the Y2K problem , and with a suite of 
date verifications and calculations that can vary of 
the year 1000 to the year 9999

We are studing and testing also a method to automatic 
replace VB code using the Date data type and the VB 
functions Dateadd and Datediff inside already 
developed source codes with the BinaryWork Time 
Machine OCX ( the name of the application will be 
BinaryWork Date Converter )

Please , watch our homepage about new software related 
to the Y2K bug


Installation

1 - extract the file "installation of the Time Machine OCX.zip"
to a empty directory , extract the content of this file to 
another directory , and execute the setup.exe file , this will 
install the shareware version of the ocx in your system

2 - after the installation of the ocx , extract the
"Time Machine Sample application.zip" to a empty directory
, inside this file you will find a vb5 sample project
exploring all the possibilities of the ocx

Uninstallation

1 - search for "BinaryWork Time Machine OCX" in the add/remove
 programs in the control panel , and select to uninstall it
 
2 - delete the folder with the sample project of the OCX

Overview

This ocx was developed to solve a bug referred to 
international date inside VB , with support to date 
calculations and date functions , and the ocx is Y2K 
bug free

Using this OCX you can forget about the Y2K problem

The method to retrieve the year , the month and the 
day is bug free

You can verify if a given year is a leap-year ( ano 
bissexto )

You can get and set any part of the date separately or 
in the BW Date format  (the BW date format is the date 
as a long in this manner  "yyyymmdd")

You can verify the number of days in a month in a especific 
year , between the year 1000 and the year 9999

You can easily make date calculations involving days 
months and years to the past and to the future ( what 
will be the date if I add 100000 days to the actual 
date ? ) , and some of this operations will retrieve an 
overflow error if you try to use the Dateadd and the 
Datediff functions of the VB , this will prove to you 
that the Date data type of VB is very weak

You can easily retrieve the difference between two 
dates in days , months and years ( what are the number 
of days between 01/01/1000  and 31/12/9999 ? ) and some 
of this operations will retrieve an overflow error if 
you try to use the Dateadd and the Datediff functions 
of the VB , this will prove to you that the Date data 
type of VB is very weak

A complete help file is installed with the ocx , to
 read it , select the ocx in the toolbox and click F1



Comments , problems , please send a email to :
Binarywork@geocities.com   

or visit the homepage at :
http://members.tripod.com/~Maquisistem/index.html

Thank you for trying our software

BinaryWork Corp.