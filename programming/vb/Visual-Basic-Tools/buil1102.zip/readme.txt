VB Builder Version 1.2 Copyright (c) 1998 GridLinx Software

1. Description
   Pinpoint errors in your VB programs to the exact line
   where they occur. VB Builder is a VB 5/6 Add-In 
   that creates line numbered versions of your VB
   program so that you can use the VB error line 
   function (erl) in your error handling code.
   VB Builder also compiles your programs and stores
   each line numbered version in a separate directory 
   based on the current version number of the program.

2. Program Requirements and Compatibility
   VB 5.0 Any Edition or Service Pack
   Windows 95/98 or NT 4.0
   1 MB Disk Space

3. Installation
   Extract the contents of this zip file in a separte
   directory. Make sure Visual Basic is not running.
   Run Setup.exe. VB DocuMentor will install all of
   its files in it own directory. It does not install
   or overwrite any VB specific files.

4. UnInstall
   Use the Control Panel Add-Remove Programs to
   remove VB Builder 

5. Operation
   Use the Menu Add-Ins - Add-In Manager to select
   Builder from the list of available Add-Ins. Then
   select Builder from the Add-In Menu. VB Builder will
   start. Use the Help file for program information.

6. Program Status
   This program is shareware. It may be freely distributed.

7. Evaluation Period
   This is a fully functional version of VB Builder 
   When you first start up VB Builder you will be asked to
   register as a evaluation user. If you are on-line, this information 
   will be sent the BrainTree registration server. You may then start 
   to use VB Builder.

   You will be able to use all functions. The evaluation preview
   period is limited to 30 days or 12 uses of the program.
   A use is defined as creating one line numbered version of
   a program. Use the Register-Status menu to the current status
   of your preview.

8. Purchase and Registration Information
   VB Builder is not free software. After the evaluation
   period, a registration fee of $26.00 is required. You may
   register on-line with your credit card by using the Brain Tree
   registration system. There is a $3.95 handling charge for
   registration for a total of $29.95

   Use the Register - Register Now menu to access the registration
   form. If you do not wish to register on-line or if you cannot
   access the registration server from your computer you may
   print out a registration form by selecting pay by mail or by fax.
   in the payment type and mail that with a check
   or credit card information to register.

9. Program Updates.
   You will be periodically asked if you want to check for new 
   versions. Or you may use the Register - Version Menu to 
   check if there are any later program versions available. 
   Or you may check directly at our web site using the
   Help - Go to GridLinx web page menu.

10. Technical Support or Questions
   Home Page: 	http://www.gridlinx.com
   e-mail:	support@gridlinx.com
   Address:	GridLinx Software
		3669 Purdue Ave.
		Los Angeles, CA 90066

11. Disclaimer of Warranty
   THIS SOFTWARE AND THE ACCOMPANYING FILES ARE SOLD "AS IS" AND WITHOUT WARRANTIES 
   AS TO PERFORMANCE OF MERCHANTABILITY OR ANY OTHER WARRANTIES WHETHER 
   EXPRESSED OR IMPLIED. ANY LIABILITY OF THE SELLER WILL BE LIMITED EXCLUSIVELY 
   TO PRODUCT REPLACEMENT OR REFUND OF PURCHASE PRICE.

12. Trademarks
   Visual Basic, Windows, Windows NT and Windows 95/98 are all registered trademarks
   of the Microsoft Corporation.

13. Known Problems
    1. Application Error in MPW32.DLL occurs occasionally when shutting down VB 
    2. Problems with source code control systems such as Visual Source Safe.
       VB Builder creates a new new project for each new version. The SCCS system
       may pop-up a dialog asking if the new project should be added to source
       code control. This may interfer with VB Builder. It is best to disable
       the SCCS while using VB Builder. Also, the orginal VBP file should not
       be read only if you want VB Builder to automatically increment the the
       version number.
    3. Auto Increment project revision fails under certain conditions. 

14. Installation Problems
   "Can not load Add-In" Message from VB when using Add-In manager. 

    This problem occurs when the Visual Studio Beta 6 Software is on
    your machine. It only occurs for the "exe" version of this add-in.

    You may obtain the "dll" version of the add-in and additional installation
    instructions by sending email to support@gridlinx.com.

15. Upgrading a registered version.
    Make sure you have a copy the registration codes. Use the Register | Registration
    Codes menu to display the registration codes form. Use the Backup button to 
    make a copy of the codes. 
 
    You may uninstall Version 1.1 before installing Version 1.2 or just install version
    1.2 over version 1.1. If you choose install Version 1.2 over Version 1.1 pay
    attention to the questions asked about overwriting your current files during
    the installation.

16. Version 1.1 Expired Previews
    If you installed Version 1.1 and used up your previews and want to try Version
    1.2 send email to preview@gridlinx.com for instructions on extending your 
    preview period.



        





    



