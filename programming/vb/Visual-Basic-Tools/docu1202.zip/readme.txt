VB DocuMentor Version 1.2 Copyright (c) 1998 GridLinx Software

1. Description
   VB DocuMentor is a VB 5.0 Add-In that allows you to 
   painlessly document your program as you code it. 
   It produces formatted descriptive procedure and 
   module headers and word wrapped comment blocks. It 
   also inserts error trapping code and tracks your 
   program's revision information.

2. Program Requirements and Compatibility
   VB 5.0 Any Edition or Service Pack
   Windows 95 or NT 4.0
   1 MB Disk Space

3. Installation
   Extract the contents of this zip file into a separate
   directory. Make sure Visual Basic is not running.
   Run Setup.exe. VB DocuMentor will install all of
   its files in it own directory. It does not install
   or overwrite any VB specific files.

4. UnInstall
   Use the Control Panel Add-Remove Programs to
   remove VB DocuMentor.

5. Operation
   Use the Add-Ins Menu - Add-In Manager to select 
   DocuMentor from the list of available Add-Ins. Then
   select DocuMentor from the Add-In Menu. VB DocuMentor
   will start. Use the Help file for program documentation.

6. Program Status
   This program is shareware. It may be freely distributed.

7. Evaluation Period
   This is a fully functional version of VB DocuMentor.
   When you first start up VB DocuMentor, you will be asked to
   register as a evaluation user. If you are on-line, this information 
   will be sent the BrainTree registration server. You may then start 
   to use VB DocuMentor.

   You will be able to use all functions. The evaluation preview
   period is limited to 30 days or 50 uses of the program.
   A use is defined as inserting one procedure, module, comment, 
   error trap or revision information. Use the Register-Status
   menu to show the current status of your preview.  

8. Purchase and Registration Information
   VB DocuMentor is not free software. After the evaluation
   period, a registration fee of $19.95 is required. You may
   register on-line with your credit card by using the Brain Tree
   registration system. There is a $3.95 handling charge for
   registration for a total of $23.90. 

   Use the Register - Register Now menu to access the registration
   form. If you do not wish to register on-line or if you cannot
   access the registration server from your computer you may
   print out a registration form by selecting pay by mail
   in the payment type and mail that with a check
   or credit card information to register.

9. Program Updates.
   You will be periodically asked if you want to check for new 
   versions. Or you may use the Register - Version Menu to 
   check if there are any later program versions available. 
   Or you may check directly at our web site using the
   Help - Go to GridLinx web page menu.

10. Technical Support or Questions
   Home Page: 	http://www.gridlinx.com
   e-mail:	support@gridlinx.com
   Address:	GridLinx Software
		3669 Purdue Ave.
		Los Angeles, CA 90066

11. Disclaimer of Warranty
   THIS SOFTWARE AND THE ACCOMPANYING FILES ARE SOLD "AS IS" AND WITHOUT WARRANTIES 
   AS TO PERFORMANCE OF MERCHANTABILITY OR ANY OTHER WARRANTIES WHETHER 
   EXPRESSED OR IMPLIED. ANY LIABILITY OF THE SELLER WILL BE LIMITED EXCLUSIVELY 
   TO PRODUCT REPLACEMENT OR REFUND OF PURCHASE PRICE.

12. Trademarks
   Visual Basic, Windows, Windows NT and Windows 95 are all registered trademarks
   of the Microsoft Corporation.

13. Known Problems
    1. Application Error in MPW32.DLL occurs occasionally when shutting down VB if
       on-line registration was not completed. 

14. Installation Start-Up Problems
   "Can not load Add-In" Message from VB when using Add-In manager. 

    This problem occurs when the Visual Studio Beta 6 Software is on
    your machine. It only occurs for the "exe" version of this add-in.

    You may obtain the "dll" version of the add-in and additional installation
    instructions by sending email to support@gridlinx.com.

        





    



