************************************************************************
********		ElfStrider Computer Solutions		********
********		      Grant Porteous			********
********		    strider@cloudnet.com		********
************************************************************************

------------------------------------------------------------------------
Converting a Number to Words - ConvertNum.dll Version 2.0
------------------------------------------------------------------------

Included in ConvertNum.zip

ReadMe.txt (This Document)
ConvertDemo.frm (Shows how to use the .dll)
ConvertNum.dll


It was written tested with VB5.0 SP3 (Not tested with anything else.)

------------------------------------------------------------------------
Changes Since Version 1.0 of ConvertNum.dll
------------------------------------------------------------------------

1. Fixed bug which incorrectly changed values above 99999
2. Added support for Upper Case, Lower Case and Title Case output
3. Now able to specify Currency, AND currency Unit


------------------------------------------------------------------------
Demo
------------------------------------------------------------------------
This .dll accepts a number and converts it to words.

Use the demo provided to see how it works:

Do the following (once you have unzipped the ConvertDemo.frm and the ConvertNum.dll)

1. Open the ConvertDemo.frm in VB

2. Set a refernce to the dll by clicking on Project|References and then on the "Browse" button to locate the dll.

3.Run the project (F5)

In the cmdConvert Click event you will see how to refernce the dll.

The following code references the dll

	Dim obj As New ConvertNum.NumtoText
	
The correct calling method is

	obj.fchange(m_Value, sCase, m_UseCurrency, m_CurrencyType, m_CurrencyUnit)

where:

m_value 	(required)
		Data Type : STRING
		is the number you want converted.  

sCase		(Optional)
		Data Type : STRING
		If omitted then "Title Case" is used.  If you want Upper case then send the string "upper", or if you want lower case then send the string "lower"

m_UseCurrency	(Optional)
		Data Type : Boolean (True/False); 
		It indicates if you want the words to reflect the currency used

m_CurrencyType 	(Optional)
		Data Type: STRING
		Indicates the type of currency eg dollar, yen etc.
		Default is "dollar"

m_CurrencyUnit	(optional)
		Data Type: STRING
		Indicates the currency unit like "cent"
		Default is "cent"
		
	
NOTE:	

1.	The maximum number the dll will convert is 922,337,203,685,476 (That is due to the limitation of VB's Currency data 	type)
2.	When NOT using the "Show Currency" option, upto FOUR decimal places will be converted to words.  PLEASE NOTE, if you 	use five or more decimal places the .dll WILL round up, if the 5th decimal place is above 5.
	For example, the number 

	100.15437
	
	is displayed as 
	
	One Hundred and One Thousand Five Hundred and Forty Four Ten Thousandths

3.	When using the "Show Currency" option, only TWO decimal places are converted, BUT there is NO rounding up if the 	third digit is above 5.

	For example, the number 

	100.15837
	
	is displayed as 
	
	One Hundred Dollars and Fifteen Cents

	

Hope it's useful!

You can use this dll free of charge, in any way or form you wish. however, please don't claim credit for it.

--End
************************************************************************
********		ElfStrider Computer Solutions		********
********		      Grant Porteous			********
********		    strider@cloudnet.com		********
************************************************************************


