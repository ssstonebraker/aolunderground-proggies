README.TXT

Global Key Generator for Visual Basic 5.
� Neil Pearson, 1998
neil@chilli.net.au

Legal crap:
The author disclaims any and all liability associated with the enclosed program code.  By using the program code and/or included binary, you agree not to hold the author responsible for any damage to hardware or software or any loss of money, or any other effects the code may have. As it is freeware, it can be freely distributed, altered or sold wherever and whenever you wish, but you must indicate the above disclaimer to your clients/customers.

And now that's out of the way (man I hate that stuff), lets see what we've just downloaded.

In GETSERIAL.TXT, there is a Visual Basic function for retrieving a serial number from a first name, a surname and a product ID.  All you need to do is paste the entire contents of GETSERIAL.TXT into the code section of the form you wish to use it from.  You can then use GetSerial() to return a serial number for any application.  The syntax is as follows:

     value = GetSerial(gs_firstname As String, gs_surname As String, gs_productid As Long) As Long

Product ID is a number between 1,000,000,000 and 2,147,483,648 (2 to the 31st).  This number should be unique to your program and is the key to having a unique serial number for your applications.

Here is an example.  Say the Product ID is 1234512345, and the program is being registered to John Smith, and we want to find SerialNumber.

     Dim SerialNumber as long  �MUST be a long, not and integer
     SerialNumber=getserial("John", "Smith", 1234512345)

SerialNumber is now equal to 228577930.  That is John Smith's serial number for Product ID 1234512345.

A typical way of registering users to, say, product ID 2020303040, is as follows:

     Three TextBoxes and a CommandButton on a form.

          TextBox:       txtFirstname
          TextBox:       txtSurname
          TextBox:       txtSerial
          CommandButton: cmdRegister

     Private Sub cmdRegister_Click()
     �put code for handling invalid entries here
     If txtSerial.text = GetSerial(txtFirstname.text, txtSurname.text, 2020303040) then
          �Code for correct serial number here
     Else
          �Code for incorrect serial number here
     End If
     End Sub

When someone registers one of your programs, you can use the included Key Generator to give them a serial number, or you can make your own using the GetSerial function. KEYGEN.EXE required VB5 runtime files.

I'm just a little programmer in a big world, and any comments/questions/feedback/donations are appreciated. My e-mail address is neil@chilli.net.au.