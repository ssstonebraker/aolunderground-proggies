Eckler CopyCom 1.1 Copyright (c) 1998 Eckler Software. 

CopyCom is a light weight COM-based DLL control that can copy the image of
another COM control to an image file (*.gif or *.bmp). With CopyCom you 
can create a copy of any COM control or ActiveX control that can be loaded 
in a container such as VB, Internet Explorer 4.0 and IIS Active Server Pages.

CopyCom can be used with ActiveX controls such as MSChart, Calendar, Label, 
TextBox and ListBox. Generally if you can load your ActiveX control into 
Internet Explorer 4.0 or higher it can be used with CopyCom.

This release includes the following files:

      ccom.dll           Eckler CopyCom Control
      readme.txt
      ccdemo.exe         CopyCom/MSChart VB5 demo
      ccdemo.frm         VB5 form
      ccdemo.frx
      ccdemo.vbp         VB5 project
      ccdemo.vbw
      combo.asp          Active Server Page file
      combo.ctl          VB5 user control
      combo.ctx
      combo.exp
      combo.lib
      combo.oca
      combo.ocx          Combo ActiveX Control
      combo.vbp          VB5 project
      combo.vbw
      ccwrap.exe         CopyCom Wrapper demo
      ccwrap.frm         VB5 form
      ccwrap.frx
      ccwrap.vbg         VB5 group
      ccwrap.vbp         VB5 project
      ccwrap.vbw
      wrapper.ctl        VB5 user control
      wrapper.ctx
      wrapper.exp
      wrapper.lib
      wrapper.oca
      wrapper.ocx        Wrapper ActiveX Control
      wrapper.vbp        VB5 project
      wrapper.vbw


There are three CopyCom demos included in this release. The ccdemo.* files 
contain VB5 source code for a simple CopyCom/MSChart demo. The ccwrap.*
and wrapper.* files contain VB5 source code for a multiple control wrapper
demo. The combo.* files contain VB5 source code for an ActiveX control 
used in the Active Server Page demo.

All demos assume you have already installed VB5 Professional or higher.
You must also register the ccom.dll. One way to register ccom.dll is to 
use the Components Dialog's Browse button in VB5. Another way is to use 
regsvr32.exe (version 4.00.1381 or newer).

When you run ccdemo and click the button it will copy the MSChart image to 
c:\copycom.gif and c:\copycom.bmp.

The ccwrap program will copy the image of multiple controls on the 
wrapper.ocx using a single CopyCom command. The output ccwrap.gif 
will be written to the same directory ccwrap.exe is executed from.

The ASP demo can be seen online from our web site. The ASP demo will show 
you how to embed MSChart images into your html page dynamically. The 
combo.ocx is used in this demo to create a wrapper for the CopyCom 
control and the MSChart control. 

Visit our web site for additional CopyCom documentation and order 
information. 

      David E. Suffield
      Eckler Software
      620 NE 101st Court
      Vancouver WA 98664

      dsuffiel@ecklersoft.com
      www.ecklersoft.com
      
The author of this program accepts no responsibility for damages 
resulting from the use of this product and makes no warranty or 
representation, either express or implied, including but not limited 
to, any implied warranty of merchantability or fitness for a particular 
purpose. This software is provided "AS IS", and you, its user, assume 
all risks when using it.

History:
1.0 Created new.

1.1 Removed LZW compression which is patented by Unisys. Added Run Length 
Encoding which still maintains compatibility with normal LZW-based GIF 
decoders.


