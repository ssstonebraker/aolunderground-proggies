
    RegEdit Light v.1.00.0026
    -------------------------
Copyright (c) Nicola Vigan� 1997
	<guru@ntt.it>

HISTORY
-------
24 June 1997 Fixed a bug writing Binary type values

ENGLISH
-------

1. IMPORTANT: If you need to replace an old version of RegEdit Light
   please unregister this old version before install the new one.
   To do this use RegSvr32.exe (you can download it from my Web site),
   opening a Dos window into the folder System and writing :
		
		   RegSvr32 /u RegEditL.ocx

   Then, if there is VB5 installed on your machine, you can follow 
   the instructions you can find into RegEdit Help.
   Otherwise you have to register the new version of RegEdit Light.
   To do this copy the new versione into the folder System and use
   this command line into the Dos window:

		   RegSvr32 RegEditL.ocx


2. RegEdit Light is not tested with Windows NT.

3. Please read the help document (RegEditL.hlp) carefully 
   before using RegEdit Light


PLEASE DON'T MODIFY THIS DOCUMENT


ITALIANO
--------

1. IMPORTANTE: Se devi sostituire una vecchia versione di RegEdit Light
   � necessario rimuovere quest'ultima prima di installare la nuova.
   Per far ci� usa il programma RegSvr32.exe (lo puoi trovare presso
   il mio sito Web), aprendo una finestra Dos nella cartella System e
   scrivendo :

		   RegSvr32 /u RegEditL.ocx

   A questi punto, se sulla tua macchina hai VB5, puoi seguire le
   istruzioni presenti nell' Help di RegEdit Light
   In caso contrario � necessario registrare la nuova versione di
   RegEdit Light, dopo averla copiata nella cartella System, con
   RegSvr32.exe, scrivendo nella finestra Dos:
		
		   RegSvr32 RegEditL.ocx

1. RegEdit Light non � stato testato con Windows NT.
   
2. Leggi attentamente l'help (RegEditL.hlp) prima di 
   utilizzare RegEdit Light
   
NON MODIFICARE QUESTO DOCUMENTO GRAZIE
