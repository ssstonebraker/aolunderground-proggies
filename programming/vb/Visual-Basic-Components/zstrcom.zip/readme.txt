Maquisistem Zlib StringCompress OCX 1.5

OCX to make in memory compression 

This ocx can compress or uncompress strings or files using 
the Zlib scheme

You can compress strings or files using this OCX

What is new : This new version is at leat 5 times 
faster than the version 1.3 , and now the file is 
generated in the Gzip format , and can be decompressed by winzip

The zlib scheme is based in the Zip compression , and this can 
compress strings or files with the same compression ratio of Zip

The algorithm used inside the Zlib compression is freeware , then 
you can use and distribute your software without copyrights problems

If you need more explanation , then read the ZLIBSTRING.HLP

email : maquisistem@geocities.com
homepage : http://members.tripod.com/~Maquisistem/index.html