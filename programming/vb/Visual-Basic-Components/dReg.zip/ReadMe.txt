DOGNet - dRegistry v1.0 for Visual Basic 5.0
============================================

Installation:
	1. Copy dReg.ocx into C:\Windows\System directory
	2. Run "RegSvr32 dReg.ocx"
	
KeyRoot Const:
  	HKEY_CLASSES_ROOT = &H80000000
  	HKEY_CURRENT_USER = &H80000001
  	HKEY_LOCAL_MACHINE = &H80000002
  	HKEY_USERS = &H80000003
  	HKEY_PERFORMANCE_DATA = &H80000004

Procedure:
	1. Sub SaveKey(hkey As Long, strpath As String)
	Usage: Call dReg1.SaveKey(HKEY_CURRENT_USER,"Software\DOGNet")
	Make a Key for "My Computer\HKEY_CURRENT_USER\Software\DOGNet"

	2. Sub SaveString(hkey As Long, strpath As String, strvalue As String, strdata As String)
	Usage: Call dReg1.SaveString(HKEY_CURRENT_USER,"Software\DOGNet","Data","Test")
	Put "Test" into section Data in "My Computer\HKEY_CURRENT_USER\Software\DOGNet"

	3. Function GetString(hkey As Long, strpath As String, strvalue As String)
	Usage: A$=dReg1.GetString(HKEY_CURRENT_USER,"Software\DOGNet","Data")
	You will get A$="Test"

Bugs Report:
	I can't make sure the ocx must run without any bugs. Please tell me if you find out any.
	It is a FREE ocx. You are no need to paid but please send a e-mail to tell me if you
	like it or use it. Thanks.


Roger Chiu
dog@dognet.org.hk
http://www.glink.net.hk/~dog
31 March, 1998.
