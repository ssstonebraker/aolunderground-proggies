The WebKeyboard ver. 1.0, for Window 95/98/NT
=============================================

This ActiveX control will help you replace,
in a public show display, a standard keyboard
by a mouse or a track ball as an input device.

==============================================

The Webkbrd.ZIP file contain:

1)  this file
2)  webkbrd.CAB (for internet installation)
3)  ocx.html (ex. for registration in your OS)
4)  Support folder containing: (for installation)
       webkbrd.DDF
       webkbrd.INF
       webkbrd.ocx
5)  webkeyboard.lpk (licence pack)
6)  clavier.exe (executable file)

Note:  You may need the VB5 runtime file, available at:

ftp://ftp.microsoft.com/Softlib/MSLFILES/MSVBVM50.EXE

===============================================

THIS ActiveX CONTROL IS NOT FREE (only $10.US by licence)
Use as a 15 days trial offer.

However, there is no charge if you do not use it as part
of your executables or on in your Web page code.

For more informations, contact:

Our Web site:    http://www.clic.net/~programa

or Email:        programa@clic.net
