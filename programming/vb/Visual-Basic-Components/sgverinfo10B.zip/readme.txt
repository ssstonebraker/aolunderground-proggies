SG VersionInfo Version 1.0
Copyright (C) 1998 Stinga
All Rights Reserved
September 20, 1998


Thank you for your interest in SG VersionInfo.
This demo version does not contain any limitations except that 
it will occasionally display registration remainder screen.

Latest version is available at
http://www.stinga.com/sgVersionInfo


===========
Description
===========

 The SG VersionInfo is an ActiveX component that can be used to
 access version information stored in the files that contain 
 Windows resources, such as a dynamic-link libraries (DLL), 
 executable files (EXE), or a font files. This information 
 can be used to perform various administrative tasks or 
 build installation scripts.


===================
System Requirements
===================

 Windows 95, Windows 98 or Windows NT 4.0.
 No external DLLs.
 

============
Installation
============

 To install SG VersionInfo, extract archive to some temporary directory 
 and run SETUP.EXE.


============
Registration
============

 SG VersionInfo is shareware. You can register SG VersionInfo for $14.
 SG VersionInfo can be ordered by secure online form, toll free phone or 
 by postal mail. Secure online registration is available at
   http://www.stinga.com/order.asp.
 For phone, postal mail or fax orders, please consult SG VersionInfo
 help file.


=====================
End User Distribution
=====================

 SG VersionInfo is royalty free. Registered users can distribute DLL.
 Source code can not be distributed. For more info, please consult 
 LICENSE.TXT file.


====================
Package Distribution
====================

 Package (SGVERINF.ZIP) containing this README.TXT file and 
 SG VersionInfo setup program is freely distributable.


============
Contact Info
============

 Stinga, Nova Cesta 151, 10000 Zagreb, Croatia
 Web:    http://www.stinga.com/sgVersionInfo
 E-mail: sgversioninfo@stinga.com
         support@stinga.com




