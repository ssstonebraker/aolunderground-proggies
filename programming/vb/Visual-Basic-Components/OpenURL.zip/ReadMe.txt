_____________________________________________________________________________________

OpenURL version 1.0 (Released on November 1st 1998)
Copyright (c) 1998, Ohad Maishar.

E-mail  : maishar@geocities.com
_____________________________________________________________________________________

*** Description ***

     OpenURL is an ActiveX control (or an OCX). It lets you open web pages through 
  your default browser from every development system (whether it's Visual C++, Visual
  Basic, or any other development system which supports ActiveX controls), without the
  need of writing tons of code.

  Note: 
  -----
     I've made this control with VisualBasic 6.0, therefore I don't think it would
     work with any older development system (but it surely works with all of the
     Microsoft VisualStudio products).

*** Usage ***

     Insert the control into your project (as you do with all kind of controls), then
  write the following code:
		OpenURL.BrowseTo Me.hWnd "http://yourwebaddress"

  Note:
  -----
     -Don't forget to include the "Me.hWnd" parameter.
     -You can write an e-mail address instead of a webpage address, for example:
		OpenURL.BrowseTo Me.hWnd "mailto:your@email.com"
      In this case, don't forget to write the "mailto:"

*** Shareware ***

     OpenURL is a shareware. For information about registering send me an e-mail.

*** Installing ***

     The installation is very simple. Copy all the files to the system folder -
  C:\Windows\System, then register the control by typing "REGSVR32.EXE OpenURL.OCX" at
  the command prompt (DOS Shell). That's it.

*** Uninstalling ***

     The uninstallation process is almost exactly like installation process.
  Go to the system folder - C:\Windows\System, then Unregister the control by typing
  "REGSVR32 /U OpenURL.OCX" at the command prompt (DOS Shell). Now you can delete all
  OpenURL files.
_____________________________________________________________________________________
  
Copyright (c), 1998. Ohad Maishar.
All rights reserved.