 --------------------------------------------------------
 Module    : IniModule(Init.bas)
 Written by: Elito C. Lelina III
             ECLIPSE Development Software
 URL       : www.geocities.com/SiliconValley/Campus/3118/
 email     : eclipseds@hotmail.com
 --------------------------------------------------------

 This module contains functions for reading and
 setting Key values from an initialization file.
 These functions are provided for compatibility
 with 16-bit applications written for Windows.
 Win32-based applications should store initialization
 information in the registry.

 This program makes no guarantees and no support is provided,
 but comments/bug reports are welcome.

 Warning:  Windows depends heavily on initialization file.
 Create initialization file Backup before editing.
 You should only edit values when you know what
 they should be.  If editing values as a test, make a note
 of the original value and restore it when you are done.

 The module contains all the neccesary code to access an
 initialization file. The project file is provided to demostrate
 the functionality of the module.

 Note. You may freely use this on your project provided that
 you free the author from any liabilities. Although it is unlikely
 that the project will cause any harm, by using the provided code,
 you accept all responsibilities and any consequential damage that
 the project may incure.

 Features:
	* Querying an integer value from Win.Ini or user provided file
	* Querying an entire section from Win.Ini or user provided file
	* Querying a single key from Win.Ini or user provided file
	* Writing an entire section from Win.Ini or user provided file
	* Writing a single key from Win.Ini or user provided file

----------------------------------------------------------------------
 � Share your knowledge. It's the best way to achieve immortality. -ECLIPSE 3:16 �
----------------------------------------------------------------------