Light in the Attic
VB CGI Module v1.12
Copyright (C) 1998-99 Aran Meuser
All Rights Reserved
aran@northcoast.com
http://www.northcoast.com/~aran/software/vbcgi.html
End-User License Agreement in license.txt

This module adds the ability to access CGI and Cookies with Visual Basic.  It is 
free to use non-commercially and commercially without any strings attached.  It 
has been tested with Visual Basic 6, and will most likely work with 4 and 5.  The 
current version is 1.12, released January 27th, 1999.

FEATURES
------------------------------------------------------------------------------------
  * Reads both the GET and POST CGI methods.
  * Automatically parses form and cookie input.
  * Supports all facets of the Netscape HTTP Cookie specification.
  * Works with any Web Server that supports CGI.
  * Faster than using scripting languages like Perl.
  * Can send redirects, no content, and binary data.
  * and its free.

Fixes in Version 1.12
------------------------------------------------------------------------------------
  * There were some reported problems with the CGISend statements that have 
    now been fixed.
  * Setting CGI_WriteLog to True and then running CGIInit() would bomb the CGI 
    application.  This has been fixed.
  * Also minorly improved the sample code that is included to have some nice 
    error handling and more.

New in Version 1.1
------------------------------------------------------------------------------------
  * Optional log output for easy debugging.
  * Comes with a Visual Basic 6 project with default "Hello World!" code.
  * Cookie and Form objects renamed CGI_Cookies and CGI_Inputs, respectively.
  * StringPairs object enhanced, now called SimpleArray.
  * SimpleArray object has Sort, Search, and ParseTHTML functions.

Methods
------------------------------------------------------------------------------------
  CGIInit Statement
    Initializes Std in and out pipes, reads environment variables, reads form input, 
    and reads cookie input. Must be called before any other function.
  Syntax:
    CGIInit()

  CGISendBinary Statement
    Sends binary data out via STD Out with appropriate HTTP headers.<BR>
  Syntax:
    CGISendBinary(ByteArray as Variant, ContentType as String)<BR>
  Arguments:
    ByteArray    An Array of bytes.
    ContentType  This can be image/gif, image/jpeg, etc. binary data types.

  CGISendNoContent Statement
    Sends a no content HTTP header.<BR>
  Syntax:
    CGISendNoContent()

  CGISendRedirect Statement
    Sends a redirect HTTP header.  Makes the user's browser load the file specified 
    in 'Location'.
  Syntax:
    CGISendRedirect(Location as String)
  Arguments:
    Location     Location to redirect the browser to.  Usually an HTML document.

  CGISendText Statement
    Sends the specified text and, if specified, cookies to the user's browser.
  Syntax:
    CGISendText(OutString as String, [WriteCookie as Boolean], 
    [CookieDate as Date], [CookieDomain as String], [ContentType as String])
  Arguments:
    OutString    String to send.
    WriteCookie  Optional. Whether or not to send cookie values. Defaults to False.
    CookieDate   Optional. Expiration date of the cookie.  When set to a date before 
                 the current date the cookie is deleted from the users browser.  
                 Defaults to 1/1/1980.
    CookieDomain Optional. Domain of the web page, like 'www.w3.org'. Defaults to 
                 127.0.0.1.
    ContentType  Optional. Text type to send such as text/html and text/vrml.  
                 Defaults to text/html.

Properties
------------------------------------------------------------------------------------
  CGI_WriteLog Property
    If enabled a text log will be written file for debugging 
    purposes to App.Path\App.EXEName.log.  You should set this 
    variable before calling CGIInit().
  Syntax:
    CGI_WriteLog = value
  Arguments:
    value        A boolean expression that determines whether a log file is 
                 written to.  If TRUE, a log file is created and written to; 
                 if FALSE, it is not.  The default value is FALSE.
