Info
----
Title    : Menu Organizer
Filename : MenuOrganizer.vbs
Version  : 1.1
Date     : 7/19/98
Author   : Ashley Hatch
Email    : hatch@nevada.edu

Disclaimer
---------
   First off I see absolutely no way that this script can damage your registry,
your computer, your files, your ability to have children, or your financial 
stability. However, in using this utility you are accepting the condition that 
I cannot be held responsible for any problems that may arise from its use other 
than your menu has suddenly been alphabetized against your will. That being said
on to the good stuff.

Intro
-----
   This short VBScript will allow you to reset the ordering of your Start Menu
and/or your IE4 Favorites Menu. It removes registry entries which hold the 
ordering information for these two sets of menus.


Installation Instructions
-------------------------
   First and foremost you must have Windows 98. I have not tested this on 
Windows 95 with IE4, and as such do not yet know if this will work on it.

   Extract MenuOrganizer.vbs to C:\Windows or if you are an advanced user place
it anywhere you wish. Then make a shortcut to it and add it to your Start Menu.
I would recommend you put it in Accesories\System tools and call it Menu Organizer.

   You also need to make sure you have the Windows Scripting host installed. Many 
systems will, but to check go to Control Panels -> Add/Remove Programs -> 
Accessories and make sure the Windows Scripting host is installed. If not then
check it, and it will be installed automatically.

   Now you should be ready to run this utility at will.

Using MenuOrganizer
-------------------
   Tip, only run this utility if the menu is out of order currently, or the script
may fail to run.

   To run the utility simply click the shortcut you made or double click the file
itself. This will load MenuOrganizer into the windows scripting host.

   A dialog box will appear introducing you to Menu Organizer. Simply click Ok to 
continue.

   The Start Menu Organizer will start. Clicking Yes here will reset all of 
your Start Menu and the Favorites on your Start Menu to alphabetical order. Clicking 
no will advance you to the IE4 Favorites Menu Organizer.

   The IE4 Favorites Menu Organizer will now start. Clicking Yes here will reset 
all of your IE4 Favorites Menu icons to alphabetical order. Clicking no will advance 
you to the final screen.

   The closing screen will come up and you can simply click ok to clear it.
   
   You now need to reboot the computer or use one of the following suggestions to 
do it more quickly

Refreshing the registry quickly
-------------------------------
1) Click Start -> Shut Down and select restart. When you click yes hold down Shift
and your system will do a warm boot which is a bit quicker than a full boot. This 
version is my recommended version simply because it is safest.

2) If you have a network installed you can click Start -> Shutdown and select Close 
all programs and log on as a new user. This is safe and very quick in general.

3) Close all programs and hit Ctrl-Alt-Del. When the Close Program screen comes up
click Explorer and click End Task. When the Shut Down Windows screen comes up click
Cancel. Then when the prompted click End Task. This is the fastest and is usually ok
but can sometimes cause problems till you reboot.

Known Problems
--------------
   The only problems I know of currently are that if the script is run twice without
refreshing the registry the script will fail to find the registry entries it is
trying to delete and will, as a result of this, fail to execute and if the menu has 
never been disordered it may result in a similar failure. Lesson: Don't run this 
utility twice without rebooting or somehow refreshing the registry.

Contacting the Author
---------------------
   If you would like to contact me for suggestions or question feel free to do so. 
If you are interested in giving me lots of money, love, and/or adoration these things
are welcome as well.

Here are my main contacts:
E-mail: hatch@nevada.edu
ICQ: 2137237

Thanks and Recognition
----------------------
   Thanks go out to the Screen Savers, Leo Laporte and Kate Botello, for letting me
ask this very question on their show and finally letting me solve it on their show
as well.
