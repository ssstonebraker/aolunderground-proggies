
XShortcut.ocx

	*********************************************************
	*							*
	*	Please take the time to send me your comments	*
	*	via the e-mail link on the About Screen.	*
	*	Your feedback can help to create bug free	*
	*	controls.  It makes me feel useful to!		*
	*							*
	*********************************************************



PROPERTIES:

   Location----

	There are 3 choices: 	DESKTOP(default)
				START_MENU
				STARTUP

	DEKSTOP puts an shortcut or .lnk file on the desktop
	START_MENU put a shortcut or .lnk file in the Programs area 
		of the start menu
	STARTUP puts a shortcut or .lnk file in the startup folder
		of the start menu to load at startup

   Path----

	Path refers to the path of the object that you want to 
		create a shortcut to
	
	*NOTE:  if you do not specify a path you will end up with a 
		shortcut to "MY COMPUTER"

   Title----

	Title is the name which you wish to give your shortcut. 
		there is a default value of "Shortcut to"


               *************NEW******************

   Arguments---- 

	Arguments allows the use of command line arguments  
		
		for example:  defrag.exe c:
		
		where c: is an argument for defrag.exe


Methods:

   .Create_Shortcut----

	Creates a shortcut using the above property information


               *************NEW******************
   .Kill_Shortcut

	Deletes a shortcut created with .Create_Shortcut



Example--------------------------------------------------------------

Private Sub Command1_Click()

	With XShortcut1
		.Location = 0
		.Path = "c:\windows\Defrag.exe"
		.Title = "Shortcut to Defrag"
		.Arguments = "d:"
	End With

	XShortcut1.Create_Shortcut


End Sub


Questions or comments to:
Bruce Flynn
xabner@mailbag.com
Or use e-mail link on about screen

