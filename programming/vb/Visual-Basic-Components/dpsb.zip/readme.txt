This readme file is provided in two formats, therefore you only need to read one. I like reading NotePad files but not printing them, so therefore, I have provided a Word 6.0 format if you so choose.

  I came up with the percent search out of frustration. I had many users for a particular project that had to do a tremendous amount of searching. If they misspelled what they were searching for, it would return nothing. I was asked to come in and remedy the situation that the last programmer has left. I created this code and added it to the already done project and everything has worked great ever since. I have always watched for other programs to pop up with something similar and have yet to see it. Therefore, I have decided to unleash this code upon the world. Essentially, I have compiled a demo program. The program is written in Visual Basic 5.0 with Service Pack 3. You will need the VB5 run-time files if you downloaded the base install. If you have VB 5 on your system (which I'm assuming is why you downloaded this program) you will be fine. I am using DAO (and therefore the Jet Engine) to access the Access 97 database in this example. If you have any problems, you may want to download the full version. It can be found at:

http://www.controlsolutionsltd.com/downloads/dpsf.zip

Feel free to modify the data in the database, though changing names of fields or tables or the database will cause the demo not to function. You can add as many items to the field I have provided as you like. I provided a few company names to search through. I would recommend opening the database to view the possible values you could return from your search or set the return percent of the demo to 1% and type the letter "c" into the search text box and leave case sensitive to no. This will return all of the records on the database, as they all begin with "c". 

I have provided this program as a demonstration of how the code works. It is provided as freeware and may be fully distributed so long as it is not altered in anyway. There is no warranty provided with this program whether expressed or implied. I will not be resposible for any damaged caused by any use or misuse of this program. 

This program is provided as a demonstration of the source code behind it. It is generally intended for someone not thouroughly experienced with Visual Basic or who doesn't want to spend the time to figure it out for such a cheap price.  The source code will work in Visual Basic 5.0 and 6.0. I assume you have general knowledge of accessing Access databases with DAO. I have thouroughly commented the code to help understand every portion so it may help some who are not overly familiar with accessing an Access database with DAO. It is not intended as a database tutorial, only as a useful reusable module for when your search needs require some slack. 

You can purchase the source code for the program by sending a check or money order in US funds for $5 to:

Marc Mitchell
P.O. Box 541405
Grand Prairie, TX 75054-1405

There are two options for receipt of product. I can email the source code (completely commented) to you if you provide me an email address with your payment. I will (for $1 extra) mail you a floppy disk with the source code if you would like to provide an address with your payment. If you would like to send $10 out of the kindness of your heart to help a starving programmer, I would probably have to except. However, if you do choose this amount, I will also leave in the reusable code for the following:
	
	A reusable routine for limiting the values that can be typed into a textbox to numbers only. This routine has optional arguments for providing a minimum and maximum value for each text box through the same routine. It really saves money and resources on an expensive third-party control to do the same.

	Also, is a much simpler routine for "highlighting" or selecting all of the text in a textbox when it receives the focus. 

I will make every attempt to get the product on its way to you ASAP. Essentially, if you send me a money order and an email address, you will have the product, the same day I receive the money order.

The license agreement for the source code is simple. You are free to use it in whatever capacity you desire for your products and projects provided the only form of distribution is compiled. You may not distribute the source code in it's original form for any reason to any person or machine other than your own.

If there are any problems, questions or suggestions, please feel free to email me at:

marcm@controlsolutionsltd.com

Thank you for downloading the demo.