SWBMenuBtn Control Setup
========================

Before you begin, please copy the SWBMenuBtn.OCX
file to your \Windows\System directory (which
may not necessarily be named \Windows\System).

Then register the component using REGSVR32.EXE,
as follows:   

In the Start Menu, select "Run".  Then type:

    REGSVR32 \Windows\System\SWBMenuBtn.OCX

A message box will confirm the registration.
Before you can use the component in a project,
you will need to add it to the VB toolbox by 
right-clicking on the toolbox and selecting 
"Components".  From the list of registered
components, select "SWB Menu Button".

The component will appear on the toolbar, 
ready for use in your application.

Copyright 1998  Software with Brains, Inc.
All rights reserved.

sales@softwarewithbrains.com
http://www.softwarewithbrains.com