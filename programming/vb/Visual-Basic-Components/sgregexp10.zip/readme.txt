SG RegExp 1.0
Copyright (C) 1998 Stinga
All Rights Reserved
August 10, 1998


Thank you for your interest in SG RegExp.
The SG RegExp is regular expression pattern search ActiveX object for 
use in VBScript� scripts. You feed SG RegExp with a pattern and string, 
and SG RegExp returns collection of matched Substring objects.

Latest version is available at
www.stinga.com/sgRegExp/sgRegExp.htm


** System requirements **

 Windows 95 or Windows NT 4.0.
 Windows 98 and Windows 5.0 testing is in progress.
 WSH and VBScript
 No external DLLs.


** Distribution **

 SG RegExp and accompanying source code are free and you can use
 them in any project: commercial or public domain. There is one
 thing you should be aware of: if you change source code, you must
 use different GUIDs and PROG IDs.


** Contact Info **

 Stinga, Branimirova 97, 10000 Zagreb, Croatia
 Web:    http://www.stinga.com/sgRegExp/sgRegExp.htm
 E-mail: sgregexp@stinga.com




