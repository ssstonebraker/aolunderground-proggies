-[bOF]-
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
Name: SV_SoundX 
Desc: Wav, Midi & MOD playing OCX for Visual Basic 5+
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
IMPORTANT!: When distrubting this OCX, do NOT forget
to include the npmod32.dll with the OCX. IT will NOT
work if the DLL is not installed.
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
Usage:
	This control is simple to use...
Open up VB, Open a Standard EXE, then from the
Project menu, select Components, from this menu
select the SV_SoundX.OCX file. It should now appear
on your toolbar. Double-click on it to add it to 
the form. You should now see a little icon on the
form. That is it. Now all of the rest is done by 
code.
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
Note: From this point on "SV_SoundX" refers to 
	whatever you name the control once it's 
	on your form. 
((i.e.: if you name the control "MySound" then you would
	type MySound.PlaySound to play a Wav.))
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
Properties:
---
SV_SoundX.FileNameWav
	This is a string that points to the name and
	location of a wav file to be played.

ex:
	SV_SoundX.FileNameWav = "c:\windows\desktop\bark.wav"
---
SV_SoundX.FileNameMid
	This is a string that points to the name and
	location of a Midi file to be played.

ex:
	SV_SoundX.FileNameMid = "c:\windows\desktop\song.mid"
---
SV_SoundX.FileNameMod
	This is a string that points to the name and 
	location of a Mod file to be played.

ex:
	SV_SoundX.FileNameMod = "c:\windows\desktop\techno.mod"
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
Methods:
---
SV_SoundX.PlaySound
	This plays the wav specified with SV_SoundX.FileNameWav
---
SV_SoundX.LoopSound
	This Loops (plays endlessly) the wav specified with 
	SV_SoundX.FileNameWav
---
SV_SoundX.StopSound
	This brings the currently playing sound to a stop.
---
SV_SoundX.PlayMidi
	This plays the Midi specified with SV_SoundX.FileNameMid
---
SV_SoundX.StopMidi
	This brings the currently playing midi to a stop.
---
SV_SoundX.PlayMod
	This plays the Mod file specified with SV_SoundX.FileNameMod
---
SV_SoundX.StopMod
	This brings the currently playing Mod to a stop.
---
SV_SoundX.ModVolume(iVol as Integer)
	This allows the volume of the mod to be changed.
	The valid volume is from 0 to 100.
---
SV_SoundX.AboutSoundX
	This displays a message about the developer of this OCX.
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
Events:
---
PlayingSound
	This is triggered by using SV_SoundX.PlaySound
---
StoppingSound
	This is triggered by using SV_SoundX.StopSound
---
LoopingSound
	This is triggered by using SV_SoundX.LoopSound
---
PlayingMidi
	This is triggered by using SV_SoundX.PlayMidi
---
StoppingMidi
	This is triggered by using SV_SoundX.StopMidi
---
PlayingMod
	This is triggered by using SV_SoundX.PlayMod
---
StoppingMod
	This is triggered by using SV_SoundX.StopMod
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
That's all there is to it. If you have any problems, 
please be sure to let me know.
skid@angelic.com : skid@radiks.net
http://start.at/skid/
http://www.radiks.net/skid/
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
SV_SoundX.OCX (c)1998 TSI : Visage : Skid Vis
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
-[eOF]-
