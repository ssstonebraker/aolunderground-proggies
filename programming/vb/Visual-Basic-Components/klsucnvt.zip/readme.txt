UNIT CONVERTER DLL

Thank you for showing interest in the Unit Conversion DLL.  This ActiveX Code 
Component provides a simple set of functions for converting between different 
types of units in several different categories.

The Categories and units currently handled (as of 11/1/97) are:
  Length - kilometers (KM)
	 - nautical miles (NM)
	 - feet (FT)
	 - kilofeet (KF)
	 - hectometers (HM)
	 - yards (YD)
	 - meters (M)
	 - statute miles (SM)
	 - inches (IN)
	 - centimeters (CM)

  Temperature - Fahrenheit (F) 
	      - Celsius (C)
	      - Kelvin (K)

  Speed - meters per second (MPS)
	- kilometers per hour (KPH)
	- knots (KTS)
	- miles per hour (MPH)

  Time - day (DAY)
       - hour (HR)
       - minutes (MIN)
       - seconds (SEC)
       - week (WK)
       - month (MON)

  Angle - radian (RAD)
	- degree (DEG)
	- mils (MIL)

  Mass - kilogram (KG)
       - pound (LB)
       - ton (TON)
       - metric ton (MT)
       - ounce (OZ)
       - gram (G)

  Energy - joule (J)
	 - calories (CAL)
	 - btu's (BTU)
	 - erg's (ERG)
	 - foot-pounds (FTLB)
	 - kilocalories (KCAL)
	 - kilowatt hours (KWH)
	 - electron volts (EV)

  Pressure - pascals (PA)
	   - atmospheres (ATM)
	   - torr, milimeters of mercury (TORR)
	   - pounds per square inch (PSI)
	   - bars (BAR)
	   - kilopascals (KPA)

  Volume - liter (LT)
	 - gallon (GA)
	 - quart (QT)
	 - fluid ounces (OZ)
	 - pint (PT)

The letters in parenthesis above are what strings you pass to the function to
use that specific unit.

The dll provides 280 conversion possibilities.  If you have a specific 
category(s) or unit(s) that you require, you can request it to be included with 
your registered copy.

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
To Use the DLL in a VB5 program:
1. Register the DLL on your system (you can use regsvr32.exe)
2. Click on Project -> References then select the 'UnitConverterDLL' entry.
3. Declare a module level variable as New UnitConverter.
4. Use it as any other class variable, as in the following example:

	Private ConvertDLL as New UnitConverter
	Dim dblReturnValue as Double

	DblReturnValue = ConvertDLL.Temperature("C", 12.87, "F")

The above code will convert 12.87 degrees Celsius to Fahrenheit.
All of the functions follow the same input parameter format:

(Input Unit as string, Input Value as double, Output Unit as string) as double

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Included in the klsucnvt.zip package are the following files:

  trial.frm - the VB5 form that demonstrates the use of the dll
  klsucnvt.dll - the unregistered version of the dll
  readme.txt - this readme file

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
To obtain a registered version of the Unit Conversion DLL (without those hideous 
nag screens), send $10 check or money order to:

Karl Stuempfle
1900 Harewood Court
Edgewood, Maryland 21040
USA

Make checks payable to: Karl Stuempfle
For custom units/categories add $1 per unit and $3 for each new category. (ex. - 
to purchase the dll with an additional category "X" that contains 2 units would 
be $15 (10 + 3 + 1 + 1))

For additional information: kstuempfle@geocities.com
