MCS VB Functions 1.0.4
**********************
Copyright 1998 Management Control Systems Ltd

This application is shareware. 

To register this product, please send a cheque/ postal order
for �45 UKP or $60 USD to:

Management Control Systems Ltd
30 Lilac Grove
Biggleswade
Bedfordshire
United Kingdom
SG18 8TP

Please make cheques payable to Management Control Systems Ltd.

In addition, you can use the excellent RegNow service to register this
product online:

	https://www.regnow.com/softsell/nph-softsell.cgi?item=1775-1

Please continue to support freeware and shareware. 
This application is copyright Management Control Systems Ltd 1998.


Instructions for use
--------------------

Please read the help file included in this zip.

For comments or suggestions please e.mail software@mcs.uk.com or use the
feedback page at http://www.mcs.uk.com/
