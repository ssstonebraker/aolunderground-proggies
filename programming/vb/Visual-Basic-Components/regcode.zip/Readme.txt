 --------------------------------------------------------
 Module    : RegistryModule(Registry.bas)
 Written by: Elito C. Lelina III
             ECLIPSE Development Software
 URL       : www.geocities.com/SiliconValley/Campus/3118/
 email     : eclipseds@hotmail.com
 --------------------------------------------------------

 This module contains functions for reading and
 setting registry values of type REG_SZ and REG_DWORD
 in Windows 95 and Windows NT. Code can be modified
 to handle other Value type.

 This program makes no guarantees and no support is provided,
 but comments/bug reports are welcome.

 Warning:  Windows depends heavily on Registry Data file.
 Editing registry values can seriously impact Windows and
 your machine's operations. Create Registry Backup before
 editing. You should only edit values when you know what
 they should be.  If editing values as a test, make a note
 of the original value and restore it when you are done.

 The module contains all the neccesary code to access the
 Windows Registry. The project file is provided to demostrate
 the functionality of the module.

 Note. You may freely use this on your project provided that
 you free the author from any liabilities. Although it is unlikely
 that the project will cause any harm, by using the provided code,
 you accept all responsibilities and any consequential damage that
 the project may incure.

 Features:
	* Creating New Key 
	* Modifying an existing value (REG_DWORD & REG_SZ only)
	* Querying an existing value (REG_DWORD & REG_SZ only)
	* Deleting an existing value from the registry
	* Deleting an entire key from the registry

----------------------------------------------------------------------
 � Share your knowledge. It's the best way to achieve immortality. -ECLIPSE 3:16 �
----------------------------------------------------------------------