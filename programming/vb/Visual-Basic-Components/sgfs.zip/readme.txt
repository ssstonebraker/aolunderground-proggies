SG FileSys 1.0
Copyright (C) 1998 Stinga
All Rights Reserved
October 23, 1998


Thank you for your interest in SG FileSys.
SG FileSys is FREE Automation compatible component that can be used to enumerate files and directories on Win32 file system. Main features include: 

 o enumerate files and directories starting at specified root node 
 o set file mask (i.e. *.dll) 
 o set file attributes mask (i.e. enumerate compressed files) 
 o exclude set of directories from the enumeration process 
 o exclude set of files from the enumeration process 
 o retrieve file's type description and icon 
 o ideal extension for WSH scripts 
 o SG FileSys is small, fast and does not need any external DLLs. 
 o SG FileSys is FREE and can be downloaded from www.stinga.com. 

Latest version is available at
http://www.stinga.com/sgFileSys


** System requirements **

 Windows 95, Windows 98 or Windows NT 4.0.
 Windows 5.0 testing is in progress.
 No external DLLs.


** Installation **

 To install SG FileSys, extract archive to some temporary directory 
 and run SETUP.EXE.


** End User Distribution **

 SG FileSys is free and you can use it in any project: commercial or
 public domain.


** Package Distribution **

 Package containing this README.TXT file (sgfs.zip) is freely
 dstributable.
 

** Contact Info **

 Stinga, Nova Cesta 151, 10000 Zagreb, Croatia
 Web:    http://www.stinga.com/sgFileSys
 E-mail: sgfilesys@stinga.com




