Thank you for downloading the shareware version of Intellidev ImageScaler 3.0

To install the ImageScaler Active X control, extract the files in this archive to a temporary directory (c:\temp\setup\) and then run "SETUP.EXE" to install the program.

For more information, please visit our web page at http://www.intellidev.com/ or e-mail support@intellidev.com

