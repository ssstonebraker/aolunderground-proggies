MetaGif32 2.4 Copyright (c) 1996-1998 Eckler Software. 

MetaGif is a 32 bit DLL that converts graphic images to CompuServe 
Gif files. Graphic images can be Windows Metafiles (*.wmf), Enhanced
(*.emf) and Windows Bitmaps (*.bmp) files. MetaGif has a file 
interface and direct binary interface for converting graphic images.
This DLL allows image resizeing without distortion when converting 
Metafiles. With this library you can create WEB documents on the fly,
from your Windows application. With MetaGif you can create a Gif file
that is larger than the screen.

This release includes the following files:

      metagif.dll        16 bit dynamic link library
      metagif32.dll      32 bit dynamic link library
      readme.txt
      main32.bas         Microsoft Visual Basic 5.0 module
      metagif.bas        Microsoft Visual Basic 5.0 module
      test32.frm         Microsoft Visual Basic 5.0 form
      test32.exe         Microsoft Visual Basic 5.0 example program
      test32.mak         Microsoft Visual Basic 5.0 make file
      test32.vbw         Microsoft Visual Basic 5.0 file
      anchor.wmf         Windows Metafile
      coins.wmf          Windows Metafile
      bird32.emf         Windows Enhanced Metafile
      ms.emf             Window Enhanced Metafile
      beany.bmp          Windows Bitmap 

This release still includes the latest 16 bit MetaGif DLL for people
who need it for 16 bit applications.  But, the 16 bit DLL will be 
supported as is, no new updates.  The 16 DLL only supports the 
MetaGif() api call.

The 32 bit MetaGif supports the following display modes - 1, 4, 8, 16
and 24 color bits per pixel.  This corresponds to monochrome, 16, 256,
32k and 16meg color displays.

The 32 bit MetaGif also allow you to control several gif file options. 
Such as 1)change the gif default background from white to any color 
2)make the gif background color transparent 3)create an interlaced gif.

There is a simple 32 bit Visual Basic 5.0 example using the MetaGif
library.  The program will convert several Metafiles and graphic 
images to Gif files.  The example can run from one directory.  
The MetaGif DLL does not need to be copied into your windows/system 
directory to run the example.  This Visual Basic program needs the 
VB5 runtime libraries if you don't have it already.

The conversion from Metafile to Gif is fast, but conversion time
is directly proportional to the size of the Gif file.  MetaGif memory 
usage depends on what color display settings you are using.  A 24 bit 
color display would use 3 times more memory than a 8 bit color display.  

MetaGif uses the default display settings when converting graphic images
to gif.  If you want the same results between Win95 and WinNT the display
mode setting must be identical.  For example, if you are using 24 bit 
color on Win95 you must use the 24 bit color setting on WinNT.  This
requirement is also true for two different PCs.  If you create wmf 
files on one PC and do conversions to gif on another PC make sure the
display mode setting are the same for both machines.

If you want additional copies of MetaGif please see our WEB site for
order information.

      David E. Suffield
      Eckler Software
      620 NE 101st Court
      Vancouver WA 98664

      dsuffiel@ecklersoft.com
      www.ecklersoft.com
      
Do you want to share MetaGif with a friend? A fully functional demo 
version of Metagif is available at www.worldaccessnet.com/~dsuffiel/eckler.htm.

The author of this program accepts no responsibility for damages 
resulting from the use of this product and makes no warranty or 
representation, either express or implied, including but not limited 
to, any implied warranty of merchantability or fitness for a particular 
purpose. This software is provided "AS IS", and you, its user, assume 
all risks when using it.

History:
1.00 Converted from 16 bit MetaGif.

2.00 Rewritten for 32 bit WIN95/NT OS.  Up to 32 times faster than
MetaGif 1.00.  

2.1 Added a new api call - MetaGifEx().

2.2 Added a new api call - MetaGifPic().

2.3 Added support for Enhanced Metafiles (*.emf).

2.4 Removed LZW compression which is patented by Unisys. Added Run Length 
Encoding which still maintains compatibility with normal LZW-based GIF 
decoders.

