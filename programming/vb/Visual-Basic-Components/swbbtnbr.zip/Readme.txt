SWBBtnBar Control Setup
========================

Before you begin, please copy the SWBBtnBar.OCX
file to your \Windows\System directory (which
may not necessarily be named \Windows\System).

Then register the component using REGSVR32.EXE,
as follows:   

In the Start Menu, select "Run".  Then type:

    REGSVR32 \Windows\System\SWBBtnBar.OCX

A message box will confirm the registration.
Before you can use the component in a project,
you will need to add it to the VB toolbox by 
right-clicking on the toolbox and selecting 
"Components".  From the list of registered
components, select "SWB Button Bar".

The component will appear on the toolbar, 
ready for use in your application.  You should
also add the ImageList control which is part
of the Windows Common Controls.  You'll need 
the ImageList in order to select graphics for your
SWBBtnBar buttons.


Copyright 1998  Software with Brains, Inc.
All rights reserved.

sales@softwarewithbrains.com
http://www.softwarewithbrains.com

========================================
Known Issues:

1. Using 16x16 pixel icons in an imagelist will not display
   them properly on the button bar.  Instead, the image will be
   diplayed as if it were a 32x32 pixel icon, showing only 
   the upper-left portion of the image.  To avoid this problem,
   use bitmap type images in the imagelist instead.

