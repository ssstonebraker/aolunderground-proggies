Eckler CopyImage 1.1 Copyright (c) 1998 Eckler Software. 

CopyImage is a light weight COM-based DLL control that can convert
graphic images to image files (wmf/emf/bmp to gif/bmp). Graphic images
can be resized during the conversion. This allows image resizing
without distortion when converting Metafiles. CopyImage has a file
to file interface and a binary to file interface. From VB you can
create a gif copy of any control's Picture property using the binary
interface. With CopyImage you can create WEB documents on the fly and
create a gif file that is larger than the screen.

This release includes the following files:

      cimage.dll         Eckler CopyImage Control
      metagif.dll        16 bit dynamic link library
      metagif32.dll      32 bit dynamic link library
      readme.txt
      cidemo.exe         CopyImage VB5 demo
      cidemo.frm         VB5 form
      cidemo.frx
      cidemo.vbp         VB5 project
      cidemo.vbw
      eckler.bmp         bitmap file
      bird.emf           enhansed windows metafile
      coins.wmf          windows metafile

This release still includes the 16 and 32 bit MetaGif DLL for people
who want to use standard api calls. But, the 16 bit DLL will be 
supported as is, no new updates.  See our web site for MetaGif
documentation and demos.

The cidemo program is a simple example of how to use CopyImage. 
The program will show you how to use the CopyFile and CopyPicture 
methods. CopyImage has properties for setting gif options such 
as - background color, transparent background and interlaced. 
The demo uses default settings - background is white, background 
is transparent and output is interlaced. Note, the PictureBox's 
Picture property can be a *.bmp, *.wmf or a *.emf file.
You can use Microsoft Word to view metafiles and gif file results. 
CopyImage is fully documented at our web site listed below.

This demo assumes you have already installed VB5 Professional or higher.
You must also register the cimage.dll. One way to register cimage.dll 
is to use the Components Dialog's Browse button in VB5. Another way 
is to use regsvr32.exe (version 4.00.1381 or newer).

The conversion from metafile to gif is fast, but conversion time
is directly proportional to the size of the gif file.  CopyImage memory 
usage depends on what color display settings you are using.  A 24 bit 
color display would use 3 times more memory than a 8 bit color display.  

CopyImage uses the default display settings when converting graphic images.
If you want the same results between Win95 and WinNT the display
mode setting must be identical.  For example, if you are using 24 bit 
color on Win95 you must use the 24 bit color setting on WinNT.  This
requirement is also true for two different PCs.  If you create wmf 
files on one PC and do conversions to gif on another PC make sure the
display mode setting are the same for both machines.

If you are familiar with our MetaGif product, CopyImage is COM replacement
for the 32 bit MetaGif DLL. MetaGif is a standard DLL library not a COM 
object. Since CopyImage is a COM object or ActiveX control, CopyImage has 
the advantage of being used in more applications or containers such as VB, 
Internet Explorer 4.0 and IIS Active Server Pages. If you want to purchase
CopyImage please see our web site listed below for order information.


      David E. Suffield
      Eckler Software
      620 NE 101st Court
      Vancouver WA 98664

      dsuffiel@ecklersoft.com
      www.ecklersoft.com
      
Do you want to copy other control images, like MSChart, Calendar, Label, 
TextBox and ListBox to gif or bmp file? You can do this with our Eckler 
CopyCom Control. Generally if you can load a control into Internet 
Explorer 4.0 or higher it can be used with CopyCom. See our CopyCom/MSChart 
ASP demo at www.worldaccessnet.com/~dsuffiel/copycom.html.

The author of this program accepts no responsibility for damages 
resulting from the use of this product and makes no warranty or 
representation, either express or implied, including but not limited 
to, any implied warranty of merchantability or fitness for a particular 
purpose. This software is provided "AS IS", and you, its user, assume 
all risks when using it.

History:
1.0 Converted from 32 bit MetaGif 2.3.

1.1 Removed LZW compression which is patented by Unisys. Added Run Length 
Encoding which still maintains compatibility with normal LZW-based GIF 
decoders.
