
DevPower Flat Button ActiveX Control
Copyright (c) 1998, 1999 Steve Robbins

http://www.devpower.com

Thank you for using this FREE ActiveX control.

If you have Internet Explorer 3 or higher, you can let it install
the control for you at http://www.devpower.com

However, if you don't have Internet Explorer, follow these steps;

(1)	You will need the Visual Basic 5.0 Service Pack 3 Runtime Files.
	If you don't have these already, you can get them from:
	    ftp://ftp.simtel.net/pub/simtelnet/win95/dll/vb500a.zip

(2)	Register the components by running the install.bat batch file

The inclusion of RegSvr32.exe may annoy some of you, but is needed for
easy installation for those who don't have the program on their path.
