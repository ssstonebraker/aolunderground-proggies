Animated Cursor Readme Beta #2
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

!!!!!!YOU MUST READ THE INSTALL.TXT FILE - VERY IMPORTANT!!!!!


Limitations of Beta Version
---------------------------
The beta control has one limitation over the planned full release control. When the control is
first used on a computer, the about dialogue is displayed. In the full version, this dialogue is
only displayed if the control is first used in Visual Basic, in the beta version it occurs 
even on a computer that doesn't have Visual Basic (i.e. when running in a distributed program).

The reason for this is that I do not want this version to be distributed in final applications - 
YET! Once the beta has been tested and I am sure that full release is a good idea, the full
100% FREE version will be available which will not display the message.

Please email me at davesoft@bigfoot.com if you are using this control - if you email me, then I
shall let you know when the final version becomes available.

Things already planned for the final version
--------------------------------------------

* Help files
* Documentation

Specification of Control
------------------------
This is the Beta #2 release. The original had almost passed Beta Testing and then a large fault
was discovered that necessitated the re-writing of this control. If you have not used the
original version and struggle to understand this one, please email me for details.

Unlike the previous version, all controls supported must have an hWnd. If you want a cursor
assigned to a Label control, for example, place the label control in a picture box and assign the
cursor to the picture box.

Filtering no longer occurs. For example, if a cursor is assigned to a form, it will no longer
affect all of the controls on it. With a bit of carefull programming this can, however, be
solved.

You can now assign the cursor to multiple controls, simply separate the control names with a
"\" character in the Control property.

Anybody who used the AvailControls property, please note that the separator is now a "\" not a
"/".

I would appreciate it if users would test this control to the limits (i.e. try placing it in
containers, place lots of them on Forms for different objects etc...). Please note that your
application will malfunction where cursors are concerned if you assign to cursors to one object -
the results are wildly unpredictable (I do not intend to do anything about this - you're kinda
daft if you try to put two cursors on one object!?!)

Finally
-------

Thankyou for your support of this ActiveX control. There are other controls available which can
be obtained by emailing me at davesoft@bigfoot.com

Registered Beta Testers (and there are already of few of them) have the right to have their name,
email address & web page displayed on the About Box of the final version of the control. If you
register, then you can request this option - unless you specifically say that you want to be
included on the list, I will not print the information. Dave Software Enterprises reserves the
right to remove names and details from the list. Another is advantage is that Beta Testers will
be entitled to free or reduced cost versions of other products. My policy is that controls that
do not provide primary functionality for a program and that have not taken too much effort to
develop, should not carry a price tag. However, not all components fit into this category.

NB Beta Testers only get their name on the control that they actually assisted with - not every
one (or the list could get very long!!)

Please feel free to send comments/suggestions/bug reports to me - as soon as I have information
on what people think of the control, then I can release the final version.

Thankyou


David Allsopp. 22nd January, 1999.
davesoft@bigfoot.com
http://www.bigfoot.com/~davesoft