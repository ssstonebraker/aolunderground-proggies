This program may be distributed freely on the condition that it is
distributed in full, and unmodified, and that no fee is charged for such
distribution.

Demo program presents some hard 3D effects like non rectangular Command buttons
using very simple advanced technics and standard MS Visual Basic custom controls. 

This program was distributed by:

	Irek G. Souleimanov
	master@sade.com

