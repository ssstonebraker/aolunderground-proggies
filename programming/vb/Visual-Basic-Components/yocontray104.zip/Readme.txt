*************
YoconTray 1.04
*************

***********************************************************************

Important Notes:

I will accept no responsibility whatsoever for any damage caused 
directly or indirectly from using this OCX.


***********************************************************************

SEE YOCONTRAY.HLP FOR MORE INFORMATION. ALSO PLEASE CHECK OUT 
EXAMPLE.ZIP(CONTAINS A EXAMPLE PROGRAM)

***********************************************************************
YoconTray is a 32-bit OCX(ActiveX control) for Visual Basic, it can 
also be used with Visual C++, but I don't think a VC programmer 
would use this OCX since it's pretty easy to use the WINAPI in VC. It 
adds trayicon(s) into the systray.
***********************************************************************
How to install

create a temp folder, the folder should be on the root of your hard 
drive because the .bat files will not work if the path name is
too long.
extract yocontray104.zip into the temp folder and run install.bat to 
copy this OCX to the system folder and register it.
note: If your system folder is not "c:\windows\system", please change 
it in the .bat file.


---------------------

you can uninstall it by running uninstall.bat
***********************************************************************

Features

	
	-Detects All left, middle(not tried), right mouse events
	-Adds more than one icons into the system tray!
	-You can modify/remove any of the trayicons you added
	-Each icon has its own unique event ID!(new)
***********************************************************************
How to use YoconTray:


	See YoconTray.hlp

***********************************************************************
Distributing More Properties

YoconTray is freely distributable, except for the following 
limitations:

1. The following files must be included in the distribution:


YOCONTRAY.OCX 	Executable file
INSTALL.BAT	Batch file for installing YoconTray
UNINSTALL.BAT	Batch file for uninstalling YoconTray
YOCONTRAY.HLP 	Help file
YOCONTRAY.CNT 	Help contents file
EXAMPLE.ZIP	YoconTray VB5 example
README.TXT	Readme file

2. You may not modify any of the above files.

3. If you wish to include YoconTray in a software collection, such as 
on a CD-ROM, you must inform me at jfgh@rocketmail.com

4. YoconTray is free software.   Therefore, you may not charge more for
it than the cost of the distribution media.

In addition to the files specified above, the following run-time files 
are required in order for YoconTray to work:

MFC42.DLL
MSVCRT.DLL
OLEAUT32.DLL
OLE32.DLL
***********************************************************************
See yocontray.hlp for more information
***********************************************************************
This program is shareware, the price:  One or more email
 (send to jfgh@rocketmail.com) 
that includes:

1) Your Name, and Email Address(optional)

2) How you like it

3) any bugs you have found

4) any ways you thought of to improve it


Pretty cheap, isn't it?

visit YoconSoft at
http://yoconsoft.hypermart.net/
or
http://www.geocities.com/ResearchTriangle/3138/


***********************************************************************
Disclaimer

This software is provided "as is", without warranties of any kind.  The
author accepts no responsibility whatsoever of any damage incurred 
directly or indirectly as a result of using this software. Use this 
software entirely at your own risk.