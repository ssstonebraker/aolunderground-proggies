// errors
#define	TPNoMem								1
#define	TPCantLockMem						2
#define	TPCantOpenFile						3
#define	TPAreaOutOfBounds					4
#define	TPFlagNotRecognized	  				5
#define	TPInvalidArg						6
#define	TPCantCreateBitmap					7
#define	TPCantCreatePal						8
#define	TPUnrecognizedFile					9
#define	TPFormatNotSupported				10
#define	TPCantTransferBits					11
#define	TPCantCreateDib						12
#define	TPUserCanceled						13
#define	TPDLLBusy							14
#define	TPNot24Dib							15		
#define	TPImageTooSmall						16
#define	TPDIBAlready24Bit					17
#define	TPDIBAlready256						18
#define	TPDIBAlready1Bit					19
#define	TPGeneralError						20
#define	TPDIBNotRgb							21
#define	TPDIBAlready16						22
#define	TPNotMyFile							23
#define	TPBadWrite							24
#define	TPUnexpectedTrailer		 			25
#define	TPUnknownConstruct					26
#define	TPUnknownExtension					27
#define	TPBadReadAppExt						28
#define	TPBadReadTextExt					29
#define	TPBadReadCommentExt	  				30
#define	TPBadReadHdt						31
#define	TPBadReadScrDesc					32		
#define	TPBadReadTypeOfExt					33
#define	TPBadReadControlExt  				34
#define	TPBadReadImgDesc					35
#define	TPBadRead							36
#define	TPCantGetDC							37
#define TPCantSaveUndo						38
#define	TPCantCreateFont					39
#define	TPCantGetMetaBits		   			40
#define	TPCantRegisterPrivateFormat			41
#define	TPCantCreateMetafile				42
#define	TPClipboardBusy						43
#define TPUndoStackEmpty					44
#define	TPImageMergeFailed		   			45
#define	TPTooManyOpenFiles		   			46
#define	TPCantApplyGamma	   				47
#define TPFileExportFailed					48
#define TPFileImportFailed					49
#define	TPFailure							50
#define TPFailedUndo						51
#define TPNoValidImageLoaded				52
#define TPFileFormatNotSupported			53
#define TPCorruptFile						54
#define TPCantOpenTmpFile					55
#define TPErrParsingJPEGFile				56
#define TPErrWritingTempFile				57
#define TPErrWritingJPEGFile				58
#define TPCantUndo							59
#define TPCantOpenClipboard					60
#define TPCantEmptyClipboard				61
#define TPClipboardPasteFormatNotSupported	62
#define TPGetFromClipboardFailed			63
#define TPPasteFailed						64
#define TPNotIconFile						65
#define TPInvalidOpcode						66
#define TPImageNotExternal					67
#define TPPictureCantGetType				68
#define TPPictureTypeNotSupported			69
#define TPPictureCantGetBitmap				70
#define TPPictureCantGetPalette				71
#define TPTiffError							72
#define TPInvalidMissingTiffLib				73
#define TPInvalidMissingFifLib				74
#define TPNoFalseColorFor24Bit				75
#define TPInvalidMissingPbmLib				76
#define TPCantGetTempPath					77
#define TPCantMakeTempFileName				78
#define TPFailedFileMapping					79
#define TPInvalidNumPalEntries				80
#define TPInvalidMissingPngLib				81
#define TPNoPluginsFound					83
#define TPPluginBusy						84
#define TPInvalidColorDepth					85
#define TPFilterLargerThanImage				86
#define TPFailedPluginLoad					87 
#define TPFailedPluginResolveAddress		88
#define TPErrPluginParameters				89	
#define TPErrPluginPrepare					90
#define TPPluginImageModeNotSupported		91
#define TPPluginProcessingFailed			92
#define TPInvalidPluginPath					93
#define TPInvalidImageSize					94
#define TPPngInterlacedLessThan5			95
#define TPNoSelectionWhenFitToSize			96
#define TPNoSelection						97
#define TPCorruptUndoFile					98


// filetypes
#define TPFileTypeUnknown			0
#define TPFileTypeClipboard			1
#define TPFileTypeAldusMetafile		2
#define	TPFileTypeWindowsMetafile	3
#define TPFileTypeBmp				4
#define TPFileTypeGif				5			   	
#define	TPFileTypeWindowsIcon		6
#define TPFileTypeWindowsCursor		7
#define TPFileTypePcx				8
#define	TPFileTypeTif				9
#define TPFileTypePng				10
#define TPFileTypeJpg				11
#define	TPFileTypePbm				12
#define	TPFileTypePgm				13
#define	TPFileTypePpm				14
#define	TPFileTypeFractalFif		15

// mirror directions
#define TPMirrorDirLeftToRight		1
#define TPMirrorDirRightToLeft		2
#define TPMirrorDirTopToBottom		3
#define TPMirrorDirBottomToTop		4

// dither methods
#define TPDitherFS					1
#define TPDitherSA					2

// color channels
#define TPColorChannelRed			2
#define TPColorChannelGreen			1
#define TPColorChannelBlue			0
#define TPColorChannelAll			3

// gradient and emboss directions
#define TPNorth						1
#define TPNorthEast					2
#define TPEast						3
#define TPSouthEast					4	
#define TPSouth						5
#define TPSouthWest					6
#define TPWest						7
#define TPNorthWest					8

// shift and difference directions
#define TPVertical   				1
#define TPHorizontal				2
#define TPHorizontalAndVertical		3

// palette creation styles
#define TPPopPal			0x0001		// popularity method
#define TPMedianCutPal		0x0002		// median cut method
#define TPUni884Pal			0x0004		// uniform distribution 8 8 4
#define TPUni666Pal			0x0008		// uniform distribution 6 6 6
#define TPUni256GrayPal		0x0010		// 256 shades of gray
#define TPBWPal				0x0020		// black & white
#define TP16Pal				0x0040		// 16 colors
#define TPHalftonePal		0x0080		// uniform halftone palette 

// gray scale conversion styles
#define	TPGrayMaximum		0x01
#define	TPGrayMean			0x02
#define	TPGrayWeightedMean	0x04

// add border shadow directions
#define TPShadowDirLeft		1
#define TPShadowDirRight	2

// combine operations
#define TPCombineSubtract	1
#define TPCombineAnd		2
#define TPCombineOr			3
#define TPCombineXor		4
#define TPCombineAdd		5
#define TPCombineMult		6
#define TPCombineDiv		7
#define TPCombineMin		8
#define TPCombineMax		9
#define TPCombineAve		10
#define TPCombineOverlay	11

// JPEG load scale
#define TPJPEGLoadAsIs		1
#define TPJPEGLoadHalf		2
#define TPJPEGLoadQuarter	3
#define TPJPEGLoadEighth	4

// Tools
#define TPToolSelectRect				1
#define TPToolSimplePixel				2
#define TPToolSimpleRect				3
#define TPToolSimpleLine				4
#define TPToolSimpleEllipse				5
#define TPToolSimpleBCurve				6
#define TPToolRndJitterBrush			7
#define TPToolSparseDashJitterBrush		8
#define TPToolFDiagonalJitterBrush		9
#define TPToolBDiagonalJitterBrush		10
#define TPToolCrowFeetJitterBrush		11
#define TPToolDenseDashJitterBrush 		12
#define TPToolPixelJitterBrush 			13
#define TPToolSoapOnARopeBrush			14
#define TPToolSelectNothing				15

// Pen Styles
#define TPPenStyleSolid			0
#define TPPenStyleDash			1       /* -------  */
#define TPPenStyleDot			2       /* .......  */
#define TPPenStyleDashDot		3       /* _._._._  */
#define TPPenStyleDashDotDot	4       /* _.._.._  */
#define TPPenStyleNull			5

/* Fill Brush Styles */
#define TPFillBSSolid		0
#define TPFillBSNull		1
#define TPFillBSHorizontal  2       /* ----- */
#define TPFillBSVertical    3       /* ||||| */
#define TPFillBSFDiagonal	4       /* \\\\\ */
#define TPFillBSBDiagonal	5       /* ///// */
#define TPFillBSCross		6       /* +++++ */
#define TPFillBSDiagCross	7       /* xxxxx */

/* background mode */
#define TPBkTransparent		1
#define TPBkOpaque			2

// Brush Slant
// affects TPToolSoapOnARopeBrush only (at the moment)
#define TPBrushSlantNone	1
#define TPBrushSlantLeft	2
#define TPBrushSlantRight	3