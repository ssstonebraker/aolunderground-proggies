This is the Virtual Code Control, a very powerfull text-encryption
OCX control.
The encryption system works over a passwort, text can only be decoded
with the same passwort as the one in the encoding process.

This version of Virtual Code Control is just shareware, the registering
costs $10.

Jan Krumsiek (Jan-K@bigfoot.com)