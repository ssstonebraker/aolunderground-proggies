
DevPower Button Bar ActiveX Control (VB5 Version)
Copyright (c) 1998, 1999 Steve Robbins

http://www.devpower.com

Thank you for using this ActiveX control.

If you have Internet Explorer 3 or higher, you can let it install the
control for you by pointing your browser at http://buttonbar.devpower.com

You will need the Visual Basic 5.0 Service Pack 3 Runtime Files.
If you don't have these already, you can get them from:
	    ftp://ftp.simtel.net/pub/simtelnet/win95/dll/vb500a.zip
