Ecltray.ocx
-----------

Note: To view this page properly, please turn the 'Word Wrap' option in the Edit Menu of Notepad.exe

Writer:  Elito C. Lelina III
	 ECLIPSE� Development Software
URL:	 http://www.geocities.com/SiliconValley/Campus/3118
email:	 eclipseds@hotmail.com
Version: 1.02 (May 21, 1998)
License: FreeWare

The Ecltray is released as a freeware.  Use it as you please. However, sending a copy of your program using the control will be greatly appreciated. I wrote this program because all the similar controls I found on the net doesn't work when VB Service Pack release 3 is installed. So I created this for people having the same problem.

History
--------

V1.01 	First Public Release.
V1.02	Fixed a minor bug. The control doesn't store the user icon
	properly. It still displays the default icon. This has been
	fixed with this release.


Installation
------------

To install the OCX, do the following:

    copy the Ecltray.ocx and Ecltray.hlp files to 'Window\System' folder. This is the proper location to place the file but you can place them in any folder you want.

Open a DOS box and type the following command:
	  REGSVR32 ECLTRAY.OCX

    If you put the control to folder other than the system folder, include the whole path to the command line (i.e. regsvr32 c:\myfolder\mycontrol.ocx)

    If you do not have regsvr32.exe available, you can download it from my homepage.

    Now, run Visual Basic. You should be able to see the Ecltray available from the Project Components option.

Note: Placing the control on a form will bring the 'About Box'. This will not appear again unless you choose the 'About' property or invoke the 'showaboutbox' event of the control.

Pressing F1 on the control will bring up help.


Notes on use:
-------------

The image for the System tray must be an Icon file. This is a windows limitation. Any size and color depth will be accepted but it shall be reduced to 16x16x16 color depth icon. So, to display best the icon you want, create them in 16x16 pixels.

If you do not supply an icon, the VB icon shall be used(default).

Be sure to try out the sample program to see how it works and to see fully commented code on its use.

If you want to bring a popup menu when the tray icon is clicked, call "SetForegroundWindow (Me.hwnd)" before calling the popup menu.  This is the proper way to call a popup menu, so that it disappears when you click outside the menu. The SetForegroundWindow is an API call, be sure to declare it.

See supplied example when using the 'exit' command on a popup menu.

Questions?  Comments? Like to thank me? 
---------------------------------------

Send E-Mail to eclipseds@hotmail.com

Wish to thank me in a greater manner:

Sending a copy of any program you write using my control will be greatly appreciated. Or of course, nobody turns down money. However, send half of the amount you wish to send me to your favorite charity, using YOUR NAME as the donor.

Visit my Homepage at:
http://www.geocities.com/SiliconValley/Campus/3118

-the S, V and C must be upper case or you will not find the site.


	- Elito C. Lelina III -
     ECLIPSE� Development Software


----------------------------------------------------------------------
 � Share your knowledge. It's the best way to achieve immortality. -ECLIPSE 3:16 �
----------------------------------------------------------------------