
DevPower WebColor ActiveX Control
Copyright (c) 1998 Steve Robbins

http://www.devpower.com

Thank you for using this FREE ActiveX control.

NOTE :	Documentation is not included in this archive as it is
	available from the above Web Site.

If you have Internet Explorer 3 or higher, you can let it install
the control for you by pointing your browser at http://www.devpower.com

However, if you don't have IE or you like a challange, follow these
steps to install;

(1)	You will need the Visual Basic 5.0 Service Pack 3 Runtime Files.
	If you don't have these already, you can get them from:
	    ftp://ftp.cdrom.com/pub/simtelnet/win95/dll/vb5rtsp3.zip

(2)	Register the components by running the install.bat batch file

The inclusion of RegSvr32.exe may annoy some of you, but is needed for
easy installation for those who don't have the program on their path.
