This program may be distributed freely on the condition that it is
distributed in full, and unmodified, and that no fee is charged for such
distribution.

This program demonstrates how to create a simple "explosion" effect with
standard MS Visual Basic custom controls. 

This program was distributed by:

	Irek G. Souleimanov
	master@sade.com

