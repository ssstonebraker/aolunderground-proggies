SG Window Version 1.1
Copyright (C) 1998 Stinga
All Rights Reserved
October 30, 1998

Thank you for your interest in SG Window.
This evaluation version does not contain any limitations except that it
will occasionally display registration remainder screen.

Latest version is available at http://www.stinga.com/sgwindow.


===========
Description
===========

 The SG Window is powerful ActiveX component that encapsulates window
 related API calls. With SG Window, VisualBasic� and WSH� programmers
 can do almost anything C/C++ programmers can:

   o SG Window is an ActiveX component - it can be used in the class 
     module without being placed on the form.
   o Cross-process message monitoring
   o Ideal for WSH scripts.
   o Subclass windows and handle messages using two techniques:
     standard events and Implements interface in a class or form module.
   o Catch messages without writing a single line of code.
     Use our free SG Window Wizard add-in.
   o Attach more than one SG Window object to single window handle.
   o Encapsulate message handling code into reusable classes.
   o Access common window API functions without Declare statements.
   o Add user interface to WSH scripts. SG Window has functions to
     show modal or modeless dialogs.
   o Sleep function that dispatches messages and events
     (Sleep with DoEvents).
   o Easy distribution. SG Window is small, about 200kB,
     and has no external DLLs.
   o An excellent tool for every VB and WSH programmer.
   o Almost free. Only $24.


===================
System Requirements
===================

 Windows 95,Windows 98 or Windows NT 4.0.
 No external DLLs.


============
Installation
============

 To install SG Window, extract archive to some temporary directory and
 run SETUP.EXE.


============
Registration
============

 SG Window is shareware. You can register SG Window for $24.
 SG Window can be ordered by secure online form, toll free phone or 
 by postal mail. Secure online registration is available at
   http://www.stinga.com/order.asp.
 For phone, postal mail or fax orders, please consult SG Window
 help file.


=====================
End User Distribution
=====================

 SG Window component is royalty free. Registered users can distribute
 SGWINDOW.DLL. Source code can not be distributed. For more info
 please look at LICENSE.TXT file.


====================
Package Distribution
====================

 Package containing this README.TXT file and SG Window setup program
 (SGWINDOW.ZIP) is freely distributable.


============
Contact Info
============

 Stinga, Nova Cesta 151, 10000 Zagreb, Croatia
 Web:    http://www.stinga.com/sgwindow
 E-mail: sgwindow@stinga.com
         support@stinga.com

