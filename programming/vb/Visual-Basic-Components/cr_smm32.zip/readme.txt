 Crazy Rides
 c/o Gerry Kichok
 60 Bristol Rd E, #221
 Mississauga, Ontario
 CANADA L4Z 3K8
                                                                         
 Phone\FAX: 905-302-3664
 E-mail: gkichok@tcn.net
 Website: http://gkichok.tcn.net                                                                      

 Date: November 28, 1998

 Title: SimpleMinMax Control v.6.00

 Introduction: 
 SimpleMinMax limits the minimum and maximum width and height the form can be sized. SimpleMinMax is Light ActiveX Control, which means it uses very little system resources. Created with Microsoft Visual Basic 6 SP1.


 System Requirements:
 o Windows 95/98/NT4(SP3) 
 o Microsoft's � Visual Basic 6 Runtime Library (Not Included)  


 For installation from diskette, copy setup.exe to diskette. Then run a:\setup.exe .

 For installation from hard drive, copy setup.exe to a directory. Then run setup.exe .


 Price: US$19.95
 Register by phone or fax or over the internet, see the help file for details.
