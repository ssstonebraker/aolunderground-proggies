----------------------------------------------------
OnTopOCX - Visual Basic Foreground Window OCX
Copyright - CMeProducts 1998
E-mail - inbox@cmeproducts.freeserve.co.uk
web - http://www.cmeproducts.freeserve.co.uk
----------------------------------------------------

This product is FREEWARE that you can use freely with your own
applications that you develop.

This control was created with Visual Basic 5 Service Pack 3
Requires: msvbvm50.dll (SP2)

HOW TO INSTALL

1. Copy all the files in the OCX folder into your Windows\System folder
2. Click on the 'Start' button
   Click on 'Run'
   Type in: regsvr32 c:\windows\system\OnTopOCX.ocx
	(Replace the above path with the correct one for your own
	windows\system folder)

USAGE

This OCX, when placed on a form and called, will force whichever form
you declare to become topmost of all visible windows. No need to delve
into the API. One line of code is all that is needed. Only one instance
of the control is needed in any given project.

SYNTAX

OnTopOCX.ForeGround(form-name)=True (or False)
	'form-name' is the form you want to set to the foreground.



DISCLAIMER

OnTopOCX AND THE ACCOMPANYING FILES ARE DISTRIBUTED "AS IS" AND WITHOUT
WARRANTIES AS TO PERFORMANCE OR MERCHANTABILITY. THE USER MUST ASSUME
THE ENTIRE RISK OF USING OnTopOCX.
