This is the JK Joystick Control. It can receive data from the joystick:
x,y,rudder,throttle, coolie hat position and button states. You can 
choose, on which port it should search for the joystick.

This is just shareware, the registering costs $8!

Jan Krumsiek(Jan-K@bigfoot.com)