dcsMixer V1.00 - ActiveX Mixer Control
Copyright 1998 Dynamic Computer Systems/Davies Custom Software
All Rights Reserved

Please note:  If installation fails, you may need the additional ocx support files located at http://www.barint.on.ca/~dcs/dcsMixer/OCX_Support.zip.  You should not need them if you have VB5SP3.

Ever have the need to mute your sound card?

How about controlling the volume from within Visual Basic?

Well now you can.  With the dcsMixer ActiveX control.  

This little activeX control allows you to set the master volume
of your sound card, or to mute it.

I had a need to mute my sound card.  My system runs 24 hours a day,
receiving faxes.  I currently use WinFax software, with the sound 
annoncement turned on.  Unfortunately, this announcement played at 
all times of the day and night.  Sometimes waking members of the 
household.  So I wanted a way a could control the sound card without 
intervention.  After much searching of the internet, I found only 
one mixer control.  When I tried to load this control on a form, it 
crashed.  Now I was back to square one.  Besides they wanted $35US 
(over $50 CDN).  So I decided to do it myself.  The results of which 
are in front of you.


Properties:
	Min (long)	' minimum volume supported by your hardware
	Max (long)	' maximum volume supported
	Volume (long)	' current volume
	Mute (boolean)	' mute status

Events:
	MixerChanged	' there was a change to the mixer settings


Note:	if the end-user's system has no sound card, the Max property will be set to zero (0).


Installation:
	copy the dcsMixerEval.ocx to your windows system directory (c:\windows\system).


Disclaimer:
        This component is distributed as shareware. It may be used
        within Commercial software. This component is provided
        "as is" without any warranty. In no event will the
        author be responsible for any damage resulting directly
        or indirectly by the Component.

        This component can be used in anything, including
        commercial programs. Appropriate credit given to the
        Author (Dynamic Computer Systems/Davies Custom Software) 
	is wished in return, for example, in the about dialog of the application.

dcsMixer can be distributed freely on BBSs, CD-ROMs, Floppies
and so on. Distribution is unlimited. There should, however, be
no profit from distributing the component.

In the event of questions, problems, suggestions, bug reports, and so
on, please email us at dcs@canada.com.
