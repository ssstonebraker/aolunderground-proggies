Attribute VB_Name = "Readme_txt"
'MCMDate.ocx Calendar Control

'Designed by Michael C. Mullen
'Any bug reports or comments to: mcmapait@erols.com

'Requires Visual Basic 5.0 Runtime Library
'available at http://support.microsoft.com/download/support/mslfiles/Msvbvm50.exe

'Functionality:

'The control does not support resizing.

'Preset a date on the control by object.SetDate (myDate),
'otherwise, the current date of the system clock is displayed.

'The date is returned by myDate = object.MCMDate

'To highlight a day without actually selecting it,
'click on the day and then drag off before releasing
'the mouse button.

'Once you select a date, the same date will be selected when you
'move to another month. For example, highlight the 25th of January
'and when you move to February the 25th will still be selected.

'The colors can be set as follows:
'Control background color: object.BackColor = myNewColor
'Font Fore Color: object.ForeColor = myNewColor
'Selected Date Color: object.SelectedColor = myNewColor
'Selected Date BackColor: object.SelectedBackColor = myNewColor
'Current Date Fore Color: object.CurrentDateColor = myNewColor








 













 




