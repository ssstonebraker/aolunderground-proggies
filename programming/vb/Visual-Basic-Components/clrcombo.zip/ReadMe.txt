Color ComboBox ActiveX Control V1.0
Copyright (c) 1998 Hai Li, Zeal SoftStudio.
Release Date: October 22, 1998

E-mail:haili@public.bta.net.cn
Homepage: http://members.tripod.com/~zealsoft/ 
          http://www.nease.net/~zealsoft/indexc.html

Description
-----------
Color ComboBox ActiveX Control offers an easy
method for a user to select a color from a 
combo box based on a predefined color-set or 
to define a custom color. Shareware (US$25)
from Zeal SoftStudio.

Features
--------
� Displays built-in default or user-definable color list
� Several predefined styles
� Optional edit button for custom colors
� Support for automatically changing color entry
� Built-in ChooseColor dialog access
� Find a color or a string with easy
� Easy to use even without one line code
� Special selected item color and 3D effect
� User-definable color bar width and height

Known issue
-----------
This version works with Delphi 2.0 and 4.0, but this
version can not work with Delphi 3.0. When you place
a Color ComboBox control on a Delphi Form, it will 
cause Access Violation exception. This is a well-
known Delphi bug. Call Inprise(Borland) for help.

This version works well with Excel 97, but can not 
work with Access 97.

This version can not work with Visual FoxPro 3.0/3.0b.
When you place a Color ComboBox control on a FoxPro
Form, it will cause an unkonwn OLE error.

History
-------
1.0 		Fix some compatible problems with Visual C++.
1.0 Beta 2	Fix the GPF error with Visual C++.
		Fix the font problem with Delphi 2.0.
		Fix some flash problem.
1.0 Beta	Initial Version.

