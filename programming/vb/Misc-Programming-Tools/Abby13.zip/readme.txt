=======================================================================
= Abby 1.3             (c) 1998 by Yonat Sharon             27-Jul-98 =
=======================================================================

Abby is an add-in to Microsoft Developer Studio 97.
It expands abbreviations like "abb" in good old vi.
For example, "w" can be expanded to:
    while () {
    }

Please send bug reports and suggestions to <yonat@usa.net>.
Latest version available at http://www.kinetica.com/home/yon/4dev/

Disclaimer:
This software is provided as-is. Don't blame me if it trashes your
source files, your system, or your life.

============
Installation
============

1. Copy Abby.dll and the *.abb files to the add-ins folder of
   Developer Studio: C:\Program Files\DevStudio\SharedIDE\AddIns

2. In Developer Studio, go to the "Tools" menu and select
   "Customize...".

3. Go to the "Add-ins and Macro Files" tab (the last one). Mark the
   checkbox next to "Abby" as checked, and click "Close".

4. Developer Studio adds a new toolbar with the Abby button.
   You can move this button to another toolbar by pressing the Alt key
   while dragging the button.

To deactivate Abby, perform steps 2-3, but uncheck the checkbox next
to Abby.

To completely uninstall Abby:
1. Exit Developer Studio.
2. Delete Abby.dll and the *.abb files from your Developer Studio add-
   ins folder.


=====
Usage
=====

Type an abbreviation and press Ctrl+Shift+Space or click the Abby
button. Abby will complete it for you.

To add or change the abbreviations, you will need to edit the
abbreviations files. There is a separate abbreviations file for each
language:
 * C.abb    - C/C++
 * Java.abb - Java
 * VB.abb   - Visual Basic
 * HTML.abb - HTML
 * None.abb - Everything else
All abbreviations files should be in the Windows folder.
The format of these files is described below.


=========================
Abbreviations File Format
=========================

An abbreviation file contains a series of abbreviations followed by
their expansions. Each abbreviations is written in a single line,
starting with "@@" and then the abbreviation itself. All the following
lines (up to the next line starting with "@@") are the expansion.
For example:

@@w
while () {
}
@@f
for (;;) {
}

You can specify where the cursor will be placed after the abbreviation
is expanded by using typing "!!" in the desired position. For example:

@@w
while (!!) {
}

If you type "!!" in two positions, the entire text between them will
be selected after the expansion. For example:

@@w
while (!!condition!!) {
}


================
Acknowledgements
================

Mark Bartosik <mark@rcp.co.uk> helped me solve a nasty COM reference 
leak. Thanks Mark!
