Visual DialogScript version 2.50 Release Notes                 10 july 1998
===========================================================================

Welcome to Visual DialogScript!
-------------------------------

Thank you for trying Visual DialogScript, the simple program development
tool for Microsoft Windows. Please take a few moments to read this file.
It contains important information both for new users and upgraders from
earlier versions of the product.

What is Visual DialogScript?
----------------------------

Visual DialogScript is a programming language and development environment
that has been designed to enable you quickly to develop simple dialog-based
programs or batch files for Windows 95 with the same ease as you might have
written a batch file or a Basic program for DOS.

The DialogScript language is easy to learn and similar to, though much more
powerful than, a batch language or macro language. Visual DialogScript also
includes visual tools: a Dialog Editor for designing dialog boxes visually,
and an Icon Editor for creating graphical icons for your programs.  There
is also a Dialog Wizard which generates the code automatically from your
visually designed dialog. Many useful DialogScript programs can be written
in a matter of minutes!

If you are new to Visual DialogScript, try the short Tutorial, then take a
few minutes to read through the User Guide section of the online manual.
This explains how the program works and covers basic concepts of the
DialogScript programming language. There are also several examples which
you can try out by cutting the code from the help file, pasting it into the
editor window, and running it.

System Requirements
-------------------

Visual DialogScript 16-bit requires the following minimum system
specification:

    - a 386SX PC with 4Mb RAM, VGA display and mouse;
    - Windows 3.1.

Visual DialogScript 32-bit requires the following minimum system
specification:

    - a 486 PC with 8Mb RAM, VGA display and mouse;
    - Windows 95.

The same specifications apply to programs created with Visual
DialogScript.

Note that the 32-bit version uses functions of the Windows 95 shell so
it will not run satisfactorily under Windows NT 3.x.

Installation
------------

If you are an existing user upgrading to a new version, you can simply
copy the contents of the ZIP archive to your current Visual DialogScript
directory.

Some distributions are split into two with the online help and associated
files in a separate archive for easier downloading over the Internet. If
you are an existing user and already have the online help from the
previous version then check the list of changes to see what new features
have been added. If you haven't already done so, it may not be necessary
to download the help files if the changes are minor, or only bug fixes.

New users should unzip the archive contents to a temporary directory
(including the online help if downloaded separately.) Then run the program
SETUP.EXE, which will copy the program files to the desired directory and
create an entry in Program Manager or the Windows 95 Start Menu for the
Visual DialogScript development environment.

You may want to move the runtime engine (DSRUN.EXE/DSRUN16.EXE) to the
Windows System directory, or alternatively to add the location of your
Visual DialogScript directory to your PATH statement. If you run
non-integrated DialogScript executables from directories other than the one
in which the runtime engine is located you will get the error message
"Cannot run script" unless this is done.

Removing Visual DialogScript from your system
---------------------------------------------

Visual DialogScript adds files to no other directories than its own.  To
remove it, simply delete all the files in the Visual DialogScript directory
and then remove the directory.

The 32-bit version creates Registry entries under the Registry key
HKEY_CURRENT_USER\Software\SADE\DialogScript\2.5.

Registering Visual DialogScript
-------------------------------

We hope you like Visual DialogScript and find it useful.  However, please
be aware that Visual DialogScript is not free or public domain software.

You are granted a license giving limited rights to use the software.  The
conditions of use are described in the License Agreement in the online
help. Basically, you are allowed up to 28 days to use the software for the
purpose of evaluating it. After that 28 days, or once you begin using it
for other purposes, whichever is the shorter, you must purchase a full
license for the software. You are violating criminal and intellectual
property laws if you do not do so.

This version of Visual DialogScript is fully functional.  However, while it
remains unregistered the software will display its startup screen for a
longer interval, displaying a gentle reminder that the software is still
unregistered.  Also, any EXE programs you create will upon termination
display a message to say that they were created using an unregistered copy
of the product.

This program can be registered through our agents RegNet - The Registration
Network.  RegNet can be located on the World Wide Web at the following URL:

	http://www.swregnet.com/

Registration costs $69.00 US. You can register online using your credit
card.  RegNet offers secure transactions for users of NetScape or Microsoft
Internet Explorer 3.  To go to the registration page for Visual
DialogScript 2 go to:

	http://www.swregnet.com/2400p.htm

You can reach this page by using the Register Now option on the Help
menu.

Alternatively, you can send a check or money order (in US dollars drawn on
a US bank), made payable to Wintronix, Inc to:

	RegNet (Wintronix, Inc.)
	21200 Trumpet Drive #201
	Santa Clarita, CA  91321-4441

You can also call the toll-free number 1 800 WWW2REG (1 800 999-2734).
Callers from outside the US should call  (801) 355-5110.

Please allow up to three working days for your registration to be
processed. You will receive your personal serial number.  This will be sent
by email if an email address was specified when registering.

When you receive your registration details, open the Register screen again
and enter you name, company or location details and serial number in the
fields provided. The software will then behave as a fully licensed version.

Any compiled EXE scripts that you have created will have to be recompiled
to remove the "unregistered" message that is displayed on termination.


Technical support
-----------------

Support for Visual DialogScript is provided via email to:

	support@vds.sade.net

Two levels of support are offered.

Free pre- and post-sales support covers Installation problems, bug reports
and the provision of workarounds (if possible) where a bug is identified,
and simple questions, like "Can you do this using VDS?" 

An extra-cost support plan is also offered which provides support cover for
the following areas:

-	Help achieving a specific task (we will write sections of script
	code)
-	Help debugging a script that won't work
-	Help writing a script (within the limit of two hours worth of work)
-	The provision of interim upgrades of the VDS software by email
	where a bug prevents a script from working or necessitates an
	inconvenient workaround (other customers must wait for the fixed
	version to be generally released.) 

For more information about support, visit the support page on our Web site.

Whatever your support problem, please help us to help you by including the
following information in your request:

-	Your name and company (as specified on registration)
-	The product name and version number (from the About box)
-	The version of Windows you are using
-	The sequence of events (or a section of script code) which will
	enable us to reproduce the problem.

Please do NOT send large screendump files as enclosures as your message may
be deleted.


Multi-platform support
----------------------

The 32-bit version of Visual DialogScript can create both 32-bit and 16-bit
executable files. DialogScript executables require the appropriate runtime
engine DSRUN.EXE (32-bit) or DSRUN16.EXE (16-bit) or must be created as
integrated executables with a copy of the runtime bound in. Either runtime
is freely redistributable, without royalties, by registered users of the
product.

The 16-bit runtime is not included in the 32-bit package, so you will not
be able to run any 16-bit programs that you create with it. To obtain it we
recommend that you download it from our World Wide Web site to ensure you
have the latest version.

A common help file is used for both versions. Differences in capabilities
between the two versions are (in general) highlighted where appropriate.

Note that the examples in the help file are for the 32-bit version. Most
of the commands where they access the Registry will have to be converted
to the corresponding INI file commands. This is normally a simple matter
of substituting INIFILE for REGISTRY and @iniread for @regread, and
deleting the default key. For other differences see below.

16-bit limitations
------------------

There are some differences in the capabilities of the 16-bit and 32-bit
versions. The main points to be aware of when writing 16-bit script
programs are:

* Long filenames, and various options relating to them, are not supported.

* Registry support is limited, and does not allow named values to be used.

* You cannot obtain the exit code of DOS programs run from within a script.

* The maximum length of a variable or string list item, is 255 characters.

* Internal string handling buffers are also restricted to 255 characters in
  length. Complex expressions may be truncated. Where this occurs, it may
  be possible to avoid the problem by breaking the operation down into
  smaller steps.

* The maximum length of most command parameters is 127 characters. In
  some cases, to reduce memory usage, it may be less, where a parameter
  would not be expected to be very long. This should not normally be a
  problem.

* Task bar icons are not supported. The Dialog Editor allows you to define
  them, but they will result in an error if used.

Known problems
--------------

* When clicking and dragging dialog controls in the Dialog Editor the
  control may lag behind the position of the mouse. The solution is to
  click on the dialog control and pause briefly before dragging or
  resizing the control.

* The presence of tab characters in a script can cause problems for the
  interpreter. The IDE editor does not allow tab characters to be entered.
  If a different editor is used to edit scripts then care should be taken
  to avoid entering tab characters.

* In the 16-bit version there is a limit on the maximum size of a script
  of 32K characters. This limit is imposed by the Windows memo control
  used by the editor, which (like Windows Notepad) does not allow more
  than 32K of text to be loaded into it. In the 32-bit version the maximum
  size of script that the editor can handle is approximately 64K
  characters. A solution is to use an external editor and then compile
  scripts using the command line compiler.

* When copying example code from the online help, blank lines appear
  between some of the lines which were not present in the listing. These
  blank lines can cause an error if they appear in the middle of a dialog
  definition or embedded text so they should be deleted after pasting the
  text into the script editor.

* If you try to create an EXE file in a directory that does not exist,
  VDS will hang. In practise this can only happen if the stored path from
  the last time an EXE was created from that script is no longer valid.

* The Help menu options to connect to our Web site and to register online
  will only work if your system is set up to automatically associate your
  Web browser with an Internet URL.

Changes in version 2.50
-----------------------

Changes:

* Added additional parameters to the LINK command.
* Fixed minor problems.

Changes in version 2.20
-----------------------

New features:

* Added @LOWER function to convert string to lower case.
* @EQUAL function now treats numeric strings as numbers, and has new EXACT
  option for case-sensitive comparisons.
* New functions @STRINS and @STRDEL implemented to allow insertion and
  deletion of characters within strings.
* The @INPUT function now has a PASSWORD option which causes the input
  text to be shown as asterisks.
* The LIST command has a new WINLIST option that creates a list of all the
  main windows in the system.
* A new LINK command lets you create Windows 95 shortcuts (32-bit only).
* A new L pseudo-attribute lets you find out the target of a shortcut
  using the @FILE function.
* You can now have conditional breakpoints by specifying a function after
  the BREAK command.
* A new OPTION, SCALE, will cause a dialog to scale itself in accordance
  with the metrics of the user's screen.

Changes:

* All items in the Tools menu (including the default ones) are now
  controlled by the tool manager. This means you will need to run
  SETUP.EXE to create Registry or INI file entries for the included tools.
* Fixed problem with window IDs being returned incorrectly from some
  window functions.
* Either or both values in an @EQUAL or @GREATER comparison can now be null
  without causing a 'Missing parameter' error.

Changes in version 2.12
-----------------------

New features:

* Added error trapping capabilities. OPTION ERRORTRAP,<label> defines a
  label to jump to if an error occurs, and the @ERROR function lets you
  determine the error code, line number at which the error occurred and
  the contents of the line.

* Added the floating point functions @FATN, @FCOS, @FSIN, @FSQT.

* Added the @BOTH function which returns a 'true' result only if both of
  its arguments are true.

* Added the @SENDMSG function which enables a script program to send
  Windows messages to other windows.

Changes:

* Increased the number of extension DLLs that can be used (ref: EXTERNAL
  command) to 4.

* Fixed problem with message boxes and input boxes not appearing in front
  of dialogs created with ONTOP dialog type.

* (16-bit) Changed the name of some of the accessory programs to avoid
  conflict if it is installed into the same directory as the 32-bit
  version.

Changes in version 2.11
-----------------------

New features:

* Added command line compile option. This feature is provided to enable
  those users who have developed scripts which have become too large for
  the integrated editor to handle to compile them. It also lets you do
  cool things like write scripts that output .dsc files which can then be
  compiled into custom executables.

  To use the command line compiler you must execute the command:

    DS(16) /C script-file-path

  This will create a matching EXE in the same directory.

  Additional command line options are:

    /X exe-path    - specifies alternative path for EXE file

    /I icon-path   - specifies path of icon to use

    /INT           - specifies an integrated EXE to be created

    /16            - (32-bit only) creates a 16-bit executable

  DS.EXE returns an errorlevel of > 0 if the attempt to create an EXE
  fails. DS16.EXE gives no indication of failure as a 16-bit Windows
  program cannot pass an errorlevel value, so it is advisable to delete
  the EXE, if it exists, before running the command line compile, and
  then test for its existence on completion.

Changes:

* Fixed bug causing assignments of strings terminating with a space to be
  null.
* Improved the behavior of the Dialog Editor.
* (16-bit) Fixed bug that caused dialogs to have no minimize button.
* (16-bit) Fixed bug in @VOLINFO with flag N.

Changes in version 2.10
-----------------------

New features:

* Included a Tip of the Day at start-up to inform users of tips and
  featurees.
* Made improvements to the editor include a user-definable tab interval
  and a Smart Enter that starts a new line on the same column as the line
  above.
* The IDE can now optionally create integrated EXE files with the
  run-time engine bound in.
* (16-bit) Included a help contents browser with similar functionality to
  that included with Windows 95.
* Added @NUMERIC function to test whether a string is a valid number.
* Added @HEX function and support for hexadecimal arithmetic (hex numbers
  must be prefixed by a $ character.)
* Added @ESC function to generate an Escape character (equivalent to
  @CHR(27)).
* Added @MSGBOX function which enables you to use the full range of
  Windows message box types.
* Added new window information functions @WINTEXT, @WINCLASS, @WINATPOINT.
* Added WINDOW SETTEXT command to set the text of a window control.
* Added WINDOW CLICK and WINDOW RCLICK commands to simulate mouse clicks on
  a specified window.
* Added DLGTYPE NOSYS and NOMIN to hide the system menu and minimize
  button.
* Added CLICK events for CHECK, COMBO, LIST and RADIO dialog elements
  so an event can be triggered by making a selection.
* Added EXIT events for COMBO and EDIT dialog elements so an event can be
  triggered on leaving the control.
* Added LIST LOADTEXT command to allow text embedded in a script to be
  loaded into a string list.
* Added WINHELP command to enable the Windows help system to be used by a
  DialogScript program.
* Added STOP command (unconditional halt, even within GOSUB).
* Implemented extension interface. An additional command and function can
  be added by means of a specially-written DLL.

Changes:

* Updated the Window Spy to give more information relating to the enhanced
  window functions, such as the mouse position.
* Programs now search their own directory as well as the current directory
  for files without a full path name that are loaded from a script.
* Increased the number of string lists allowed from 4 to 9.
* The @CLICK function now accepts an argument of flags B, R, X, Y returning
  multiple values which can be separated using PARSE. The previous format
  is still accepted.
* Enhanced the @WINEXISTS function to detect the existence of child
  windows.
* Enhanced the @SUM function so it can now sum an unlimited list of
  arguments.
* Fixed problem with @NEXT leaving OK unchanged rather than setting it to
  True.
* Fixed the problem with DIALOG CLOSE destroying the dialog before the
  script finishes when run in the debugger.
* Fixed the problem with trailing spaces on a command line causing
  inconsistent behavior between debugger and run-time.
* Fixed the problem affecting users of some European keyboards in which
  characters generated by pressing the right-hand shift key were not sent
  correctly by Window Send.
* (16-bit) Fixed problems affecting commands and functions that access the
  Registry.
* (16-bit) LIST COPY and LIST PASTE now no longer restricted to a maximum
  255 characters of text.
* (16-bit) Fixed problem with Dialog Editor help not appearing when
  running under Windows 3.1.
* Fixed several problems with Icon Editor, such as Undo not working.
* Fixed some bugs in the Dialog Editor.
* Dialog Wizard now generates code for all events used by the dialog
  without the need to manually refresh the dialog before exiting.
* Improved the error checking and added additional error messages.

Changes in version 2.05
-----------------------

Changes:

* (16-bit) Fixed bug affecting Alt-keys in WINDOW SEND.
* Fixed bug in @NAME function (returned null if no period in filename.)
* Fixed some problems with dialog editor.

Changes in version 2.04
-----------------------

Changes:

* (16-bit) Fixed bug which made RUNM, RUNZ, RUNH all have the same effect
  as RUN.

Changes in version 2.03
-----------------------

New features:

* The OPTION PRIORITY command lets you set the priority level of your
  programs.  (32-bit only)
* The OPTION SKDELAYcommand lets you add a delay between characters sent
  using the WINDOW SEND command.
* The RUN and SHELL commands have an extra optional priority level
  parameter.  (32-bit only)
* In the REGISTRY command and the @REGREAD function you can now use the
  STATS root key to access the Windows performance statistics under
  Registry key HKEY_DYN_DATA.  (32-bit only)

Changes:

* Fixed problem with 32-bit Dialog Editor which caused incorrect wrapping
  of dialog elements when inserting to the editor.
* Fixed bug in Dialog Editor whereby value field clears when value of
  RADIO dialog element is changed.
* Fixed bug in Dialog Editor that caused default style names to always be
  STYLE1.
* Fixed bug in 16-bit runtime that caused first command line parameter
  passed to an EXE program to be lost.
* Fixed problem that caused 'Unable to run EXE' or 'Sharing violation'
  messages on some systems.
* Default INI file handling has been changed to use DS16.INI instead of
  DEFAULT.INI for compatibility with the 16-bit version.

===========================================================================
S.A.D.E. s.a.r.l., 94-96, rue Victor Hugo 94200 Ivry-sur-Seine, FRANCE

        Find us on the World Wide Web at: http://www.vds.sade.net/
