/***************************************************************

	ImgDLL - a Win32 Image File Processing DLL

	Copyright 1997, 1989 Smaller Animals Software

	Author 
		Chris Losinger, smallest@smalleranimals.com
		http://www.smalleranimals.com/index.htm

		This DLL provides JPG, PCX, PNG, TGA, TIFF, GIF, 
	WMF and BMP support.	WMF is read-only.

		Also included are routines to do various image processing
	functions such as 24-bit to 8-bit color quantization and
	gray-scaling, resizing, sharpening and blurring, 
	DWORD-alignment utilities, image size querys, etc..

		This DLL is freely distributable. The full-access key is not.
	If you have a full-access key without paying for it, you are
	using this without permission, and that is illegal. 
		
		Companies who distribute ImgDLL as part of an application
	without first registering ImgDLL are in violation of the terms-of-use 
	(see ImgDLLv4.rtf) and will be prosecuted.

		GIF output is accomplished by using a non-LZW algorithm.

	------

	This DLL (and supporting library, ImgLib, is thread-safe.
	All error and state data (initialization info, PNG/JPG Text, 
	DPI info, etc.) are stored in thread-local data : each thread
	gets its own copy of the error and state data. It will appear
	to each thread that it is the only thread using the DLL.

	For this reason, the DLL (and lib) must be initialized for
	each thread.

	------


	Tech Credit:

		Color quantization code modified from DL1Quant, by Dennis Lee 
			(denlee@ecf.utoronto.ca)

		JPEG code from IJG v6b.

		PCX code from Bob Johnson's PCXLib

		PNG code from LibPng 1.0.1

		TIFF code from LibTiff v3.4 b37

		WMF code from www.codeguru.com

		TGA code from Timothy A. Bish

	-- non-LZW GIF encoder copyright info --
		
		Encoder from http://www.boutell.com/gd/

		Portions copyright 1994, 1995, 1996, 1997, 1998, by Cold Spring Harbor 
		Laboratory. Funded under Grant P41-RR02188 by the National Institutes of Health. 

		Portions copyright 1996, 1997, 1998, by Boutell.Com, Inc. 

		GIF decompression code copyright 1990, 1991, 1993, by David Koblas 
		(koblas@netcom.com). 

		Non-LZW-based GIF compression code copyright 1998, by Hutchison 
		Avenue Software Corporation (http://www.hasc.com/, info@hasc.com). 

	--

		All other code written by Smaller Animals Software, Chris Losinger.


	Usage notes :

		0)	DLL must be initialized with ImgDLLStringInitDLL. the value passed to
	this function may be the key to unlock the full version of the DLL.
	Registered users will be given the real key. Everyone else is free to
	try any value they like.

		1)	all strings are to be zero-terminated - some languages don't do this
	by default. 

		2)	UINT32 is a 32-bit unsigned integer. this works as a "long" in VB. 
	VB's "Integer" is too small!!

		3)	BOOL is a 32-bit unsigned integer. zero for FALSE, one for TRUE.

		4)	RGBQUAD is a structure defined as follows :

		typedef struct tagRGBQUAD { 
			BYTE    rgbBlue; 
			BYTE    rgbGreen; 
			BYTE    rgbRed; 
			BYTE    rgbReserved; 		  // rarely used
		} RGBQUAD; 

		5)	"__int32" is a 32-bit signed integer.

		6)	HGLOBAL is a HANDLE to memory allocated by GlobalAlloc.
	If a routine returns a non-NULL HGLOBAL value, it is up to
	the caller to call GlobalFree to release this memory back
	to the system. See ImgDLLv4.rtf for more info.

		7)  RGB means 24-bit (3 BYTEs per pixel)  Red,Green,Blue, one BYTE each.
	If you have an RGB buffer of an image that is 100 x 100 pixels, you
	MUST have a buffer of 100 x 3 x 100 BYTEs!! All calls that says RGB
	assume this arrangement. RGB is the same as "packed RGB".
	
		8)	double designates a 64-bit floating-point number.

		9)	"colormapped 8-bit" means an image which is made up of 8-bit pixels
	each of which is an index into a palette of 24-bit RGB values. 
	a "colormapped 8-bit" buffer is not the same as a 24-bit (RGB) buffer.

***************************************************************/

#ifndef IMGDLLH
#define IMGDLLH

#define IMGEXP WINAPI //FAR PASCAL

/***************************************************************
	
	  error codes

***************************************************************/

#define TRIALVERSION	-1		// LIB was not initialized with a registered key

#define IMGOK				0		// no err
#define MEMERR				1		// out of memory
#define FILEOPENERR		2		// error on file open
#define FILEREADERR		3		// error on file read
#define FILEWRITEERR		4		// error on file write
#define BADPARAMERR		5		// bad user param
#define INVALIDBMPERR	6		// bad BMP file
#define BMPRLEERR			7		// some RLE variations are not supported
#define INVALIDGIFERR	8		// bad GIF file
#define INVALIDJPGERR	9		// bad JPG file
#define IMGDCERR			10		// error with device context
#define IMGDIBERR			11		// problem with a GetDIBits call
#define NOGIFERR			12		// GIF support disabled
#define IMGNORESOURCE	13		// resource not found
#define CALLBACKCANCEL	14		// callback returned FALSE - operation aborted
#define INVALIDPNGERR	15		// bad PNG file
#define PNGCREATEERR		16		// internal PNG lib behavior - contact smaller animals s.w.
#define IMGDLLINTERNAL	17		// misc unexpected behavior error - contact smaller animals s.w.
#define IMGFONTERR		18		// trouble creating a font object
#define INTTIFFERR		19		// misc internal TIFF error
#define INVALIDTIFFERR	20		// invalid TIFF file
#define TIFFLZWNOTSUPPORTED	21	// this will not read TIFF-LZW iamges
#define INVALIDPCXERR	22		// invalid PCX image
#define CREATEBMPERR		23		// a call to the fn CreateCompatibleBitmap failed
#define IMGNOLINES		24		// end of an image while using single-line de/compression
#define GETDIBERR			25		// error during a call to GetDIBits
#define DEVOPNOSUPPORT	26		// device does not support an operation required by this function
#define INVALIDWMF		27		// invalid windows metafile
#define DEPTHMISMATCHERR	28	// the file was not of the requested bit-depth
#define BITBLTERR			29		// a call to BitBlt failed.
#define BUFTOOSMALL		30		// output buffer is too small for this operation
#define TOOMANYCOLORS	31		// not enough room in the output palette to store the colors from this image
#define INVALIDTGAERR	35		// Invalid TGA File
#define NOTGATHUMBNAIL	36		// No TGA Thumbnail in the file 

#define IMGDLL_LOCK_KEY	"Key"	// key to unlock Lib provided to registered
										// users only. any other key will prevent the Lib
										// from offering full functionality.

/* These are for the PNG interlacing type.*/
#define PNG_INTERLACE_NONE        0 /* Non-interlaced image */
#define PNG_INTERLACE_ADAM7       1 /* Adam7 interlacing */
#define PNG_INTERLACE_LAST        2 /* Not a valid value */

/* PNG color type masks - use the next set of values, not these! */
#define PNG_COLOR_MASK_PALETTE    1
#define PNG_COLOR_MASK_COLOR      2
#define PNG_COLOR_MASK_ALPHA      4

/* PNG color types.  Note that not all combinations are legal */
#define PNG_COLOR_TYPE_GRAY 0
#define PNG_COLOR_TYPE_PALETTE  (PNG_COLOR_MASK_COLOR | PNG_COLOR_MASK_PALETTE)
#define PNG_COLOR_TYPE_RGB        (PNG_COLOR_MASK_COLOR)
#define PNG_COLOR_TYPE_RGB_ALPHA  (PNG_COLOR_MASK_COLOR | PNG_COLOR_MASK_ALPHA)
#define PNG_COLOR_TYPE_GRAY_ALPHA (PNG_COLOR_MASK_ALPHA)

/***************************************************************
	
	channelMask values : e.g.

	BYTE mask = CHRED | CHGREEN;// use only red and green values in this operation

***************************************************************/

#define CHRED		1			// include RED channel if this is set in channelMask
#define CHGREEN		2
#define CHBLUE		4

#define UINT32	unsigned __int32	// 32 bits

#ifdef __cplusplus
extern "C" {
#endif

/***************************************************************

  void IMGEXP ImgDLLStringInitDLL(...)

	Purpose :
		Perform DLL initialization / unlock. 


	Param				Type				Use
	initString		const char *	ImgDLL unlock key

										users who have paid for the DLL
										will be given a valid value for LOCK_KEY
										that will allow them to use all
										of the DLLs functions without limits.

	Note :
	This call should only be called once per session. All calls
	after the first will have no effect. 

	Besides unlocking the DLL, this performs other useful initialization
	functions.

	Note :

	Return
		none

****************************************************************/

void IMGEXP ImgDLLStringInitDLL(const char * initString);

// obsolete as of v4.3 . use ImgDLLStringInitDLL
// void IMGEXP ImgDLLInitDLL(UINT32 initVal);

/***************************************************************

	BOOL IMGEXP ImgDLLGetVersion(...)

	Purpose :
		Get ImgDLL version string

	Param				Type			Use
	versString		char *		caller-allocated buffer of chars
										this will receive the version string

	iLen				__int32		length of buffer (including space for trailing 0)

	for safety, versString should be at least 15 characters long

	Return
		TRUE on success

***************************************************************/

BOOL IMGEXP ImgDLLGetVersion(char * versString,
										__int32 iLen);

/***************************************************************

	__int32 IMGEXP ImgDLLGetLastError()

	Purpose :
		query the last error value

	Param				Type			Use
	none

	Return
		__int32 value of error - see above for values and meaning

***************************************************************/

__int32 IMGEXP ImgDLLGetLastError();

/***************************************************************

	void IMGEXP ImgDLLSetJPGErrorMsgBox(...)

	Enable JPG error message boxes

	Param				Type			Use
	enable			BOOL			TRUE, enable modal msg boxes, else disable

	Return
		none

***************************************************************/

void IMGEXP ImgDLLSetJPGErrorMsgBox(BOOL enable);

/***************************************************************

	void IMGEXP ImgDLLSetJPGDCT(...)

	Switch the compression method : dct is one of :

	0 - default (usually JDCT_ISLOW)
	1 - JDCT_ISLOW: slow but accurate integer algorithm
	2 - JDCT_IFAST: faster, less accurate integer method
	3 - JDCT_FLOAT: floating-point method

	It is not necessary to use this function to be able save JPG files.
	This is only for people who need more speed or higher quality
	in their output.

	All JPG files written will be written using this setting.
	
	Param			Type				Use
	dct			UINT32			which level to set

	Return
		none

***************************************************************/
void IMGEXP ImgDLLSetJPGDCT(UINT32 dct);

/***************************************************************
	callback type definition

	ex.  this prints the row #'s, as they are processed, to the debug window

	BOOL CALLBACK functionName(UINT32 curRow, UINT32 totalRows)
	{
		TRACE2("cur row : %u    total rows : %u\n",curRow, totalRows);
		return TRUE;
	}

	...
		ImgDLLSetCallback(functionName);
	...
***************************************************************/
typedef BOOL (CALLBACK* CALLBACKPTR)(UINT32 uCurRow,			// current row
									 UINT32 uHeight);						// total rows	

/***************************************************************

	void IMGEXP ImgDLLSetCallback(...)

	Purpose :
	The DLL will call the callback function once for every scan line
	read or written to a JPG, PCX, TIFF, TGA, PNG, GIF or BMP file. 

	The DLL will also call the callback function once per row for all 
	image processing calls, except where stated otherwise. 
	
	Operations which do not operate on image buffers are not "image 
	processing calls" and so, these won't use the callback function. 
	This includes calls such as JPG and PNG text calls, PNG gamma and 
	background operations, DPI queries, ImgDLL error queries, etc.. 
	Basically, if there is no loop over pixels, there is no callback call.
	However, this does not mean that *all* operations which do have a 
	pixel loop use the callback function: some don't. Check the function
	comments in this file, to be sure.

	If the callback function returns FALSE the operation aborts and 
	ImgDLLGetLastError will return CALLBACKCANCEL

	You can use this to monitor the progress of ImgDLL operations.

	It is not neccessary for you to use this function. If you do not
	set the callback function or pass a NULL to this call, no callback
	will be performed.

	Param				Type				Use
	pCallback		CALLBACKPTR		ptr to a function defined to 
											accept 2 UINTs and return a BOOL.
	Return
		none

***************************************************************/

void IMGEXP ImgDLLSetCallback(CALLBACKPTR pCallback);

/***************************************************************

	BOOL IMGEXP ImgDLLSaveRGBToJPG(...)

	Purpose :
		Save an RGB buffer to a JPG file . 
		Buffer must be packed RGB.

		This will write all JPG text fields set by ImgDLLAddJPGText.

		A JPG file may contain any number of text fields (JPEG_COM markers).
	These strings can be any length. Once added, these strings will be 
	written to all subsequent JPG files until ImgDLLClearJPGOutputText is 
	called.

	Param				Type				Use
	fileName			const char *	path to open for writing
	pBuf				BYTE *			image buffer
	uWidthPix		UINT32			width, in pixels
	uHeight			UINT32			height, in pixels
	uQuality			UINT32			quality from 1-100
	bColor			BOOL				FALSE = Grayscale
	bProgressive	BOOL				TRUE = write progressive mode

	modifies global error value, check with	ImgDLLGetLastError()

	Return
		TRUE on success

***************************************************************/

BOOL IMGEXP ImgDLLSaveRGBToJPG(const char * fileName,
											BYTE * pBuf,
											UINT32 uWidthPix,
											UINT32 uHeight,
											UINT32 uQuality,
											BOOL bColor,
											BOOL bProgressive);

/***************************************************************

	BOOL IMGEXP ImgDLLGrayscaleToJPG(...)

	Purpose :
		Save an 8-bit grayscale buffer to a JPG file . 
		Buffer must be 8 bit data. 0 for black 255 for white.

		This will write all JPG text fields set by ImgDLLAddJPGText.

		A JPG file may contain any number of text fields (JPEG_COM markers).
	These strings can be any length. Once added, these strings will be 
	written to all subsequent JPG files until ImgDLLClearJPGOutputText is 
	called.

	Param				Type				Use
	fileName			const char *	path to open for writing
	pBuf				BYTE *			image buffer
	uWidthPix		UINT32			width, in pixels
	uHeight			UINT32			height, in pixels
	uQuality			UINT32			quality from 1-100
	bProgressive	BOOL				TRUE = write progressive mode

	modifies global error value, check with	ImgDLLGetLastError()


	Return
		TRUE on success

***************************************************************/

BOOL IMGEXP ImgDLLGrayscaleToJPG(const char * fileName, 
							BYTE *dataBuf,
							UINT32 widthPix,
							UINT32 height,
							__int32 quality,
							BOOL bProgressive);

/***************************************************************

	UINT32 IMGEXP ImgDLLSaveRGBToJPGMem(...)

	Purpose :
		Save an RGB buffer to a JPG image in memory. Output
		buffer must have been previously allocated by the 
		caller. For safety, make this at least (width * height * 3) BYTEs.

		Input buffer must be packed RGB.

		This will write all JPG text fields set by ImgDLLAddJPGText.

		A JPG file may contain any number of text fields (JPEG_COM markers).
	These strings can be any length. Once added, these strings will be 
	written to all subsequent JPG files until ImgDLLClearJPGOutputText is 
	called.

	Param				Type			Use
	outBuf			BYTE *		memory at which to write the JPG image
	outBufSize		UINT32		size of output buffer in BYTEs
	pBuf				BYTE *		input image buffer
	uWidthPix		UINT32		width, in pixels
	uHeight			UINT32		height, in pixels
	uQuality			UINT32		quality from 1-100
	bColor			BOOL			FALSE = Grayscale
	bProgressive	BOOL			TRUE = write progressive mode

	modifies global error value, check with	ImgDLLGetLastError()


	Return
		UINT32 representing number of bytes actually written to memory.

***************************************************************/

UINT32 IMGEXP ImgDLLSaveRGBToJPGMem(BYTE * outBuf,
												UINT32 outBufSize,
												BYTE * inBuf,
												UINT32 uWidthPix,
												UINT32 uHeight,
												UINT32 uQuality,
												BOOL bColor,
												BOOL bProgressive);

/***************************************************************

	HGLOBAL IMGEXP ImgDLLReadRGBFromJPG(...)

	Purpose :
		Read a JPG file to a buffer of RGB bytes.

		A JPG file may contain any number text fields (JPEG_COM markers).
	These strings can be any length. When ImgDLL reads a JPG file, 
	it stores these strings in the ImgDLL JPG text buffer. These 
	strings remain valid until :

		1) the next JPG file is read
		2) ImgDLLClearJPGInputText is called

	Param				Type				Use
	fileName			const char *	path to open for reading
	uWidth			UINT32*			width, in pixels
	uHeight			UINT32*			height, in pixels

	modifies global error value, check with	ImgDLLGetLastError()

	Return
		HGLOBAL . 
		Caller must use GlobalUnlock to get a ptr to this buffer!
		Caller is responsible for calling GlobalFree on this buffer!

***************************************************************/

HGLOBAL IMGEXP ImgDLLReadRGBFromJPG(const char * fileName,
							 UINT32 *width,
							 UINT32 *height);

/***************************************************************

	HGLOBAL IMGEXP ImgDLLReadRGBFromJPGMem(...)

	Purpose :
		Read a JPG memory stream to a buffer of RGB bytes.

		A JPG file may contain any number text fields (JPEG_COM markers).
	These strings can be any length. When ImgDLL reads a JPG file, 
	it stores these strings in the ImgDLL JPG text buffer. These 
	strings remain valid until :

		1) the next JPG file is read
		2) ImgDLLClearJPGInputText is called

	Param				Type			Use
	inBuf				BYTE *		buffer containing JPG file image
	inBufSize		UINT32		size of input buffer
	uWidth			UINT32*		width, in pixels
	uHeight			UINT32*		height, in pixels

	modifies global error value, check with ImgDLLGetLastError()

	Return
		HGLOBAL . 
		Caller must use GlobalUnlock to get a ptr to this buffer!
		Caller is responsible for calling GlobalFree on this buffer!

***************************************************************/

HGLOBAL IMGEXP ImgDLLReadRGBFromJPGMem(BYTE * inBuf,   
											UINT32 inBufSize,
											UINT32 *width,
											UINT32 *height);

/***************************************************************

	HGLOBAL IMGEXP ImgDLLRead8BitGrayscaleFromJPG(...)

	Purpose :
		Read a JPG file to a buffer of width * height bytes.

		A JPG file may contain any number text fields (JPEG_COM markers).
	These strings can be any length. When ImgDLL reads a JPG file, 
	it stores these strings in the ImgDLL JPG text buffer. These 
	strings remain valid until :

		1) the next JPG file is read
		2) ImgDLLClearJPGInputText is called

	Param				Type			Use
	fileName			const char *	path to open for reading
	uWidth				UINT32*			width, in pixels
	uHeight				UINT32*			height, in pixels

	modifies global error value, check with ImgDLLGetLastError()

	Return
		HGLOBAL . 
		Caller must use GlobalUnlock to get a ptr to this buffer!
		Caller is responsible for calling GlobalFree on this buffer!

***************************************************************/

HGLOBAL IMGEXP ImgDLLRead8BitGrayscaleFromJPG(const char * fileName,
							 UINT32 *width,
							 UINT32 *height);

/***************************************************************

	HBITMAP IMGEXP ImgDLLReadHBITMAPFromJPG(...)

	Purpose :
		Read a JPG file to an HBITMAP - if hPal is non-NULL and the
	display is at <= 256 colors, hPal is used to render the image. 
	if NULL and display is <= 256 colors, the system palette will be used 
	instead.

		internally, this call wraps ImgDLLReadRGBFromJPG and ImgDLLRGBToHBITMAP

		A JPG file may contain any number text fields (JPEG_COM markers).
	These strings can be any length. When ImgDLL reads a JPG file, 
	it stores these strings in the ImgDLL JPG text buffer. These 
	strings remain valid until :

		1) BEFORE the next JPG file is read
		2) ImgDLLClearJPGInputText is called

	Param				Type			Use
	fileName			const char *	path to open for reading
	hPal				HPALETTE		palette

	modifies global error value, check with	ImgDLLGetLastError()

	Return
		HBITMAP - the new bitmap!
		
		be sure to call DeleteObject(..) on this when you're done!

***************************************************************/

HBITMAP IMGEXP ImgDLLReadHBITMAPFromJPG(const char * fileName,
										HPALETTE hPal);

/***************************************************************

	BOOL IMGEXP ImgDLLSaveRGBToBMP(...)

	Purpose :
		Save an RGB buffer to a 24-bit BMP file . 
		Buffer must be packed RGB (not DWORD aligned), 
		vertically oriented as viewed.

	Param					Type				Use
	fileName				const char *	path to open for writing
	pBuf					BYTE *			image buffer
	uWidthPix			UINT32			width, in pixels
	uHeight				UINT32			height, in pixels

	modifies global error value, check with	ImgDLLGetLastError()

	Return
		TRUE on success

***************************************************************/

BOOL IMGEXP ImgDLLSaveRGBToBMP(const char * fileName,
						BYTE * pBuf,
						UINT32 uWidthPix,
						UINT32 uHeight);

/***************************************************************

	BOOL IMGEXP ImgDLLSaveColormappedToBMP(...)

	Purpose :
		Save a colormapped buffer to a colormapped BMP file . 
		Buffer must be colormapped, 8-bit per pixel,
		vertically oriented as viewed. 

	Param				Type				Use
	fileName			const char *	path to open for writing
	pBuf				BYTE *			8-bit image buffer
	uWidthPix		UINT32			width, in pixels
	uHeight			UINT32			height, in pixels
	uBPP				UINT32			bits per pixel to save as
	uColors			UINT32			colors in palette
	rgbPalett		RGBQUAD *		palette array

	modifies global error value, check with	ImgDLLGetLastError()


	Return
		TRUE on success

***************************************************************/

BOOL IMGEXP ImgDLLSaveColormappedToBMP(const char * fileName,
									BYTE * pBuf,
									UINT32 uWidthPix,
									UINT32 uHeight,
									UINT32 uBPP,
									UINT32 uColors,
									RGBQUAD *rgbPalette);

/***************************************************************

	BOOL IMGEXP ImgDLLSaveDIBColormappedToBMP(...)


	Purpose :
		Save a colormapped buffer to a colormapped BMP file . 
		Buffer must be in DIB format - 1,4,8,24 or 32 bits.


	Param				Type				Use
	fileName			const char *	path to open for writing
	pBuf				BYTE *			image buffer
	pBMI				BITMAPINFO *	filled in BITMAPINFO
	colorMap			RGBQUAD *		palette - ognored for 24-bit DIBs

	modifies global error value, check with	ImgDLLGetLastError()


	Return
		TRUE on success

***************************************************************/

BOOL IMGEXP ImgDLLSaveDIBColormappedToBMP(const char * fileName,
											BYTE * pBuf,
											BITMAPINFO * pBMI,
											RGBQUAD *colorMap);

/***************************************************************

	HGLOBAL IMGEXP ImgDLLReadRGBFromBMP(...)

	Purpose :
		Read a BMP file to a buffer of RGB bytes. Does not read
	RL-encoded BMP files.

	Param				Type				Use
	fileName			const char *	path to open for reading
	uWidth			UINT32*			width, in pixels
	uHeight			UINT32*			height, in pixels

	modifies global error value, check with	ImgDLLGetLastError()

	Return
		HGLOBAL . 
		Caller must use GlobalUnlock to get a ptr to this buffer!
		Caller is responsible for calling GlobalFree on this buffer!

***************************************************************/


HGLOBAL IMGEXP ImgDLLReadRGBFromBMP(const char * fileName,
									 UINT32 *width,
									 UINT32 *height);

/***************************************************************

	HBITMAP IMGEXP ImgDLLReadHBITMAPFromBMP(...)

	Purpose :
		Read a BMP file to a HBITMAP.

	Param				Type			Use
	fileName			const char *	path to open for reading

	modifies global error value, check with ImgDLLGetLastError()

	Return
		HBITMAP - the new bitmap!
		
		be sure to call DeleteObject(..) on this when you're done!

***************************************************************/

HBITMAP IMGEXP ImgDLLReadHBITMAPFromBMP(const char * fileName);


/***************************************************************

	BOOL IMGEXP ImgDLLGetJPGDimensions(...)

	Purpose :
		Query a JPG file for image dimensions.

		Because this will also fill the global JPG text buffers. You can
	use this function to fetch the JPEG_COM text without reading the
	pixel data.

		A JPG file may contain any number text fields (JPEG_COM markers).
	These strings can be any length. When ImgDLL reads a JPG file, 
	it stores these strings in the ImgDLL JPG text buffer. These 
	strings remain valid until :

		1) the next JPG file is read
		2) ImgDLLClearJPGInputText is called

	Param				Type				Use
	fileName			const char *	path to open for reading
	width				UINT32*			width, in pixels
	height			UINT32*			height, in pixels

	modifies global error value, check with	ImgDLLGetLastError()

	Return
		TRUE on success

***************************************************************/


BOOL IMGEXP ImgDLLGetJPGDimensions(const char * fileName,
							UINT32 *width,
							UINT32 *height);

/***************************************************************

	BOOL IMGEXP ImgDLLGetPNGDimensions(...)

	Purpose :
		Query a PNG file for image dimensions

	Param               Type            Use
	fileName            const char *    path to open for reading
	width               UINT32*           width, in pixels                                             
	height              UINT32*           height, in pixels

	modifies global error value, check with ImgDLLGetLastError()

	Return
      TRUE on success

***************************************************************/

BOOL IMGEXP ImgDLLGetPNGDimensions(const char * fileName,
                            UINT32 *width,
                            UINT32 *height);

/***************************************************************

	BOOL IMGEXP ImgDLLGetBMPDimensions(...)

	Purpose :
		Query a BMP file for image dimensions

	Param				Type			Use
	fileName			const char *	path to open for reading
	width				UINT32*			width, in pixels
	height				UINT32*			height, in pixels

	modifies global error value, check with	ImgDLLGetLastError()

	Return
		TRUE on success

***************************************************************/

BOOL IMGEXP ImgDLLGetBMPDimensions(const char * fileName,
							UINT32 *width,
							UINT32 *height);

/***************************************************************

	BOOL IMGEXP ImgDLLGetTIFFDimensions(...)

	Purpose :
		Query a TIFF file for image dimensions

	Param				Type			Use
	fileName			const char *	path to open for reading
	width				UINT32*			width, in pixels
	height				UINT32*			height, in pixels

	modifies global error value, check with ImgDLLGetLastError()

	Return
		TRUE on success

***************************************************************/

BOOL IMGEXP ImgDLLGetTIFFDimensions(const char * fileName,
							UINT32 *width,
							UINT32 *height);

/***************************************************************

	BOOL IMGEXP ImgDLLGetPCXDimensions(...)

	Purpose :
		Query a PCX file for image dimensions

	Param				Type			Use
	fileName			const char *	path to open for reading
	width				UINT32*			width, in pixels
	height				UINT32*			height, in pixels

	modifies global error value, check with ImgDLLGetLastError()

	Return
		TRUE on success

***************************************************************/

BOOL IMGEXP ImgDLLGetPCXDimensions(const char * fileName,
							UINT32 *width,
							UINT32 *height);

/***************************************************************

	HGLOBAL IMGEXP ImgDLLRGBFromDWORDAligned(...)

	Purpose :
		Create a packed RGB buffer from a DWORD aligned buffer

	Param				Type			Use
	inBuf				BYTE *			input buffer
	uWidthPix			UINT32			width, in pixels
	uWidthBytes			UINT32			width, in bytes	of input buffer
	uHeight				UINT32			height, in pixels

	** does not use callback 

	modifies global error value, check with	ImgDLLGetLastError()

	Return
		HGLOBAL to the buffer
		Caller must use GlobalUnlock to get a ptr to this buffer!
		Caller is responsible for calling GlobalFree on this buffer!

***************************************************************/


HGLOBAL IMGEXP ImgDLLRGBFromDWORDAligned(BYTE *inBuf,
									UINT32 widthPix,
								 	UINT32 widthBytes,
									UINT32 height);

/***************************************************************

	HGLOBAL IMGEXP ImgDLLDWORDAlignBuf(...)

	Purpose :
		Create a DWORD-aligned buffer from a packed RGB buffer

	Param				Type			Use
	dataBuf			BYTE *		input buffer
	WidthPix			UINT32			width, in pixels
	height			UINT32			height 
	uiOutWidthBytes UINT32 *		width, in bytes, of new buffer

	** does not use callback 

	modifies global error value, check with	ImgDLLGetLastError()

	Return
		HGLOBAL to the buffer
		Caller must use GlobalUnlock to get a ptr to this buffer!
		Caller is responsible for calling GlobalFree on this buffer!

***************************************************************/

HGLOBAL IMGEXP ImgDLLDWORDAlignBuf(BYTE *dataBuf,
									 UINT32 widthPix,		// pixels!!
									 UINT32 height,
									 UINT32 *uiOutWidthBytes);

/***************************************************************

	HGLOBAL IMGEXP ImgDLLDWORDAlignBufBytes(...)

	Purpose :
		Create a DWORD-aligned buffer from a buffer

	Param				Type			Use
	dataBuf				BYTE *	input buffer
	WidthBytes			UINT32		width, in bytes
	height				UINT32		height 
	uiOutWidthBytes	UINT32 *	width, in bytes, of new buffer

	** does not use callback 

	modifies global error value, check with	ImgDLLGetLastError()

	Return
		HGLOBAL to the buffer
		Caller must use GlobalUnlock to get a ptr to this buffer!
		Caller is responsible for calling GlobalFree on this buffer!

***************************************************************/

HGLOBAL IMGEXP ImgDLLDWORDAlignBufBytes(BYTE *dataBuf,
									 UINT32 widthBytes,		// bytes!!
									 UINT32 height,
									 UINT32 *uiOutWidthBytes);// bytes!!!

/***************************************************************

	BOOL IMGEXP ImgDLLVerticalFlipBuf(...)

	Purpose :
		Vertically flip buffer

	Param				Type			Use
	inbuf				BYTE *		input buffer
	widthBytes		UINT32		width, in BYTEs (!!!)
	height			UINT32		height 

	modifies global error value, check with ImgDLLGetLastError()

	Return
		TRUE on success

***************************************************************/

BOOL IMGEXP ImgDLLVerticalFlipBuf(BYTE  * inbuf, 
											UINT32 widthBytes, 
											UINT32 height);

/***************************************************************

	BOOL IMGEXP ImgDLLBGRFromRGB(...)

	Purpose :
		Swap red and blue values in a buffer

	Param				Type				Use
	dataBuf			BYTE *			buffer
	WidthPix			UINT32			width, in pixels
	height			UINT32			height 

	modifies global error value, check with	ImgDLLGetLastError()

  ** does not use callback 

	Return
		TRUE on success

***************************************************************/

BOOL IMGEXP ImgDLLBGRFromRGB(BYTE *buf, UINT32 widthPix, UINT32 height);

/***************************************************************

	BOOL IMGEXP ImgDLLSetAlphaChannelToImage(...)

	Purpose :
		Fill in the bytes of the alpha channel in an RGBA image.

	Param				Type				Use
	destRGBA			BYTE *			32-bit RGBA image to receive new alpha data
	w					UINT32			width in pixels
	h					UINT32			height
	alphaImage		BYTE *			8-bit image that will become the alpha channel

	** does not use callback 

	modifies global error value, check with ImgDLLGetLastError()

	Return
		FALSE on failure

***************************************************************/

BOOL IMGEXP ImgDLLSetAlphaChannelToImage(BYTE *destRGBA,
										UINT32 w,
										UINT32 h,
										BYTE *alphaImage);

/***************************************************************

	HGLOBAL IMGEXP  ImgDLLRGBAFromRGB24(...)

	Purpose :
		Given a 24-bit RGB image, create a 32-bit RGBA image.
	The alpha channel will be set to defAlpha.

	Param			Type			Use
	inBuf			BYTE *		24-bit RGB image
	widthPix		UINT32		width in pixels
	height		UINT32		height
	defAlpha		BYTE 			default value for all aplha BYTEs

	** does not use callback 

	modifies global error value, check with	ImgDLLGetLastError()

	Return
		HGLOBAL to new buffer
		Caller must use GlobalUnlock to get a ptr to this buffer!
		Caller is responsible for calling GlobalFree on this buffer!

***************************************************************/

HGLOBAL IMGEXP ImgDLLRGBAFromRGB24(BYTE *inBuf,
							UINT32 widthPix,
							UINT32 height,
							BYTE defAlpha);

/***************************************************************

	BOOL IMGEXP ImgDLLMake8BitGrayScale(...)

	Purpose :
		convert RGB to 8-bir grayscale uses luminance formula.

	Param				Type			Use
	inBuf				BYTE *			input RGB buffer
	widthPix			UINT32			width, in pixels
	height				UINT32			height 
	outBuf				BYTE *			output 8-bit buffer

	modifies global error value, check with	ImgDLLGetLastError()

	Return
		TRUE on success

***************************************************************/

BOOL IMGEXP ImgDLLMake8BitGrayScale(BYTE *inBuf, 
									UINT32 widthPix, 
									UINT32 height, 
									BYTE *outBuf);

/***************************************************************

	BOOL IMGEXP ImgDLLMakeGrayScale(...)

	Purpose :
		convert RGB to GGG (all three bytes the same). 
	uses luminance formula.

	Param				Type				Use
	dataBuf			BYTE *			buffer
	WidthPix			UINT32			width, in pixels
	height			UINT32			height 

	modifies global error value, check with	ImgDLLGetLastError()

	Return
		TRUE on success

***************************************************************/

BOOL IMGEXP ImgDLLMakeGrayScale(BYTE *buf, UINT32 widthPix, UINT32 height);

/***************************************************************

	BOOL IMGEXP ImgDLLHorizontalFlipRGB(...)

	Purpose :
		Horizontally flip a buffer of RGB pixels

	Param				Type				Use
	dataBuf			BYTE *			input buffer
	widthPix			UINT32			width, in pixels
	height			UINT32			height 

	modifies global error value, check with	ImgDLLGetLastError()

	Return
		HGLOBAL to the buffer
		Caller must use GlobalUnlock to get a ptr to this buffer!
		Caller is responsible for calling GlobalFree on this buffer!

***************************************************************/

BOOL IMGEXP ImgDLLHorizontalFlipRGB(BYTE  * inbuf, 
									   UINT32 widthPix, 
									   UINT32 height);

/***************************************************************

	BOOL IMGEXP ImgDLLResizeRGB2(...)

	Purpose :
		given an RGB image, resize it to the dimensions specified.

   caller supplies the output buffer. (outWidth * outHeight * 3 pixels)

	Param				Type				Use
	rgbIn				BYTE *			24-bit RGB image data
	inWidth			UINT32			input width
	inHeight			UINT32			input height
	rgbOut			BYTE *			buffer to receive image
	outWidth			UINT32			output height
	outHeight		UINT32			output width

	modifies global error value, check with	ImgDLLGetLastError()

	Return
		FALSE on failure

***************************************************************/

BOOL IMGEXP ImgDLLResizeRGB2(BYTE * rgbIn,
							UINT32 inWidth,
							UINT32 inHeight,
							BYTE *rgbOut,
							UINT32 outWidth,
							UINT32 outHeight);

/***************************************************************

	HGLOBAL IMGEXP ImgDLLResizeRGB(...)

	Purpose :
		given an RGB image, resize it to the dimensions specified.
	returns a handle to the new image.

	Param				Type			Use
	rgbIn				BYTE *		24-bit RGB image data
	inWidth			UINT32		input width
	inHeight			UINT32		input height
	outWidth			UINT32		output height
	outHeight		UINT32		output width

	modifies global error value, check with	ImgDLLGetLastError()

	Return
		NULL on failure

***************************************************************/

HGLOBAL IMGEXP ImgDLLResizeRGB(BYTE * rgbIn,
							UINT32 inWidth,
							UINT32 inHeight,
							UINT32 outWidth,
							UINT32 outHeight);

/***************************************************************

	BOOL IMGEXP ImgDLLResizeRGBMasked(...)

	Purpose :
		given an RGB image, resize it to the dimensions specified. do not 
	perform pixel interpolation on the mask color. this will preserve
	sharp edges on a single color in the image.

	Param				Type			Use
	rgbIn				BYTE *			24-bit RGB image data
	inWidth			UINT32			input width
	inHeight			UINT32			input height
	rgbOut			BYTE *			buffer to receive image
	outWidth			UINT32			output height
	outHeight		UINT32			output width
	clrMask			COLORREF			color to mask

	modifies global error value, check with ImgDLLGetLastError()

	Return
		FALSE on failure

***************************************************************/

BOOL IMGEXP ImgDLLResizeRGBMasked(BYTE * rgbIn,
												UINT32 inWidth,
												UINT32 inHeight,
												BYTE *rgbOut,
												UINT32 outWidth,
												UINT32 outHeight,
												COLORREF clrMask);

/***************************************************************

	HGLOBAL IMGEXP ImgDLLDecimateRGB(...)

	Purpose :
		given an RGB image, resize it to the dimensions specified.
		return a handle to the new image.
		This uses a different algorithm than ResizeRGB. This is a
		pixel averaging algorithm which can produce better images than
		ResizeRGB. This works only when reducing images. 

		** This will not enlarge images **

	Param           Type					Use
	rgbIn           BYTE *				24-bit RGB image data
	inWidth         UINT32				input width         ( > output width )
	inHeight        UINT32				input height        ( > output height )
	outWidth        UINT32				output height
	outHeight       UINT32				output width

	modifies global error value, check with ImgDLLGetLastError()

	Return
		NULL on failure

***************************************************************/

HGLOBAL IMGEXP ImgDLLDecimateRGB(BYTE * rgbIn,
                            UINT32 inWidth,
                            UINT32 inHeight,
                            UINT32 outWidth,
                            UINT32 outHeight);

/***************************************************************

	BOOL IMGEXP ImgDLLResizeRGB2(...)

	Purpose :
		given an RGB image, resize it to the dimensions specified.
	the caller supplies the output buffer (outWidth * outHeight * 3 pixels)

		This uses a different algorithm than ResizeRGB. This is a
	pixel averaging algorithm which can produce better image than
	ResizeRGB. This works only when reducing images. 

		** This will not enlarge images **

	Param 			 Type 			Use
	rgbIn 			 BYTE *			24-bit RGB image data
	inWidth			 UINT32			input width
	inHeight 		 UINT32			input height
	rgbOut			 BYTE *			buffer to receive image
	outWidth 		 UINT32			output height
	outHeight		 UINT32			output width

	modifies global error value, check with ImgDLLGetLastError()

	Return
		NULL on failure

***************************************************************/

BOOL IMGEXP ImgDLLDecimateRGB2(BYTE * rgbIn,
                              UINT32 inWidth,
                              UINT32 inHeight,
                              BYTE *rgbOut,
                              UINT32 outWidth,
                              UINT32 outHeight);

/***************************************************************

	BOOL IMGEXP ImgDLLSharpenRGB(...)

	Purpose :
		sharpen an RGB buffer into a different RGB buffer. 3 x 3 matrix

		buffers must be the same size!!!

		rgbIn must not be the same as rgbOut !!!

	Param				Type				Use
	rgbIn				BYTE *			24-bit RGB image data
	rgbOut			BYTE *			24-bit RGB image data
	widhtPix			UINT32			width in pixels
	height			UINT32			height
	sharpLevel		UINT32			0..100 sharpening intensity

	modifies global error value, check with	ImgDLLGetLastError()

	Return
		NULL on failure

***************************************************************/

BOOL IMGEXP ImgDLLSharpenRGB(BYTE * rgbIn,
							BYTE * rgbOut,
							UINT32 widthPix,
							UINT32 height,
							UINT32 sharpLevel);

/***************************************************************

	BOOL IMGEXP ImgDLLBlurRGB(...)

	Purpose :
		blur an RGB buffer into a different RGB buffer. 3 x 3 matrix

		buffers must be the same size!!!

		rgbIn must not be the same as rgbOut !!!

	Param				Type				Use
	rgbIn				BYTE *			24-bit RGB image data
	rgbOut			BYTE *			24-bit RGB image data
	widhtPix			UINT32			width in pixels
	height			UINT32			height
	blurLevel		UINT32			0..100 blur intensity

	modifies global error value, check with	ImgDLLGetLastError()

	Return
		NULL on failure

***************************************************************/

BOOL IMGEXP ImgDLLBlurRGB(BYTE * rgbIn,
							BYTE * rgbOut,
							UINT32 widthPix,
							UINT32 height,
							UINT32 blurLevel);

/***************************************************************

	BOOL IMGEXP ImgDLLMedianCutRGB();

	Purpose :
		perform median cut on an image, using a 3x3 matrix

		rgbIn must not be the same as rgbOut !!!

		rgbIn must be the same size as rgbOut !!

	Param				Type				Use
	rgbIn				BYTE *			24-bit RGB image data
	rgbOut			BYTE *			24-bit RGB image data
	widhtPix			UINT32			width in pixels
	height			UINT32			height

	modifies global error value, check with ImgDLLGetLastError()

	Return
		NULL on failure

***************************************************************/
BOOL IMGEXP ImgDLLMedianCutRGB(BYTE * rgbIn,
                            BYTE * rgbOut,
                            UINT32 widthPix,
                            UINT32 height);

/***************************************************************

	BOOL IMGEXP ImgDLLQuantizeRGBTo8Bit(...)

	Purpose :
		generate a palette and a dithered image with the specified
	number of colors.	

		The output buffer must be widthPix * height BYTEs !

		The output buffer is an 8-bit image. 

		Ex. If you ask for a 16-color image, the pixels will be 
	placed one-per-byte, even though there are only 4 significant 
	bits (2^4 = 16 colors) per pixel.

	Param				Type				Use
	inBuf				BYTE *			input image
	outBuf			BYTE *			output image
	widthPix			UINT32 			width
	height			UINT32 			height
	colors			UINT32			colors to reduce to	(1..256)
	pPal				RGBQUAD *		ptr to an array of RGBQUADs. 
											there must be at least "colors" 
											entries. this receives the
											new palette.

	** does not use callback

	modifies global error value, check with ImgDLLGetLastError()

	Return
		FALSE on failure

***************************************************************/

BOOL IMGEXP ImgDLLQuantizeRGBTo8Bit(BYTE *inBuf,
										BYTE *outBuf,
										UINT32 widthPix,
										UINT32 height,
										UINT32 colors,
										RGBQUAD *pPal);

/***************************************************************

  BOOL IMGEXP ImgDLLRGBTo8BitBestFit(...);

	Purpose :
		given an RGB image and a palette, use the Pythagorean
	distance formula to find the closest color in the palette 
	for each source pixel, generate an 8-bit image. this does 
	not dither the output image. 

	The output buffer must be widthPix * height BYTEs !

	The output buffer is an 8-bit image. 

	Param				Type			Use
	inBuf				BYTE *		input image
	outBuf			BYTE *		output image
	widthPix			UINT32 		width
	height			UINT32 		height
	colors			UINT32		colors in pPal
	pPal				RGBQUAD *	ptr to an array of RGBQUADs. 
										there must be at least "colors" 
										entries. this is an input palette.

	modifies global error value, check with ImgDLLGetLastError()

	Return
		FALSE on failure
***************************************************************/

BOOL IMGEXP ImgDLLRGBTo8BitBestFit(BYTE *pRGB,
										BYTE *p8Bit,
										UINT32 width,
										UINT32 height,
										UINT32 colors,
										RGBQUAD *pPal);

/***************************************************************

	BOOL IMGEXP ImgDLLGet8BitPalette(...)

	Purpose :
		generate a palette with the specified number of colors. does not
	generate an output image. does not affect the input image.

	this is an "optimal" palette that is identical to the one created 
	by ImgDLLQuantizeRGBTo8Bit . for images with < 256 colors, the colors 
	in this palette should exactly match the colors in the source image.

	Param				Type				Use
	inBuf				BYTE *			input image
	widthPix			UINT32 			width
	height			UINT32 			height
	colors			UINT32			colors to reduce to	(1..256)
	pPal				RGBQUAD *		ptr to an array of RGBQUADs. there must be at
											least "colors" entries. this receives the
											new palette.

	** does not use callback

	modifies global error value, check with	ImgDLLGetLastError()

	Return
		FALSE on failure

***************************************************************/

BOOL IMGEXP ImgDLLGet8BitPalette(BYTE *inbuf, 
									UINT32 nWidth, 
									UINT32 nHeight, 
									UINT32 nColors,
									RGBQUAD *pPal);

/***************************************************************

	BOOL IMGEXP ImgDLLRGBFrom8Bit(...)

	Purpose :
		apply a palette to an 8-bit image to generate an equivalent
	24-bit image.

	Param				Type			Use
	inBuf				BYTE *		input image
	outBuf			BYTE *		output image (widthPix * height * 3 BYTEs)
	widthPix			UINT32 		width
	height			UINT32 		height
	colors			UINT32		colors in palette
	pPal				RGBQUAD *	ptr to an array of RGBQUADs. there must be at
										least "colors" entries.

	modifies global error value, check with	ImgDLLGetLastError()

	Return
		FALSE on failure

***************************************************************/

BOOL IMGEXP ImgDLLRGBFrom8Bit(BYTE *inBuf,
								BYTE *outBuf,
								UINT32 widthPix,
								UINT32 height,
								UINT32 colors,
								RGBQUAD *pPal);

/***************************************************************

	HGLOBAL IMGEXP ImgDLLDIBToRGB2(...)

	Purpose :
		given a DIB, use the screen device driver to create an RGB buffer.

	Param				Type				Use
	inhBmp			BYTE *			BYTE ptr to DIB 
	width				UINT32 *			receives image width
	height			UINT32 *			receives image height

	modifies global error value, check with	ImgDLLGetLastError()

	Return
		NULL on failure

***************************************************************/

HGLOBAL IMGEXP ImgDLLDIBToRGB2(BYTE * pDIB,
								UINT32 *width, 
								UINT32 *height);

/***************************************************************

	HGLOBAL IMGEXP ImgDLLDIBToRGB(...)

	Purpose :
		given an image in DIB format, create a 24-bit RGB buffer

	use of this function is tricky at best. it is recommended that
	you use ImgDLLDIBToRGB2.

	Param			Type						Use
	inBuf			BYTE *					DI-Bits
	pBMI			BITMAPINFOHEADER *	a filled-in BMIH
	colorMap		RGBQUAD *				space large enough to hold a palette

	modifies global error value, check with ImgDLLGetLastError()

	Return
		TRUE on success

***************************************************************/

HGLOBAL IMGEXP ImgDLLDIBToRGB( BYTE * inBuf,
								BITMAPINFOHEADER *pBMI,
								RGBQUAD * colorMap);

/***************************************************************

	HGLOBAL IMGEXP ImgDLLRGBToDIB(...)

	Purpose :
		given a 24-bit RGB image, create a 24-bit DIB. 

	Param				Type				Use
	inBuf				BYTE *			RGB buffer
	widthPix			UINT32			buffer width in pixels
	height			UINT32			height

	modifies global error value, check with ImgDLLGetLastError()

	Return
		NULL on failure

***************************************************************/
HGLOBAL IMGEXP ImgDLLRGBToDIB( BYTE * inBuf,
								UINT32 widthPix,
								UINT32 height);

/***************************************************************

	HGLOBAL IMGEXP ImgDLLHBITMAPToRGB(...)

	Purpose :
		given an HBITMAP create an RGB buffer, using the 
	screen device driver.

	Param				Type			Use
	inhBmp			HBITMAP		handle to bitmap
	width				UINT32 *		width
	height			UINT32 *		height
	hPal				HPALETTE		palette to use in rendering the image.
										if NULL, the system palette is used

	** does not use callback

	modifies global error value, check with	ImgDLLGetLastError()

	Return
		NULL on failure

***************************************************************/

HGLOBAL IMGEXP ImgDLLHBITMAPToRGB(HBITMAP inhBmp, 
								  UINT32 *width, 
								  UINT32 *height,
								  HPALETTE hPal);

/***************************************************************

	HBITMAP IMGEXP ImgDLLRGBToHBITMAP(...)

	Purpose :
		given a 24-bit RGB image, create an HBITMAP. 

	if hPal is non-NULL and the display is at <= 256 colors, 
	hPal is used to render the image. if NULL and display is <= 
	256 colors, the system palette will be used instead.

	Param				Type				Use
	inBuf				BYTE *			RGB buffer
	widthPix			UINT32			buffer width in pixels
	height			UINT32			height
	hPal				HPALETTE			palette

   ** does not use callback

	modifies global error value, check with	ImgDLLGetLastError()

	Return
		NULL on failure

***************************************************************/

HBITMAP IMGEXP ImgDLLRGBToHBITMAP( BYTE * inBuf,
								UINT32 widthPix,
								UINT32 height,
								HPALETTE hPal);

/***************************************************************

	HGLOBAL IMGEXP ImgDLLDCToRGB(...)

	Purpose :
		Copy a rectangle of pixels in the given HDC to an RGB buffer.

	RGB buffer dimensions are  (uWidth - uXStart) x (uHeight - uYStart)

	The device referred to by hDC must support the following RASTERCAPS
	values : 
		RC_BITBLT
		RC_BITMAP64
		RC_DI_BITMAP

	Param				Type			Use
	hDC				HDC			input DC
	uXStart			UINT32		left side of the pixel rect
	uYStart			UINT32		top of the pixel rect
	uWidth			UINT32		width of the pixel rect
	uHeight			UINT32		height of the pixel rect

   ** does not use callback

	modifies global error value, check with ImgDLLGetLastError()

	Return
		NULL on failure

***************************************************************/

HGLOBAL IMGEXP ImgDLLDCToRGB(HDC hDC,
								UINT32 uXStart,
								UINT32 uYStart,
								UINT32 uWidth,
								UINT32 uHeight);

/***************************************************************

	BOOL IMGEXP ImgDLLDrawHBITMAP(...)

	Purpose :
		given an HBITMAP and an HDC, draw the image to the DC. this
	is just a quick way to do the usual CreateCompatibleDC, SelectObject,
	BitBlt stuff.

	The device referred to by hDC must support the following RASTERCAPS
	values : 
		RC_BITBLT
		RC_BITMAP64

	Param				Type			Use
	outHDC			HDC			device context to draw into
	hBmp				HBITMAP		handle to bitmap
	xPos				__int32		X position in DC to draw at
	yPos				__int32		Y position in DC to draw at
	outWidth			UINT32 		width of dest rect
	outHeight		UINT32 		height of dest rect
	hPal				HPALETTE		palette to use in rendering the image.
										if NULL, the system palette is used

   ** does not use callback

	modifies global error value, check with	ImgDLLGetLastError()

	Return
		FALSE on failure

***************************************************************/

BOOL IMGEXP ImgDLLDrawHBITMAP(HDC outHDC, 
								HBITMAP hBmp,
								__int32 xPos,
								__int32 yPos,
								UINT32 outWidth,
								UINT32 outHeight,
								HPALETTE hPal);

/***************************************************************

	BOOL IMGEXP ImgDLLDrawHBITMAPCrop(...)

	Purpose :
		given an HBITMAP and an HDC, draw the image to the DC. this
	is just a quick way to do the usual CreateCompatibleDC, SelectObject,
	BitBlt stuff.

	The device referred to by hDC must support the following RASTERCAPS
	values : 
		RC_BITBLT
		RC_BITMAP64

		the srcXStart and srcYStart params, along with the outWidth and 
	outHeight params allow you to specify a rect from the source HBITMAP to
	use for drawing. this allows you to draw a portion of the HBITMAP at a time.

	Param				Type			Use
	outHDC				HDC		device context to draw into
	hBmp				HBITMAP		handle to bitmap
	xPos				__int32		X position in DC to draw to
	yPos				__int32		Y position in DC to draw to
	srcXStart		UINT32		X position in source to start drawing from
	srcYStart		UINT32		Y position in source to start drawing from
	outWidth			UINT32 		width of dest rect (also X pixels in source to copy)
	outHeight		UINT32 		height of dest rect (also Y pixels in source to copy)
	hPal				HPALETTE		palette to use in rendering the image.
										if NULL, the system palette is used

   ** does not use callback

	modifies global error value, check with ImgDLLGetLastError()

	Return
		FALSE on failure

***************************************************************/

BOOL IMGEXP ImgDLLDrawHBITMAPCrop(HDC outDC, 
								HBITMAP hBmp,
								__int32 xPos,
								__int32 yPos,
								UINT32 outXStart,
								UINT32 outYStart,
								UINT32 outWidth,
								UINT32 outHeight,
								HPALETTE hPal);

/***************************************************************

	BOOL IMGEXP ImgDLLDrawRGB(...)

	Purpose :

		given a 24-bit RGB image and an HDC, draw the image to the DC.
	this call wraps a call to ImgDLLRGBToHBITMAP and a call 
	to ImgDLLDrawRGB

	NOTE : Not all devices will support the calls necessary for this
	to work. Printer DCs are likely to not work with this call.

	The device referred to by hDC must support the following RASTERCAPS
	values : 
		RC_DI_BITMAP
		RC_BITBLT
		RC_BITMAP64

	Param				Type			Use
	outHDC			HDC				device context to draw into
	pRGB				BYTE *			RGB (24-bit) image
	inWidth			UINT32			width of RGB image
	inHeight			UINT32			height of RGB image
	xPos				__int32				X position in DC to draw at
	yPos				__int32				Y position in DC to draw at
	outWidth			UINT32 			width of dest rect
	outHeight		UINT32 			height of dest rect
	hPal				HPALETTE		palette to use in rendering the image.
										if NULL, the system palette is used

   ** does not use callback

	modifies global error value, check with	ImgDLLGetLastError()

	Return
		FALSE on failure

***************************************************************/

BOOL IMGEXP ImgDLLDrawRGB(HDC outDC,
							BYTE *pRGB,
							UINT32 inWidth,
							UINT32 inHeight,
							__int32 xPos,
							__int32 yPos,
							UINT32 outWidth,
							UINT32 outHeight,
							HPALETTE hPal);

/***************************************************************

	BOOL IMGEXP ImgDLLDrawRGB2(...)

	Purpose :
		given a 24-bit RGB image and an HDC, draw the image to the DC.
	this uses StretchDIBBits. 

	this is 20-30 % faster than ImgDLLDrawRGB(), but it can't
	use a palette.

	NOTE: using this function, an output size different than the
	input size results in a scaled image. the scaling operation
	produces images which are acceptable for most purposes, but
	are not as good as you would get from using ResizeRGB.

	this is different behavior than ImgDLLDrawRGB, which clips 
	the image, if necessary.

	NOTE : Not all devices will support the calls necessary for this
	to work. Printer DCs are likely to not work with this call.

	The device referred to by hDC must support the following RASTERCAPS
	values : 
		RC_STRETCHDIB

   Param				Type			Use
	outHDC			HDC			device context to draw into
	pRGB				BYTE *		RGB (24-bit) image
	inWidth			UINT32		width of RGB image
	inHeight			UINT32		height of RGB image
	xPos				__int32		X position in DC to draw at
	yPos				__int32		Y position in DC to draw at
	outWidth			UINT32 		width of dest rect
	outHeight		UINT32 		height of dest rect

	** does not use callback

	modifies global error value, check with ImgDLLGetLastError()

	Return
		NULL on failure

***************************************************************/

BOOL IMGEXP ImgDLLDrawRGB2(HDC outDC,
							BYTE *pRGB,
							UINT32 inWidth,
							UINT32 inHeight,
							__int32 xPos,
							__int32 yPos,
							UINT32 outWidth,
							UINT32 outHeight);

/***************************************************************

	BOOL IMGEXP ImgDLLDrawRGBCrop(...)

	Purpose :
		given an HBITMAP and an HDC, draw the image to the DC

		the srcXStart and srcYStart params, along with the outWidth and 
	outHeight params allow you to specify a rect from the source HBITMAP to
	use for drawing. this allows you to draw a portion of the HBITMAP at a time.

	The device referred to by hDC must support the following RASTERCAPS
	values : 
		RC_DI_BITMAP
		RC_BITBLT
		RC_BITMAP64

	Param				Type			Use
	outHDC			HDC			device context to draw into
	pRGB				BYTE *		RGB (24-bit) image
	inWidth			UINT32		width of RGB image
	inHeight			UINT32		height of RGB image
	xPos				__int32		X position in DC to draw at
	yPos				__int32		Y position in DC to draw at
	srcXStart		UINT32 		X position in image to start drawing from
	srcYStart		UINT32 		Y position in image to start drawing from
	outWidth			UINT32 		width of dest rect
	outHeight		UINT32 		height of dest rect
	hPal				HPALETTE		palette to use in rendering the image.
										if NULL, the system palette is used

	modifies global error value, check with ImgDLLGetLastError()

	Return
		NULL on failure

***************************************************************/

BOOL IMGEXP ImgDLLDrawRGBCrop(HDC outDC,
											BYTE *pRGB,
											UINT32 inWidth,
											UINT32 inHeight,
											__int32 xPos,
											__int32 yPos,
											UINT32 srcXStart,
											UINT32 srcYStart,
											UINT32 outWidth,
											UINT32 outHeight,
											HPALETTE hPal);

/***************************************************************

	BOOL IMGEXP ImgDLLDrawRGB2Crop(...)

	Purpose :
		given an RGB image and an HDC, draw the image to the DC.
	this uses StretchDIBBits. 

	this should be 20-30 % faster than ImgDLLDrawRGBCrop(), but it can't
	use a palette.

		the srcXStart and srcYStart params, along with the outWIdth and 
	outHeight params allow you to specify a rect from the source image to
	use for drawing. this allows you to draw a portion of the image at a time.

	NOTE : Not all devices will support the calls necessary for this
	to work. Printer DCs are likely to not work with this call.

	The device referred to by hDC must support the following RASTERCAPS
	values : 
		RC_STRETCHDIB

   Param				Type			Use
	outHDC			HDC			device context to draw into
	pRGB				BYTE *		RGB (24-bit) image
	inWidth			UINT32		width of RGB image
	inHeight			UINT32		height of RGB image
	xPos				__int32		X position in DC to draw at
	yPos				__int32		Y position in DC to draw at
	srcXStart		UINT32 		X position in image to start drawing from
	srcYStart		UINT32 		Y position in image to start drawing from
	outWidth			UINT32 		width of dest rect
	outHeight		UINT32 		height of dest rect

	** does not use callback

	modifies global error value, check with	ImgDLLGetLastError()

	Return
		NULL on failure

***************************************************************/

BOOL IMGEXP ImgDLLDrawRGB2Crop(HDC outDC,
										BYTE *pRGB,
										UINT32 inWidth,
										UINT32 inHeight,
										__int32 xPos,
										__int32 yPos,
										UINT32 srcXStart,
										UINT32 srcYStart,
										UINT32 outWidth,
										UINT32 outHeight);

/***************************************************************

	BOOL IMGEXP ImgDLLDrawTransparentHBITMAP(...)

	Description:
	Draws a bitmap with one color "transparent"

	Code taken almost exactly from Microsoft Developer's Network
	October 1995.

	NOTE : Not all devices will support the calls necessary for this
	to work. Printer DCs are likely to not work with this call.

	The device referred to by hDC must support the following RASTERCAPS
	values : 
		RC_BITBLT
		RC_BITMAP64

	Parameter			Type				Use
	hdc					HDC				handle to a DC to draw into
	hBitmap				HBITMAP			handle to a BMP
	xPos					__int32			xpos
	ypos					__int32			ypos
	cTransparentColor	COLORRREF		color to use as trasparent

	** does not use callback

	return - TRUE on success

***************************************************************/

BOOL IMGEXP ImgDLLDrawTransparentHBITMAP(HDC outDC, 
								HBITMAP hBmp,
								__int32 xPos,
								__int32 yPos,
								COLORREF cTransparentColor);

/***************************************************************

	BOOL IMGEXP ImgDLLDrawTranparentRGB(...)

	Purpose :
		given an RGB image and an HDC, draw the image to the DC with
	one color transparent. this call wraps a call to ImgDLLRGBToHBITMAP 
	and a call to ImgDLLDrawTransparentHBITMAP

	NOTE : Not all devices will support the calls necessary for this
	to work. Printer DCs are likely to not work with this call.

	The device referred to by hDC must support the following RASTERCAPS
	values : 
		RC_DI_BITMAP
		RC_BITBLT
		RC_BITMAP64

	Param					Type			Use
	outHDC				HDC			device context to draw into
	pRGB					BYTE *		RGB (24-bit) image
	inWidth				UINT32		width of RGB image
	inHeight				UINT32		height of RGB image
	xPos					__int32		X position in DC to draw at
	yPos					__int32		Y position in DC to draw at
	cTransparentColor	COLORREF	color to use as trasparent

   ** does not use callback

	modifies global error value, check with ImgDLLGetLastError()

	Return
		NULL on failure

***************************************************************/

BOOL IMGEXP ImgDLLDrawTranparentRGB(HDC outDC,
												BYTE *pRGB,
												UINT32 inWidth,
												UINT32 inHeight,
												__int32 xPos,
												__int32 yPos,
												COLORREF cTransparentColor);

/***************************************************************

	HBITMAP IMGEXP ImgDLLLoadResourceBMP(...)

	use ImgDLLLoadResourceBMP, instead of CBitmap::LoadBitmap!

	on 8-bit displays, LoadBitmap maps the bitmap to the 16-colors
	of the standard Windows palette - this is no good. you don't even
	get a chance to use a palette on the image because LoadBitmap mangles
	the color info!! yuck!!

	if you use this function, with a palette that represents a
  spread of colors from the image, or even just a nice spread of
	colors all across the spectrum, you'll get much better results.
	trust me. 
	
	if you use a NULL palette, this function will use a 
	set of colors from the system palette, which will give slightly
	better results than LoadBitmap.

	Param			Type			Use
	hInstance	HINSTANCE	app instance to find a resource in
	lpString		LPCSTR		resource name, or ID
	hInPalette	HPALETTE		palette to map the bitmap through, may be NULL

	returns an HBITMAP, else NULL

   ** does not use callback

	be sure to call DeleteObject(..) on this when you're done!

***************************************************************/

HBITMAP IMGEXP ImgDLLLoadResourceBMP(HINSTANCE hInstance,
												LPCSTR lpString, 
												HPALETTE hInPalette);

/***************************************************************

	BOOL IMGEXP ImgDLLApplyMatrixToRGB(...)

	Purpose :
		apply a convolution matrix to an RGB image.

		buffers must be the same size!!!
		rgbIn must not be the same as rgbOut !!!

		the matrix is an array of _9_ doubles, arranged as :

			0  1  2
			3  4  5
			6  7  8

			where "4" is the source pixel.

		it is applied for pixel(x,y) as :

			double tempSum = (
			pMatrix[0] * pixel(x-1, y-1) +
			pMatrix[1] * pixel(x,   y-1) +
			pMatrix[2] * pixel(x+1, y-1) +
			pMatrix[3] * pixel(x-1, y )  +
			pMatrix[4] * pixel(x,   y )  +
			pMatrix[5] * pixel(x+1, y )  +
			pMatrix[6] * pixel(x-1, y+1) +
			pMatrix[7] * pixel(x,   y+1) +
			pMatrix[8] * pixel(x+1, y+1));		// step 1

			tempSum = tempSum * dLevel;			// step 2
			tempSum = min(tempSum, 255);		// step 3
			tempSum = max(tempSum, 0);			// step 4

			outval = (BYTE) tempSum;			// step 5

	bDoFeedback
		if the bDoFeedback options is TRUE, step 2 becomes :

			tempSum = pixel(x,y) * (1.0 - dLevel) + (dLevel * tempSum);


	channelMask
		if the CHRED bit is set in channelMask, the matrix is
		applied to all red pixels.
	
		if the CHGREEN bit is set in channelMask, the matrix is
		applied to all green pixels.

		if the CHBLUE bit is set in channelMask, the matrix is
		applied to all blue pixels.

	zero
		if zero is TRUE, the input channels excluded by the channelMask
		will have all values set to zero.
		if zero is FALSE, the input channels excluded by the channelMask
		will retain the values from the source image.


	Param				Type			Use
	rgbIn				BYTE *		24-bit RGB image data
	rgbOut			BYTE *		24-bit RGB image data allocated by caller
	widhtPix			UINT32		width in pixels
	height			UINT32		height
	channelMask		BYTE			controls which channels are to be modified
										CHRED | CHGREEN | CHBLUE
	zero				BOOL			controls channels excluded by channelMask
	bDoFeedback		BOOL			controls arithmetic
	dLevel			double		multiplier
	pMatrix			double *		3 x 3 matrix to apply.

	modifies global error value, check with	ImgDLLGetLastError()

	Return
		FALSE on failure

***************************************************************/

BOOL IMGEXP ImgDLLApplyMatrixToRGB(BYTE * rgbIn,
							BYTE * rgbOut,
							UINT32 widthPix,
							UINT32 height,
							BYTE channelMask,
							BOOL zero,
							BOOL bDoFeedback,
							double dLevel,
							double *pMatrix);


/***************************************************************

	BOOL IMGEXP ImgDLLApplyConvolutionFilter(...)

	Purpose :
		apply a convolution filter/matrix to an RGB image.

		buffers must be the same size!!!
		rgbIn must not be the same as rgbOut !!!

		the number of columns and the number of rows in the matrix
		must both be odd!

		it is applied as follows :

			M = matrix ( 3x3, in this example)
		
             1  1  1
         M = 1 -8  1			this is a sharpening matrix
             1  1  1
		
			the matrix is centered on the current pixel. in this example, 
			M[4] is the center of the matrix.

			dLevel is a level 

			P = pixels . since the matrix is centered on the current pixel,
			P(x,y), the pixels used in this calculation will be :
				P(x-1,y-1),	P(x, y-1),	P(x+1, y-1)
				P(x-1,y),	P(x, y),	P(x+1, y)
				P(x-1,y+1),	P(x, y+1),	P(x+1, y+1)

			t = sum ( M[i] * P[i] )  [for all elements of the matrix]

			outPixel = curPixel - (dLevel * t)

		Matrix M in this example demonstrates the sharpening filter 
		used by this library.

		besides the ability to use matricies of arbitrary size, this function 
		differs from ImgDLLApplyMatrixToRGB in the way the final caluclation 
		is performed. 

	Param				Type			Use
	rgbIn				BYTE *		24-bit RGB image data
	rgbOut			BYTE *		24-bit RGB image data allocated by caller
	widhtPix			UINT32		width of image in pixels
	height			UINT32		height of image
	matrixCols		UINT32		width of matrix, must be an odd number
	matrixRows		UINT32		height of matrix, must be an odd number
	dLevel			double		multiplier
	pMatrix			double *		matrix to apply . be sure you have 
										matrixCols x matrixRows elements!!

	modifies global error value, check with	ImgDLLGetLastError()

	Return
		FALSE on failure

***************************************************************/

BOOL IMGEXP ImgDLLApplyConvolutionFilter(BYTE * rgbIn,
											BYTE * rgbOut,
											UINT32 widthPix,
											UINT32 height,
											UINT32 matrixCols,
											UINT32 matrixRows,
											double dLevel,
											double *pMatrix);

/***************************************************************

	BOOL IMGEXP ImgDLLApplyLUTToRGB(...)

	Purpose :
		Apply a Look Up Table (LUT) to an RGB image.
	
	For each channel in each pixel the following function is
	performed :
		
		v = Val[pixel][channel]
		v' = LUT[v]
		v = v'

	Param				Type			Use
	rgbBuf			BYTE *		buffer to apply LUT to
	widthPix			UINT32		width
	height			UINT32		height
	channelMask		BYTE			control which channels are modified
										CHRED | CHGREEN | CHBLUE
	pLUT				BYTE			array of 256 BYTE values (0...255)

	modifies global error value, check with	ImgDLLGetLastError()

	Return
		FALSE on failure

***************************************************************/

BOOL IMGEXP ImgDLLApplyLUTToRGB(BYTE *rgbBuf,
								   UINT32 widthPix,
								   UINT32 height,
								   BYTE channelMask,
								   BYTE *pLUT);


/***************************************************************

	BOOL IMGEXP ImgDLLHistogramEqualizeRGB(...)


	Purpose :
		Perform histogram equalization on an image.

	Param				Type			Use
	inBuf				BYTE *		buffer
	widthPix			UINT32		width, in pixels
	height			UINT32		height 
	loThresh			UINT32		0..255 low limit on candidate pixel values
	hiThresh			UINT32		0..255 hi limit on candidate pixel values. 
										must be < loThresh
	channelMask		BYTE			control which channels are modified
										CHRED | CHGREEN | CHBLUE

	modifies global error value, check with	ImgDLLGetLastError()

	Return
		TRUE on success

***************************************************************/

BOOL IMGEXP ImgDLLHistogramEqualizeRGB(BYTE *inBuf, 
								UINT32 widthPix, 
								UINT32 height,
								UINT32 loThresh,
								UINT32 hiThresh,
								BYTE channelMask);

/***************************************************************

	BOOL ImgDLLGetBrightnessHistogram(...)

	Purpose :
		Calculate the brightness/luminance histogram for an image.
	For 0..255, every pixel with a calculated luminance of "b" will
	increase the value of pHisto[b].

	Param				Type			Use
	inBuf				BYTE *		buffer
	widthPix			UINT32		width, in pixels
	height			UINT32		height 
	pHisto			__int32 *	array of 256 ints

	modifies global error value, check with	ImgDLLGetLastError()

	Return
		TRUE on success

***************************************************************/

BOOL IMGEXP ImgDLLGetBrightnessHistogram(BYTE *inBuf,
								UINT32 widthPix,
								UINT32 height,
								__int32 *pHisto);

/***************************************************************

	BOOL IMGEXP ImgDLLGetChannelHistogram(...)

	Purpose :
		Calculate the histogram for a single channel (R,G or B) in 
	an RGB image.
	Every pixel in the image with a value of "b" in the specified
	channel will increase the value of pHisto[b] by one.

	Param				Type			Use
	inBuf				BYTE *		buffer
	widthPix			UINT32		width, in pixels
	height			UINT32		height 
	chMask			BYTE			_one of_ CHRED, CHGREEN, CHBLUE
	pHisto			__int32 *	array of 256 ints

	modifies global error value, check with	ImgDLLGetLastError()

	Return
		TRUE on success

***************************************************************/

BOOL IMGEXP ImgDLLGetChannelHistogram(BYTE *inBuf,
										UINT32 widthPix,
										UINT32 height,
										BYTE chMask,
										__int32 *pHisto);

/***************************************************************

	HGLOBAL IMGEXP ImgDLLRotateRGB(...)


	Purpose :
		Rotate an RGB image by a number of radians.

	Param				Type			Use
	inBuf				BYTE *		input image
	widthPix			UINT32		width, in pixels
	height			UINT32		height 
	radians			double		0..2pi radians to rotate
	backColor		COLORREF		color to draw where there is no image
	outWidth			UINT32 *		output width
	outHeight		UINT32 *		output height

	modifies global error value, check with	ImgDLLGetLastError()

	Return
		HGLOBAL to a new image, else NULL on failure

***************************************************************/

HGLOBAL IMGEXP ImgDLLRotateRGB(BYTE *inBuf, 
								UINT32 widthPix, 
								UINT32 height,
								double radians,
								COLORREF backColor,
								UINT32 * outWidth,
								UINT32 *outHeight);

/***************************************************************

	BOOL IMGEXP ImgDLLQuickRotateRGB(...)


	Purpose :
		Rotate an RGB image 90, 180 or 270 degrees.
	This rotates the image in-place.

	Param				Type			Use
	inBuf				BYTE *		input image
	widthPix			UINT32		width, in pixels
	height			UINT32		height 
	rotationType	__int32		rotation type : 
										0 - 90 degrees cw
										1 - 180 deg
										2 - 270 deg cw

	modifies global error value, check with	ImgDLLGetLastError()

	Note : when rotating 90 or 270 degrees, width (rotated) = height (initial)
	and height (rotated) = width (initial). It is up to the caller to account 
	for this.

	Return
		BOOL - TRUE on success

***************************************************************/

BOOL IMGEXP ImgDLLQuickRotateRGB(BYTE *inBuf, 
											UINT32 widthPix, 
											UINT32 height,
											__int32 rotationType);

/***************************************************************

	HGLOBAL IMGEXP ImgDLLCropRGB(...)

	Purpose :
		Crop an image to the rectangle specified.

	Param				Type				Use
	inBuf				BYTE *			input image
	uInWidthPix		UINT32			width, in pixels
	uInHeight		UINT32			height 
	uLeft				UINT32			left edge of crop rect
	uTop				UINT32			top edge of crop rect
	uRight			UINT32			right edge...
	uBottom			UINT32			bottom edge

	uTop <= uBottom
	uLeft <= uRight

	uRight - uLeft < uInWidthPix
	uBottom - uTop < uInHeight

	modifies global error value, check with	ImgDLLGetLastError()

	Return
		HGLOBAL to a new image, else NULL on failure

***************************************************************/

HGLOBAL IMGEXP ImgDLLCropRGB(BYTE *inBuf,
						   UINT32 uInWidthPix,
						   UINT32 uInHeight,
						   UINT32 uLeft,
						   UINT32 uTop,
						   UINT32 uRight,
						   UINT32 uBottom);

/***************************************************************

	HGLOBAL IMGEXP ImgDLLZoomRGB(...)

	Purpose :
		Zoom into an image. Performed as a crop to the rectangle
	specified, then a resize to the output dimensions. This actually
	uses ImgDLLCropRGB and then ImgDLLResizeRGB.

	Param				Type				Use
	inBuf				BYTE *			input image
	uInWidthPix		UINT32			width, in pixels
	uInHeight		UINT32			height 
	uLeft				UINT32			left edge of crop rect
	uTop				UINT32			top edge of crop rect
	uRight			UINT32			right edge...
	uBottom			UINT32			bottom edge
	uOutWidthPix	UINT32			width of output image (may be > uInWidthPix)
	uOutHeight		UINT32			height of output image (may be > uInHeight)

	uTop <= uBottom
	uLeft <= uRight

	uRight - uLeft < uInWidthPix
	uBottom - uTop < uInHeight

	modifies global error value, check with	ImgDLLGetLastError()

	Return
		HGLOBAL to a new image, else NULL on failure

***************************************************************/

HGLOBAL IMGEXP ImgDLLZoomRGB(BYTE *inBuf,
						   UINT32 uInWidthPix,
						   UINT32 uInHeight,
						   UINT32 uLeft,
						   UINT32 uTop,
						   UINT32 uRight,
						   UINT32 uBottom,
						   UINT32 uOutWidthPix,
						   UINT32 uOutHeight);

/***************************************************************

	BOOL IMGEXP ImgDLLOverlayRGB(...)

	Purpose :
		Overlay one image on another, using variable opacity.

	pImage1 must point to an RGB image that is larger or
	equal in size to the image in pImage2.

	Param				Type			Use
	pImage1			BYTE *		larger image to receive the overlay
	uImage1Width	UINT32		width of pImage1	
	uImage1Height	UINT32		height of pImage1
	pImage2			BYTE *		smaller image to be overlayed
	uImage2Width	UINT32		width of pImage2
	uImage2Height	UINT32		height of pImage2
	iXPos				__int32		x position on pImage1 where overlay will start
	iYPos				__int32		y position on pImage1 where overlay will start
	opacity			double		overlay image opacity (0...1 . 1 is opaque)

	modifies global error value, check with	ImgDLLGetLastError()

	Return
		FALSE on failure

***************************************************************/

BOOL IMGEXP ImgDLLOverlayRGB(BYTE *pImage1,
						   UINT32 uImage1Width,
						   UINT32 uImage1Height,
						   BYTE *pImage2,
						   UINT32 uImage2Width,
						   UINT32 uImage2Height,
						   __int32 iXPos,
						   __int32 iYPos,
						   double opacity);

/***************************************************************

	BOOL IMGEXP ImgDLLOverlayRGBTransparent(...)

	Purpose :
		Overlay one image on another, using variable opacity and
	one transparent color.

	transColor specifies a color in image2 that is to be considered
	transparent - image1 will show through image2 where the color of
	image 2 is transColor.

	pImage1 must point to an RGB image that is larger or
	equal in size to the image in pImage2.

	Param					Type			Use
	pImage1				BYTE *		larger image to receive the overlay
	uImage1Width		UINT32		width of pImage1	
	uImage1Height		UINT32		height of pImage1
	pImage2				BYTE *		smaller image to be overlayed
	uImage2Width		UINT32		width of pImage2
	uImage2Height		UINT32		height of pImage2
	iXPos					__int32 		x position on pImage1 where overlay will start
	iYPos					__int32 		y position on pImage1 where overlay will start
	opacity				double		overlay image opacity (0.0 - 1.0 1 is opaque)
	transColor			COLORREF		color in image2 to be considered trasnparent


	modifies global error value, check with	ImgDLLGetLastError()

	Return
		FALSE on failure

***************************************************************/

BOOL IMGEXP ImgDLLOverlayRGBTransparent(BYTE *pImage1,
						   UINT32 uImage1Width,
						   UINT32 uImage1Height,
						   BYTE *pImage2,
						   UINT32 uImage2Width,
						   UINT32 uImage2Height,
						   __int32  iXPos,
						   __int32  iYPos,
						   double opacity,
						   COLORREF clr);

/***************************************************************

	BOOL IMGEXP BOOL ImgDLLOverlayEdgeFade(...)

	Purpose :
	overlay pImage2 onto pImage1 with a smooth edge fade on pImage2

	pImage1 and pImage2 are RGB (24-bit) images.

	Param				Type			Use
	pImage1				BYTE *	larger image to receive the overlay
	uImage1Width		UINT32		width of pImage1	
	uImage1Height		UINT32		height of pImage1
	pImage2				BYTE *	smaller image to be overlayed
	uImage2Width		UINT32		width of pImage2
	uImage2Height		UINT32		height of pImage2
	fFadeRatio			double	must be > 0.0, < 0.5 . controls how wide the fade is
										on the overlay image. .5 is max.
	iXPos					__int32		x position on pImage1 where overlay will start
	iYPos					__int32		y position on pImage1 where overlay will start

	modifies global error value, check with ImgDLLGetLastError()

	Return
		TRUE on success

***************************************************************/

BOOL IMGEXP ImgDLLOverlayEdgeFade(BYTE *pImage1,
												UINT32 uImage1Width,
												UINT32 uImage1Height,
												BYTE *pImage2,
												UINT32 uImage2Width,
												UINT32 uImage2Height,
												double fFadeRatio,
												__int32 uXPos,
												__int32 uYPos);

/***************************************************************

	BOOL IMGEXP ImgDLLMakeAlphaEdgeMask(...)

	Purpose :
		create an alpha edge fade image. this is an 8bit image
	which has a white center (255) which fades to black (0) at
	the edges. this is a rectangular fade.

		this is generally used in conjunction with ImgDLLOverlayAlpha
	to cause one image to blend into another without sharp edges.
	
	
	Param				Type			Use
	pAlphaImage		BYTE *		called-allocated buffer. this buffer
										must be nWidth * nHeight BYTEs !
	nWidth			UINT32			image size
	nHeight			UINT32			image size
	fFadeRatio		double		determines how fast the edges fade to 0.
										must be greater 0.0 and less than .5

   ** does not use callback

	modifies global error value, check with ImgDLLGetLastError()

	Return
		TRUE on success

***************************************************************/

BOOL IMGEXP ImgDLLMakeAlphaEdgeMask(BYTE *pAlphaImage,
														UINT32 nWidth,
														UINT32 nHeight,
														double fFadeRatio);

/***************************************************************

	BOOL IMGEXP BOOL ImgDLLOverlayAlpha(...)

	Purpose :
		alpha-blend one RGB image onto another using an 8-bit alpha mask

		this is similar to the other overlay functions except for 
	the 8-bit alpha mask which is used to control the opacity of pImage2.

	a 0 in the alpha image means that the overlay image is totally transparent.
	1..254 yield a gradual increase in opacity
	a 255 in the alpha image means that the overlay image is totally opaque.
	
	pAlphaMask MUST be uImage2Width x uImage2Height BYTEs. this is an 8-bit
	image.

	pImage1 and pImage2 are RGB (24-bit) images.

	Param				Type			Use
	pImage1				BYTE *	larger image to receive the overlay
	uImage1Width		UINT32	width of pImage1	
	uImage1Height		UINT32	height of pImage1
	pImage2				BYTE *	smaller image to be overlayed
	uImage2Width		UINT32	width of pImage2
	uImage2Height		UINT32	height of pImage2
	pAlphaMask			BYTE *	alpha image. 
	iXPos					__int32	x position on pImage1 where overlay will start
	iYPos					__int32	y position on pImage1 where overlay will start

	modifies global error value, check with ImgDLLGetLastError()

	Return
		TRUE on success

***************************************************************/

BOOL IMGEXP ImgDLLOverlayAlpha(BYTE *pImage1,
											UINT32 uImage1Width,
											UINT32 uImage1Height,
											BYTE *pImage2,
											UINT32 uImage2Width,
											UINT32 uImage2Height,
											BYTE *pAlphaMask,
											__int32 uXPos,
											__int32 uYPos);

/***************************************************************

	UINT32 IMGEXP ImgDLLCountRGBColors(...)

	Purpose :
		Count colors used in RGB image

	Param				Type		Use
	InBuf				BYTE *	input image
	widthPix			UINT32	width of image
	height			UINT32	height of image
	fast				BOOL		if TRUE, this uses 1 MB of memory and runs
									about 18% faster than if FALSE. if FALSE,
									this uses 512 K of memory.

	** does not use callback 

	modifies global error value, check with ImgDLLGetLastError()

	Return
		FALSE on failure

***************************************************************/

UINT32 IMGEXP ImgDLLCountRGBColors(BYTE *inBuf,
						UINT32 widthPix,
						UINT32 height,
						BOOL fast);


/***************************************************************

	BOOL IMGEXP ImgDLLDrawTextOnRGB(...)

	Purpose :
		draw text on an RGB image.


	Param			Type				Use
	pRGB			BYTE *			ptr to your image data
	width			UINT32			image width, in pixels
	height		UINT32			image height
	drawText		const char *	text to draw
	fontName		const char *	name of font to use
	fontPixels	UINT32			max height of text, in pixels
	xpos			__int32			x position
	ypos			__int32			y position
	textColor	COLORREF			text color

	modifies global error value, check with ImgDLLGetLastError()

	Return
		TRUE on success, else FALSE

***************************************************************/

BOOL IMGEXP ImgDLLDrawTextOnRGB(BYTE *pRGB,
											UINT32 width,
											UINT32 height,
											const char *drawText,
											const char *fontName,
											UINT32 fontPixels,
											__int32 xpos,
											__int32 ypos,
											COLORREF textColor);

/***************************************************************

	BOOL IMGEXP ImgDLLDrawTextOnRGB2(...)

	Purpose :
		draw text on an RGB image.


	Param			Type					Use
	pRGB			BYTE *				ptr to your image data
	width			UINT32				image width, in pixels
	height		UINT32				image height
	drawText		const char *		text to draw
	pLogFont		const LOGFONT *	use this font - caller must initialize this !
	xpos			__int32				x position
	ypos			__int32				y position
	textColor	COLORREF				text color

	modifies global error value, check with	ImgDLLGetLastError()

	Return
		TRUE on success, else FALSE

***************************************************************/

BOOL IMGEXP ImgDLLDrawTextOnRGB2(BYTE *pRGB,
							UINT32 width,
							UINT32 height,
							const char *drawText,
							const LOGFONT *pLogFont,
							__int32 xpos,
							__int32 ypos,
							COLORREF textColor);

/***************************************************************

	void IMGEXP ImgDLLColorSubRGB(...)

	Purpose :
		replace all pixels of a given color with a new color

	Param			Type			Use
	image			BYTE *		RGB image
	w				UINT32		width
	h				UINT32		height
	oldColor		COLORREF		color to look for
	newColor		COLORREF		color to replace it with
	

	Return
		none

***************************************************************/
void IMGEXP ImgDLLColorSubRGB(BYTE *image,
					   UINT32 w,
					   UINT32 h,
					   COLORREF oldColor,
					   COLORREF newColor);

/***************************************************************

	HGLOBAL IMGEXP ImgDLLReadRGBFromPNG(...)

	Purpose :
		Read a PNG file to a buffer of RGB bytes. all files types
	are converted to 24-bit RGB images!!

		screen gamma defaults to 2.9 . this can (and should) be changed
	to your own monitor's gamma value by using ImgDLLPNGSetScreenGamma.

		background color for alpha blending channel is set by using
	ImgDLLPNGSetDefBackground.

	Please read the PNG Notes in the ImgDLLv4.RTF file.

	Param				Type				Use
	fileName			const char *	path to open for reading
	uWidth			UINT32*			width, in pixels
	uHeight			UINT32*			height, in pixels

	modifies global error value, check with	ImgDLLGetLastError()

	Return
		HGLOBAL . 
		Caller must use GlobalUnlock to get a ptr to this buffer!
		Caller is responsible for calling GlobalFree on this buffer!

***************************************************************/

HGLOBAL IMGEXP ImgDLLReadRGBFromPNG(const char *fileName,
										UINT32 *width, 
										UINT32 *height);


/***************************************************************

	HGLOBAL IMGEXP ImgDLLReadRGBFromPNGMem(BYTE * inBuf,   
                                            UINT32 inBufSize,
                                            UINT32 *width,
                                            UINT32 *height);


	Purpose :
		Read a memory-based PNG file to a buffer of RGB bytes. all files types
	are converted to 24-bit RGB images!!

		screen gamma defaults to 2.9 . this can (and should) be changed
	to your own monitor's gamma value by using ImgDLLPNGSetScreenGamma.

		background color for alpha blending channel is set by using
	ImgDLLPNGSetDefBackground.

	Please read the PNG Notes in the ImgDLLv4.RTF file.

	Param				Type			Use
	inBuf				BYTE *		memory-based PNG file
	inBUfSize		UINT32		bytes in inBuf
	uWidth			UINT32*		receives width, in pixels
	uHeight			UINT32*		receives height, in pixels

	modifies global error value, check with	ImgDLLGetLastError()

	Return
		HGLOBAL . 
		Caller must use GlobalUnlock to get a ptr to this buffer!
		Caller is responsible for calling GlobalFree on this buffer!

***************************************************************/
HGLOBAL IMGEXP ImgDLLReadRGBFromPNGMem(BYTE * inBuf,   
                                         UINT32 inBufSize,
                                         UINT32 *width,
                                         UINT32 *height);

/***************************************************************

	BOOL IMGEXP ImgDLLSaveToPNGMem(BYTE *pOutputBuf,
											 DWORD dwOutputBufSize,
											 DWORD *pBytesWritten,
											  BYTE *image, 
											  UINT32 inWidthPix, 
											  UINT32 inHeight, 
											  UINT32 inWidthBytes,
											  UINT32 bitDepth,
											  UINT32 colors,
											  RGBQUAD * inPalette, 
											  UINT32 colorType,
											  double gammaVal,
											  UINT32 filterMask,
											  UINT32 interlaceType);


	Purpose :
		Save a buffer to a PNG file. 

		This routine can take a large variety of input image
	formats, not just packed RGB!. There is not much error checking 
	done on the input data. Be sure that what you are passing is in the
	format you say it is!! 

	Writes any text fields added with ImgDLLAddPNGText

	Please read the PNG Notes in the ImgDLLv4.RTF file.

	Param				Type				Use
	pOutputBuf		BYTE *			ptr to output buffer. must be at least w * h * 3 BYTEs
	dwOutputBufSize DWORD			size of pOutputBuf
	pBytesWritten	DWORD *			receives bytes written when operation is complete
	image				BYTE *			ptr to your image data
	inWidthPix		UINT32				image width, in pixels
	inHeight			UINT32				image height
	inWidthBytes	UINT32				width of an image row, in BYTEs
	bitDepth			UINT32				1, 2, 4, 8, or 16 bits/channel
	colors			UINT32				number of colors in palette

	inPalette		RGBQUAD *		palette entries. there must be at least
											as many RGBQUADs as specified by "colors".
											if your image does not use a palette, pass
											NULL for this parameter.

	colorType		UINT32				this tells the PNG writer which format the
											input image is in, see PNG_COLOR_* definitions

	gammaVal		double				if you know the display gamma of the device this 
											image was created on, pass a value equal 
											to 1 / display_gamma. according to the PNG docs,
											a value of .45 is acceptable for most PCs

	filterMask		UINT32				filter to apply to the image. as of LibPng-0.96,
											the only valid value is 0.

	interlaceType	UINT32				see PNG_INTERLACE_* definitions

	modifies global error value, check with	ImgDLLGetLastError()

	Return
		TRUE on success, else FALSE

***************************************************************/

BOOL IMGEXP ImgDLLSaveToPNGMem(BYTE *pOutputBuf, 
											DWORD dwOutputBufSize,
											DWORD *pBytesWritten,
											BYTE *image, 
											UINT32 inWidthPix, 
											UINT32 inHeight, 
											UINT32 inWidthBytes,
											UINT32 bitDepth,
											UINT32 colors,
											RGBQUAD * inPalette, 
											UINT32 colorType,
											double gammaVal,
											UINT32 filterMask,
											UINT32 interlaceType);

/***************************************************************

	double IMGEXP ImgDLLPNGSetScreenGamma(...)

	Purpose :
		Set the screen gamma value for PNG reads and writes

	Param				Type				Use
	screenGamma		double			value to set as gamma. 

	Return
		last PNG gamma value

***************************************************************/

double IMGEXP ImgDLLPNGSetScreenGamma(double screenGamma);

/***************************************************************

	void IMGEXP ImgDLLPNGSetDefBackground(...)

	Purpose :
		Set the background colors to be used in blending the
	alpha channel from PNG images that have one. This is used
	for both reading and writing of PNG images - if the input image
	uses an alpha channel but has no background specified, this
	value is used. When writing a file, this value is written
	as the default background.

	Please read the PNG Notes in the ImgDLLv4.RTF file.

	Param			Type			Use
	palIndex		BYTE			palIndex to use for background
									(if you know the incoming image has a 
									certain palette)
	red			UINT32		red component of RGB background value
	green			UINT32		green component of RGB background value
	blue			UINT32		blue component of RGB background value
	gray			UINT32		gray value to be used for grayscale images

	Return
		none

***************************************************************/

void IMGEXP ImgDLLPNGSetDefBackground(BYTE palIndex,
										 UINT32 red,
										 UINT32 green,
										 UINT32 blue,
										 UINT32 gray);

/***************************************************************

	BOOL IMGEXP ImgDLLSaveToPNG(...)

	Purpose :
		Save a buffer to a PNG file. 

		This routine can take a large variety of input image
	formats, not just packed RGB!. There is not much error checking 
	done on the input data. Be sure that what you are passing is in the
	format you say it is!! 

	Writes any text fields added with ImgDLLAddPNGText

	Please read the PNG Notes in the ImgDLLv4.RTF file.

	Param				Type				Use
	imageFileName	const char *	file to write
	image				BYTE *			ptr to your image data
	inWidthPix		UINT32			image width, in pixels
	inHeight			UINT32			image height
	inWidthBytes	UINT32			width of an image row, in BYTEs
	bitDepth			UINT32			1, 2, 4, 8, or 16 bits/channel
	colors			UINT32			number of colors in palette

	inPalette		RGBQUAD *		palette entries. there must be at least
											as many RGBQUADs as specified by "colors".
											if your image does not use a palette, pass
											NULL for this parameter.

	colorType		UINT32			this tells the PNG writer which format the
											input image is in, see PNG_COLOR_* definitions

	gammaVal			double			if you know the display gamma of the device this 
											image was created on, pass a value equal 
											to 1 / display_gamma. according to the PNG docs,
											a value of .45 is acceptable for most PCs

	filterMask		UINT32			filter to apply to the image. as of LibPng-0.96,
											the only valid value is 0.

	interlaceType	UINT32			see PNG_INTERLACE_* definitions

	title				char *				optional text to write under key "Title"
	description		char *			optional text to write under key "Description"

	modifies global error value, check with	ImgDLLGetLastError()

	Return
		TRUE on success, else FALSE

***************************************************************/

BOOL IMGEXP ImgDLLSaveToPNG(const char *imageFileName, 
							  BYTE *image, 
							  UINT32 inWidthPix, 
							  UINT32 inHeight, 
							  UINT32 inWidthBytes,
							  UINT32 bitDepth,
							  UINT32 colors,
							  RGBQUAD * inPalette, 
							  UINT32 colorType,
							  double gammaVal,
							  UINT32 filterMask,
							  UINT32 interlaceType);

/***************************************************************

	BOOL IMGEXP ImgDLLSaveRGBToPNG()

	Purpose :
		Save an RGB24 buffer to a PNG-RGB24 file. 

	Please read the PNG Notes in the ImgDLLv4.RTF file.

	Writes any text fields added with ImgDLLAddPNGText

	Param				Type				Use
	imageFileName	const char *	file to write
	image				BYTE *			ptr to your image data
	inWidthPix		UINT32			image width, in pixels
	inHeight			UINT32			image height
	gammaVal			double			if you know the display gamma of the device this 
											image was created on, pass a value equal 
											to 1 / display_gamma. according to the PNG docs,
											a value of .45 is acceptable for most PCs

	modifies global error value, check with	ImgDLLGetLastError()

	Return
		TRUE on success, else FALSE

***************************************************************/

BOOL IMGEXP ImgDLLSaveRGBToPNG(const char *imageFileName, 
							  BYTE *image, 
							  UINT32 inWidthPix, 
							  UINT32 inHeight, 
							  double gammaVal);

/***************************************************************

	BOOL IMGEXP ImgDLLSave8BitToPNG8Bit(...)

	Purpose :
		Save an RGB24 buffer to a PNG-RGB24 file. 

	Writes any text fields added with ImgDLLAddPNGText

	Please read the PNG Notes in the ImgDLLv4.RTF file.

	Param				Type				Use
	imageFileName	const char *	file to write
	image				BYTE *			ptr to your image data
	inWidthPix		UINT32			image width, in pixels
	inHeight			UINT32			image height
	colors			UINT32			number of colors in palette
	inPalette		RGBQUAD			palette
	gammaVal			double			if you know the display gamma of the device this 
											image was created on, pass a value equal 
											to 1 / display_gamma. according to the PNG docs,
											a value of .45 is acceptable for most PCs

	modifies global error value, check with	ImgDLLGetLastError()

	Return
		TRUE on success, else FALSE

***************************************************************/

BOOL IMGEXP ImgDLLSave8BitToPNG8Bit(const char *imageFileName, 
									  BYTE *image, 
									  UINT32 inWidthPix, 
									  UINT32 inHeight, 
									  UINT32 colors,
									  RGBQUAD * inPalette,
									  double gammaVal);

/***************************************************************

	HGLOBAL IMGEXP ImgDLLGetPNGKey(...)

	Purpose :
		return a buffer containing the key of one of the PNG text
	fields.

	a PNG file may contain any number text fields. Each of these fields
	consists of a key and the text. These strings can be any length.
	When ImgDLL reads a PNG file, it stores these strings in the 
	ImgDLL PNG text buffer. These strings remain valid until the next 
	PNG file is read or ImgDLLClearPNGText is called. 

	To find the number of strings read from the last PNG file, use
	ImgDLLGetPNGTextCount.

	Please read the PNG Notes in the ImgDLLv4.RTF file.

	Param			Type				Use
	index			UINT32			index of string you'd like to fetch

	modifies global error value, check with	ImgDLLGetLastError()

	Return
		HGLOBAL to a zero-terminated string, else NULL on error

***************************************************************/

HGLOBAL IMGEXP ImgDLLGetPNGKey(UINT32 index);

/***************************************************************

	HGLOBAL IMGEXP ImgDLLGetPNGText(...)

	Purpose :
		return a buffer containing the text of one of the PNG text
	fields.

	a PNG file may contain any number text fields. Each of these fields
	consists of a key and the text. These strings can be any length.
	When ImgDLL reads a PNG file, it stores these strings in the 
	ImgDLL PNG text buffer. These strings remain valid until the next 
	PNG file is read or ImgDLLClearPNGText is called. 

	To find the number of strings read from the last PNG file, use
	ImgDLLGetPNGTextCount.

	Please read the PNG Notes in the ImgDLLv4.RTF file.

	Param			Type			Use
	index			UINT32		index of string you'd like to fetch

	modifies global error value, check with	ImgDLLGetLastError()

	Return
		HGLOBAL to a zero-terminated string, else NULL on error

***************************************************************/

HGLOBAL IMGEXP ImgDLLGetPNGText(UINT32 index);

/***************************************************************

	BOOL IMGEXP ImgDLLGetPNGCompression(...)

	Purpose :
		return the compression state of a stored PNG string

	a PNG file may contain any number text fields. Each of these fields
	consists of a key and the text. These strings can be any length.
	When ImgDLL reads a PNG file, it stores these strings in the 
	ImgDLL PNG text buffer. These strings remain valid until the next 
	PNG file is read or ImgDLLClearPNGText is called. 

	To find the number of strings read from the last PNG file, use
	ImgDLLGetPNGTextCount.

	Please read the PNG Notes in the ImgDLLv4.RTF file.

	Param			Type			Use
	index			UINT32		index of string you'd like to fetch

	modifies global error value, check with	ImgDLLGetLastError()

	Return
		BOOL - TRUE if the string was compressed in the PNG file

***************************************************************/

BOOL IMGEXP ImgDLLGetPNGCompression(UINT32 index);

/***************************************************************

	void IMGEXP ImgDLLClearPNGText()

	Purpose :
		clear the stored PNG text fields, both input and output. 
	when you read a PNG file, the stored text remains in memory 
	until you read a new PNG file, or you explicitly clear it with 
	this call.

	see ImgDLLAddPNGText for a brief example

	Param			Type			Use
	none

	Return
		none

***************************************************************/

void IMGEXP ImgDLLClearPNGText();

/***************************************************************

	UINT32 IMGEXP ImgDLLGetPNGTextCount()

	Purpose :
		Ask ImgDLL how many text fields were read when the last
	PNG file was read. 

	Please read the PNG Notes in the ImgDLLv4.RTF file.

	Param			Type			Use
	none

	Return
		UINT32 - number of fields read

***************************************************************/

UINT32 IMGEXP ImgDLLGetPNGTextCount();

/***************************************************************

	BOOL IMGEXP ImgDLLAddPNGText(...)

	Purpose :
		Add a text field to the ImgDLL global PNG text buffer.
	PNG text fields consist of a mandatory 1-79 character key and 
	an optional text buffer of any size. The text can be written 
	compressed or uncompressed. It is not recommended that you compress text 
	fields of length < 1000.

	Keys should be plain ASCII, no control or non-printable chars.

	You may add as many fields as you wish. 

  The keywords that are given in the PNG Specification are:

            Title            Short (one line) title or caption for image
            Author           Name of image's creator
            Description      Description of image (possibly long)
            Copyright        Copyright notice
            Creation Time    Time of original image creation
            Software         Software used to create the image
            Disclaimer       Legal disclaimer
            Warning          Warning of nature of content
            Source           Device used to create the image
            Comment          Miscellaneous comment; conversion from other
                             image format

	NOTE : All fields will be cleared after the next ImgDLL PNG file write
	action.

	Please read the PNG Notes in the ImgDLLv4.RTF file.

	Param			Type				Use
	key			char *			key string 1-79 ASCII chars
	title			char *			text string
	compress		BOOL				compress text if TRUE

	Return
		TRUE on success

***************************************************************/

BOOL IMGEXP ImgDLLAddPNGText(const char *key,
								const char *text,
								BOOL compress);

/***************************************************************

	HGLOBAL IMGEXP ImgDLLReadRGBFromTIFF(...)

	Purpose :
		read a 24-bit image from a non-LZW-compressed TIFF image


	Param			Type				Use
	path			const char *	path to open for reading
	pWidth		UINT32*			width, in pixels
	pHeight		UINT32*			height, in pixels

	Return
		HGLOBAL . 
		Caller must use GlobalUnlock to get a ptr to this buffer!
		Caller is responsible for calling GlobalFree on this buffer!

***************************************************************/

HGLOBAL IMGEXP ImgDLLReadRGBFromTIFF(const char * path,
								  UINT32 *pWidth,
								  UINT32 *pHeight);

/***************************************************************

	BOOL IMGEXP ImgDLLSaveRGBToTIFF(...)

	Purpose :
		Save an RGB buffer to a non-LZW-compressed TIFF file . 
		Buffer must be packed RGB.


	Param				Type				Use
	fileName			const char *	path to open for writing
	pBuf				BYTE *			image buffer
	uWidthPix		UINT32			width, in pixels
	uHeight			UINT32			height, in pixels

	modifies global error value, check with	ImgDLLGetLastError()

	Return
		TRUE on success

***************************************************************/

BOOL IMGEXP ImgDLLSaveRGBToTIFF(LPCSTR lpFileName,
							BYTE *pRGB,
							UINT32 nWidth,
							UINT32 nHeight);

/***************************************************************

	BOOL IMGEXP ImgDLLSaveColormappedToTIFF(...)

	Purpose :
		Save an 8-bit colormapped image to a non-LZW-compressed TIFF file . 


	Param				Type				Use
	fileName			const char *	path to open for writing
	pBuf				BYTE *			image buffer
	uWidthPix		UINT32			width, in pixels
	uHeight			UINT32			height, in pixels
	pPal				RGBQUAD *		ptr to array of 256 RGBQUAD values -the image palette

	modifies global error value, check with	ImgDLLGetLastError()

	Return
		TRUE on success

***************************************************************/

BOOL IMGEXP ImgDLLSaveColormappedToTIFF(LPCSTR lpFileName,
							BYTE *pBuf,
							UINT32 nWidth,
							UINT32 nHeight,
							RGBQUAD *pPal);

/***************************************************************

	HGLOBAL IMGEXP ImgDLLReadRGBFromPCX(...)


	Purpose :
		Read a PCX file to a buffer of RGB bytes.

	Param				Type				Use
	fileName			const char *	path to open for reading
	uWidth			UINT32*			width, in pixels
	uHeight			UINT32*			height, in pixels

	modifies global error value, check with	ImgDLLGetLastError()

	Return
		HGLOBAL . 
		Caller must use GlobalLock to get a ptr to this buffer!
		Caller is responsible for calling GlobalFree on this buffer!

***************************************************************/

HGLOBAL IMGEXP ImgDLLReadRGBFromPCX(const char* filename,
                                          UINT32 *width,
                                          UINT32 *height);


/***************************************************************

	BOOL IMGEXP ImgDLLSaveRGBToPCX(...)

	Purpose :
		Write a 24-bit PCX file from a 24-bit RGB buffer

	Param				Type				Use
	fileName			const char *	path to open for writing
	pRGB				BYTE *			ptr to the image
	uWidth			UINT32*			width, in pixels
	uHeight			UINT32*			height, in pixels

	modifies global error value, check with	ImgDLLGetLastError()

	Return
		TRUE on success

***************************************************************/
						 
BOOL IMGEXP ImgDLLSaveRGBToPCX(LPCSTR lpFileName,
							BYTE *pRGB,
							UINT32 nWidth,
							UINT32 nHeight);

/***************************************************************

	BOOL IMGEXP ImgDLLSaveColormappedToPCX(...)

	Purpose :
		Write an 8-bit PCX file from a colormapped buffer

	Param				Type				Use
	fileName			const char *	path to open for writing
	p8Bit				BYTE *			ptr to the 8-bit image
	uWidth			UINT32			width, in pixels
	uHeight			UINT32			height, in pixels
	pPal				RGBQUAD *		ptr to 256 RGBQUADs

	modifies global error value, check with	ImgDLLGetLastError()

	Return
		TRUE on success

***************************************************************/

BOOL IMGEXP ImgDLLSaveColormappedToPCX(LPCSTR lpFileName,
							BYTE *p8Bit,
							UINT32 nWidth,
							UINT32 nHeight,
							RGBQUAD *pPal);


/***************************************************************

	HGLOBAL IMGEXP ImgDLLCreateDJIS(...)

	Purpose :
		Create a JPEG Decompression structure for single-line
	JPEG decompression.

		This is to be used in conjunction with ImgDLLGetNextDJISLine
	and ImgDLLDestroyDJIS.

		You must call ImgDLLDestroyDJIS to free the memory associated
	with this object!

		See ImgDLLv4.rtf for example

	Param				Type				Use
	fileName			const char *	path to open for reading
	width				UINT32*			width, in pixels
	height			UINT32*			height, in pixels

	modifies global error value, check with ImgDLLGetLastError()

	Return
		HGLOBAL to be passed to the other DJIS functions

***************************************************************/

HGLOBAL IMGEXP ImgDLLCreateDJIS(const char *fileName,
												UINT32 *width,
												UINT32 *height);

/***************************************************************

	BOOL IMGEXP ImgDLLGetNextDJISLine(...)

	Purpose :
		Read the next scan line from a JPEG file previously
	opened with ImgDLLCreateDJIS.

		This is to be used in conjunction with ImgDLLCreateDJIS
	and ImgDLLDestroyDJIS.

		See ImgDLLv4.rtf for example

	Param				Type				Use
	hDJIS				HGLOBAL			returned from ImgDLLCreateDJIS
	pOutBuf			BYTE *			start of buffer to receive RGB data

	modifies global error value, check with ImgDLLGetLastError()

	Return
		TRUE on success. FALSE when end of file or error. 
		check for IMGNOLINES from ImgDLLGetLastError()

***************************************************************/

BOOL IMGEXP ImgDLLGetNextDJISLine(HGLOBAL hDJIS,
												BYTE *pOutRow);

/***************************************************************

	BOOL IMGEXP ImgDLLDestroyDJIS(...)

	Purpose :
		Release the memory associated with this object. This
	object was previously allocated by ImgDLLCreateDJIS.

		This is to be used in conjunction with ImgDLLCreateDJIS
	and ImgDLLGetNextDJISLine.

		See ImgDLLv4.rtf for example

	Param				Type				Use
	hDJIS				HGLOBAL			returned from ImgDLLCreateDJIS

	modifies global error value, check with ImgDLLGetLastError()

	Return
		TRUE on success

***************************************************************/

BOOL IMGEXP ImgDLLDestroyDJIS(HGLOBAL hDJIS);

/***************************************************************

	HGLOBAL IMGEXP ImgDLLCreateCJIS(...)

	Purpose :
		Create a JPEG Compression structure for single-line
	JPEG compression.

		This is to be used in conjunction with ImgDLLWriteNextCJISLine
	and ImgDLLDestroyCJIS.

		You must call ImgDLLDestroyCJIS to free the memory associated
	with this object!

		See ImgDLLv4.rtf for example

	Param				Type				Use
	fileName			const char *	path to open for reading
	widthPix			UINT32			width of RGB image, in pixels
	height			UINT32*			height, in pixels
	color				BOOL				TRUE = color, FALSE = grayscale
	quality			__int32			0..100. 100 is high
	bProgressive	BOOL				TRUE = write progressive mode

	modifies global error value, check with ImgDLLGetLastError()

	Return
		HGLOBAL to be passed to the other CJIS functions

***************************************************************/

HGLOBAL IMGEXP ImgDLLCreateCJIS(const char *fileName,
												UINT32 widthPix,
												UINT32 height,
												BOOL color, 
												__int32 quality,
												BOOL bProgressive);

/***************************************************************

	BOOL IMGEXP ImgDLLWriteNextCJISLine(...)

	Purpose :
		Write the next scan line to a JPEG file previously
	opened with ImgDLLCreateCJIS.

		This is to be used in conjunction with ImgDLLCreateCJIS
	and ImgDLLDestroyCJIS.

		See ImgDLLv4.rtf for example

	Param				Type				Use
	hCJIS				HGLOBAL			returned from ImgDLLCreateCJIS
	pIamgeRow		BYTE *			pointer to the RGB row to write

	modifies global error value, check with ImgDLLGetLastError()

	Return
		TRUE on success. FALSE when end of file or error. 
		check for IMGNOLINES from ImgDLLGetLastError()

***************************************************************/

BOOL IMGEXP ImgDLLWriteNextCJISLine(HGLOBAL hCJIS,
													BYTE *pImageRow);

/***************************************************************

	BOOL IMGEXP ImgDLLDestroyCJIS(...)

	Purpose :
		Release the memory associated with this object. This
	object was previously allocated by ImgDLLCreateCJIS.

		This is to be used in conjunction with ImgDLLCreateCJIS
	and ImgDLLGetNextCJISLine.

		See ImgDLLv4.rtf for example

	Param				Type				Use
	hDJIS				HGLOBAL			returned from ImgDLLCreateCJIS

	modifies global error value, check with ImgDLLGetLastError()

	Return
		TRUE on success

***************************************************************/

BOOL IMGEXP ImgDLLDestroyCJIS(HGLOBAL hCJIS);

/***************************************************************

	HGLOBAL IMGEXP ImgDLLCreateDBIS(...)

	Purpose :
		Create a BMP Decompression structure for single-line
	BMP decompression.

		This is to be used in conjunction with ImgDLLGetNextDBISLine
	and ImgDLLDestroyDBIS.

		You must call ImgDLLDestroyDBIS to free the memory associated
	with this object!

		See ImgDLLv4.rtf for example

	Param				Type				Use
	fileName			const char *	path to open for reading
	width				UINT32*			width, in pixels
	height			UINT32*			height, in pixels

	modifies global error value, check with ImgDLLGetLastError()

	Return
		HGLOBAL to be passed to the other DBIS functions

***************************************************************/
	
HGLOBAL IMGEXP ImgDLLCreateDBIS(const char *fileName,
						UINT32 *width,
						UINT32 *height);

/***************************************************************

	BOOL IMGEXP ImgDLLGetNextDBISLine(...)


	Purpose :
		Read the next scan line from a BMP file previously
	opened with ImgDLLCreateDBIS.

		This is to be used in conjunction with ImgDLLCreateDBIS
	and ImgDLLDestroyDBIS.

		See ImgDLLv4.rtf for example

	Param				Type				Use
	hDBIS				HGLOBAL			returned from ImgDLLCreateDBIS
	pOutBuf			BYTE *			start of buffer to receive RGB data

	modifies global error value, check with ImgDLLGetLastError()

	Return
		TRUE on success. FALSE when end of file or error. 
		check for IMGNOLINES from ImgDLLGetLastError()

***************************************************************/

BOOL IMGEXP ImgDLLGetNextDBISLine(HGLOBAL hDBIS,
										BYTE *pOutBuf);

/***************************************************************

	BOOL IMGEXP ImgDLLDestroyDBIS(...)

	Purpose :
		Release the memory associated with this object. This
	object was previously allocated by ImgDLLCreateDBIS.

		This is to be used in conjunction with ImgDLLCreateDBIS
	and ImgDLLGetNextDBISLine.

		See ImgDLLv4.rtf for example

	Param				Type				Use
	hDBIS				HGLOBAL			returned from ImgDLLCreateDBIS

	modifies global error value, check with ImgDLLGetLastError()

	Return
		TRUE on success

***************************************************************/

BOOL IMGEXP ImgDLLDestroyDBIS(HGLOBAL hDBIS);

/***************************************************************

	HGLOBAL IMGEXP ImgDLLCreateCBIS(...)	

	Purpose :
		Create a BMP Compression structure for single-line
	BMP compression.

		This is to be used in conjunction with ImgDLLWriteNextCBISLine
	and ImgDLLDestroyCBIS.

		You must call ImgDLLDestroyCBIS to free the memory associated
	with this object!

		See ImgDLLv4.rtf for example

	Param				Type				Use
	fileName			const char *	path to open for reading
	widthPix			UINT32			width of RGB image, in pixels
	height			__int32			height, in pixels. if negative, BMP is stored top-down
	bitsPerPixel	UINT32			1,4,8,24 . if < 24, image must be in a
											colormapped 8-bit buffer !!!!

	colors			UINT32				colors in the palette (may be 0 if 24-bit)
	colormap			RGBQUAD*			pointer to an array of RGBQUADs. this must
											have at least "colors" entries. may be NULL
											for 24-bit.

	modifies global error value, check with ImgDLLGetLastError()

	Return
		HGLOBAL to be passed to the other CBIS functions

***************************************************************/

HGLOBAL IMGEXP ImgDLLCreateCBIS(const char *fileName,
											 UINT32 width,
											 UINT32 height,
 											 __int32 bitsPerPixel,
											 __int32 colors,
											 RGBQUAD *colormap);	

/***************************************************************

	BOOL IMGEXP ImgDLLWriteNextCBISLine(...)

	Purpose :
		Write the next scan line to a BMP file previously
	opened with ImgDLLCreateCBIS.

		This is to be used in conjunction with ImgDLLCreateCBIS
	and ImgDLLDestroyCBIS.

		See ImgDLLv4.rtf for example

	Param				Type				Use
	hCBIS				HGLOBAL			returned from ImgDLLCreateCBIS
	pIamgeRow		BYTE *			pointer to the row to write.
											this is RGB data for 24-bit files,
											else 8-bit for all others.

	modifies global error value, check with ImgDLLGetLastError()

	Return
		TRUE on success. FALSE when enf of file or error. 
		check for IMGNOLINES from ImgDLLGetLastError()

***************************************************************/

BOOL IMGEXP ImgDLLWriteNextCBISLine(HGLOBAL hCBIS,
													BYTE *pImageRow);

/***************************************************************

	BOOL IMGEXP ImgDLLDestroyCBIS(...)

	Purpose :
		Release the memory and close all files associated with this object. This
	object was previously allocated by ImgDLLCreateCBIS.

		This is to be used in conjunction with ImgDLLCreateCBIS
	and ImgDLLGetNextCBISLine.

		See ImgDLLv4.rtf for example

	Param				Type				Use
	hDJIS				HGLOBAL			returned from ImgDLLCreateCBIS

	modifies global error value, check with ImgDLLGetLastError()

	Return
		TRUE on success

***************************************************************/

BOOL IMGEXP ImgDLLDestroyCBIS(HGLOBAL hCBIS);

/***************************************************************

	BOOL IMGEXP ImgDLLAddJPGText(...)

	Purpose :
		Add a text field to the ImgDLL global JPG text buffer. 

		All strings added will be written to all JPG files written,
	until the text buffers are cleared by a call to ImgDLLClearJPGOutputText.

		Text should be plain ASCII, no control or non-printable chars.

		You may add as many fields as you wish. 

	Param			Type			Use
	title			char *		text string

	Return
		TRUE on success

***************************************************************/

BOOL IMGEXP ImgDLLAddJPGText(const char *text);

/***************************************************************

	void IMGEXP ImgDLLClearJPGOutputText();

	Purpose :
		clear the stored JPG output text fields. 

	Param			Type			Use
	none

	Return
		none

***************************************************************/

void IMGEXP ImgDLLClearJPGOutputText();

/***************************************************************

	void IMGEXP ImgDLLClearJPGInputText();

	Purpose :
		clear the stored JPG output text fields. 

	Param			Type			Use
	none

	Return
		none

***************************************************************/

void IMGEXP ImgDLLClearJPGInputText();

/***************************************************************

	UINT32 IMGEXP ImgDLLGetJPGInputTextCount();

	Purpose :
		Ask ImgDLL how many input text fields were read when the last
	JPG file was read. 

	Param			Type			Use
	none

	Return
		UINT32 - number of fields read

***************************************************************/
UINT32 IMGEXP ImgDLLGetJPGInputTextCount();

/***************************************************************

	HGLOBAL IMGEXP ImgDLLGetJPGText(...)

	Purpose :
		return a buffer containing the text of one of the JPG text
	fields.

	a JPG file may contain any number text fields (JPEG_COM markers).
	These strings can be any length. When ImgDLL reads a JPG file, 
	it stores these strings in the ImgDLL JPG text buffer. These 
	strings remain valid until the next JPG file is read or 
	ImgDLLClearJPGInputText is called. 

	Param			Type			Use
	index			UINT32			index of string you'd like to fetch

	modifies global error value, check with	ImgDLLGetLastError()

	Return
		HGLOBAL to a zero-terminated string, else NULL on error

***************************************************************/

HGLOBAL IMGEXP ImgDLLGetJPGText(UINT32 index);


/***************************************************************

	BOOL IMGEXP ImgDLLGetJPGInputDPI(...)

	Purpose :
		fetch DPI settings of last-read JPG file.	these are
	set when a JPG file read operation is performed (including
	GetDimensions).
	
		note that not all files will have valid DPI values.

	Param			Type			Use
	dpix			UINT32 *		receives X pixel density
	dpiy			UINT32 *		receives Y pixel density
	units			UINT32 *		0 - no units specified in file
									1 - dots / inch
									2 - dots / cm
	
	modifies global error value, check with ImgDLLGetLastError()

	Return
		TRUE on success

***************************************************************/

BOOL IMGEXP ImgDLLGetJPGInputDPI(UINT32 *dpiX,
												UINT32 *dpiY,
												UINT32 *units);

/***************************************************************

	BOOL IMGEXP ImgDLLSetJPGOutputDPI(...)

	Purpose :
		set DPI settings for all subsequent JPG file write
	operations.
	
		the default is 1,1,0 - indicating "square pixels
	of unknown size"

	Param			Type			Use
	dpix			UINT32 			X pixel density
	dpiy			UINT32 			Y pixel density
	units			UINT32			0 - no units specified in file
									1 - dots / inch
									2 - dots / cm
	
	modifies global error value, check with ImgDLLGetLastError()

	Return
		TRUE on success

***************************************************************/

BOOL IMGEXP ImgDLLSetJPGOutputDPI(UINT32 dpiX,
												UINT32 dpiY,
												UINT32 units);

/***************************************************************

	BOOL IMGEXP ImgDLLGetTIFFInputDPI(...)

	Purpose :
		fetch DPI settings of last-read TIFF file.	these are
	set when a TIFF file read operation is performed (including
	GetDimensions).
	
		note that not all files will have valid DPI values.

	Param			Type			Use
	dpix			UINT32 *		receives X pixel density
	dpiy			UINT32 *		receives Y pixel density
	units			UINT32 *		1 - no units specified in file
									2 - dots / inch
									3 - dots / cm
	
	modifies global error value, check with	ImgDLLGetLastError()

	Return
		TRUE on success

***************************************************************/

BOOL IMGEXP ImgDLLGetTIFFInputDPI(UINT32 *dpiX,
												UINT32 *dpiY,
												UINT32 *units);

/***************************************************************

	BOOL IMGEXP ImgDLLSetTIFFOutputDPI(...)

	Purpose :
		set DPI settings for all subsequent TIFF file write
	operations.
	
		the default is 1,1,1	- indicating "square pixels
	of unknown size"

	Param			Type			Use
	dpix			UINT32 			X pixel density
	dpiy			UINT32 			Y pixel density
	units			UINT32			1 - no units specified in file
									2 - dots / inch
									3 - dots / cm
	
	modifies global error value, check with	ImgDLLGetLastError()

	Return
		TRUE on success

***************************************************************/

BOOL IMGEXP ImgDLLSetTIFFOutputDPI(UINT32 dpiX,
												UINT32 dpiY,
												UINT32 units);

/***************************************************************

	BOOL IMGEXP ImgDLLGetPNGInputDPI(...)

	Purpose :
		fetch DPI settings of last-read PNG file.	these are
	set when a PNG file read operation is performed (including
	GetDimensions).
	
		note that not all files will have valid DPI values.

	Param			Type			Use
	dpix			UINT32 *		receives X pixel density
	dpiy			UINT32 *		receives Y pixel density
	units			UINT32 *		0 - no units specified in file
									1 - dots / cm
	
	modifies global error value, check with	ImgDLLGetLastError()

	Return
		TRUE on success

***************************************************************/

BOOL IMGEXP ImgDLLGetPNGInputDPI(UINT32 *dpiX,
												UINT32 *dpiY,
												UINT32 *units);

/***************************************************************

	BOOL IMGEXP ImgDLLSetPNGOutputDPI(...)

	Purpose :
		set DPI settings for all subsequent PNG file write
	operations.
	
		the default is 1,1,0 - indicating "square pixels
	of unknown size"

	Param			Type			Use
	dpix			UINT32 			X pixel density
	dpiy			UINT32 			Y pixel density
	units			UINT32			0 - no units specified in file
									1 - dots / cm
	
	modifies global error value, check with	ImgDLLGetLastError()

	Return
		TRUE on success

***************************************************************/

BOOL IMGEXP ImgDLLSetPNGOutputDPI(UINT32 dpiX,
												UINT32 dpiY,
												UINT32 units);

/***************************************************************

	BOOL IMGEXP ImgDLLSaveColormappedToGIF(...)

	Purpose :
		Save a colormapped buffer to a GIF file . 
		Buffer must be colormapped, 8-bit per pixel,
		vertically oriented as viewed.

	Param				Type			Use
	fileName			const char *	path to open for writing
	pBuf				BYTE *			image buffer
	uWidthPix			UINT32			width, in pixels
	uHeight				UINT32			height, in pixels
	uBackColor			UINT32			color to set as background color
	iTransparent		__int32			transparent color index, -1 if none
	rgbPalette			RGBQUAD *		palette array

	modifies global error value, check with	ImgDLLGetLastError()


	Return
		TRUE on success

***************************************************************/

BOOL IMGEXP ImgDLLSaveColormappedToGIF(const char * fileName,
														BYTE * pBuf,
														UINT32 uWidthPix,
														UINT32 uHeight,
														UINT32 backColor,
														__int32 iTransparent,
														RGBQUAD *rgbPalette);

/***************************************************************

	BOOL IMGEXP ImgDLLSaveColormappedToGIF2(...)

	Purpose :
		Save a colormapped buffer to a GIF file . 
		Buffer must be colormapped, 8-bit per pixel,
		vertically oriented as viewed.

   if you specifiy n bits-per-pixel, you must have 2^n palette
	entries, and none of your pixels may have values higher than
	(2^n - 1) . 

	Param				Type			Use
	fileName			const char *	path to open for writing
	pBuf				BYTE *			image buffer
	uWidthPix			UINT32			width, in pixels
	uHeight				UINT32			height, in pixels
	uBackColor			UINT32			color to set as background color
	iTransparent		__int32			transparent color index, -1 if none
	uBitsPerPixel		UINT32			use this many bits per pixel when writing image
	rgbPalette			RGBQUAD *		palette array. at least 2^bitsPerPixel entries

	modifies global error value, check with	ImgDLLGetLastError()


	Return
		TRUE on success

***************************************************************/

BOOL IMGEXP ImgDLLSaveColormappedToGIF2(const char * fileName,
														BYTE * pBuf,
														UINT32 uWidthPix,
														UINT32 uHeight,
														UINT32 backColor,
														__int32 iTransparent,
														UINT32 uBitsPerPixel,
														RGBQUAD *rgbPalette);

/***************************************************************

	HGLOBAL IMGEXP ImgDLLReadRGBFromGIF(...)

	Purpose :
		Read a GIF file to a buffer of RGB bytes. 

	Param				Type			Use
	fileName			const char *	path to open for reading
	uWidth				UINT32*			width, in pixels
	uHeight				UINT32*			height, in pixels
	pTransColor		COLORREF *		receives transparent color, -1 if none

	modifies global error value, check with	ImgDLLGetLastError()

	Return
		HGLOBAL . 
		Caller must use GlobalUnlock to get a ptr to this buffer!
		Caller is responsible for calling GlobalFree on this buffer!

***************************************************************/

HGLOBAL IMGEXP ImgDLLReadRGBFromGIF(const char * fileName,
													 UINT32 *width,
													 UINT32 *height,
													 COLORREF *pTransColor);

/***************************************************************

	HGLOBAL IMGEXP ImgDLLReadRGBFromGIFMem(...)

	Purpose :
		Read a GIF file to a buffer of RGB bytes. 

	Param				Type			Use
	inBuf				BYTE *		memory-buffered GIF file
	bufSize			DWORD			size of file buffer
	uWidth				UINT32*			width, in pixels
	uHeight				UINT32*			height, in pixels
	pTransColor		COLORREF *		receives transparent color, -1 if none

	modifies global error value, check with	ImgDLLGetLastError()

	Return
		HGLOBAL . 
		Caller must use GlobalUnlock to get a ptr to this buffer!
		Caller is responsible for calling GlobalFree on this buffer!

***************************************************************/

HGLOBAL IMGEXP ImgDLLReadRGBFromGIFMem(BYTE *inBuf,
													  DWORD bufSize,
													  UINT32 *width,
													  UINT32 *height,
													  COLORREF *pTransColor);

/***************************************************************

  DWORD IMGEXP ImgDLLSaveColormappedToGIFMem(...)

	Purpose :
		Save a colormapped buffer to a GIF memory buffer. 
		Source buffer must be colormapped, 8-bit per pixel, vertically 
		oriented as viewed.

   Note : for safety, you should allocate at least uWidthPix * uHeight * 2
	BYTEs for a destination buffer. Actual compressed image size will 
	depend on the image data as it relates to the compression algorithm.
	This will set an error of BUFTOOSMALL if the buffer is not large enough.

	If the buffer provided is too small (even though it is at least w * h * 2 
	BYTEs), you may see a "Microsoft C++ Exception" message in your debug
	window. This is an internal exception thrown when the output manager
	sees that the output buffer is too small for the operation. This is not
	a fatal situation. ImgDLL handles this exception.

	Param				Type			Use
	pOutBuf			BYTE *		ptr to a caller-allocated destination buffer
	dwBufSize		DWORD			size of dest buffer
	pBuf				BYTE *			image buffer
	uWidthPix		UINT32			width, in pixels
	uHeight			UINT32			height, in pixels
	uBackColor		UINT32			color to set as background color
	iTransparent	__int32			transparent color index, -1 if none
	rgbPalette		RGBQUAD *		palette array

	modifies global error value, check with	ImgDLLGetLastError()

	Return
		DWORD - size of GIF memory file, in BYTEs

***************************************************************/

DWORD IMGEXP ImgDLLSaveColormappedToGIFMem(BYTE *pOutBuf,
										DWORD dwBufSize,
                                BYTE * pBuf,
                                UINT32 uWidthPix,
                                UINT32 uHeight,
                                UINT32 backColor,
										  __int32 iTransparent,
                                RGBQUAD *rgbPalette);

/***************************************************************

  DWORD IMGEXP ImgDLLSaveColormappedToGIFMem2(...)

	Purpose :
		Save a colormapped buffer to a GIF memory buffer. 
		Source buffer must be colormapped, 8-bit per pixel, vertically 
		oriented as viewed.

   if you specifiy n bits-per-pixel, you must have 2^n palette
	entries, and none of your pixels may have values higher than
	(2^n - 1) . 

	see note for ImgDLLSaveColormappedToGIFMem .

	Param				Type			Use
	pOutBuf			BYTE *		ptr to a caller-allocated destination buffer
	dwBufSize		DWORD			size of dest buffer
	pBuf				BYTE *			image buffer
	uWidthPix		UINT32			width, in pixels
	uHeight			UINT32			height, in pixels
	uBackColor		UINT32			color to set as background color
	iTransparent	__int32			transparent color index, -1 if none
	uBitsPerPixel	UINT32			bits per pixel
	rgbPalette		RGBQUAD *		palette array (2 ^ bitsPerPixel) entries

	modifies global error value, check with	ImgDLLGetLastError()

	Return
		DWORD - size of GIF memory file, in BYTEs

***************************************************************/

DWORD IMGEXP ImgDLLSaveColormappedToGIFMem2(BYTE *pOutBuf,
										DWORD dwBufSize,
                                BYTE * pBuf,
                                UINT32 uWidthPix,
                                UINT32 uHeight,
                                UINT32 backColor,
										  __int32 iTransparent,
										  UINT32	uBitsPerPixel,
                                RGBQUAD *rgbPalette);

/***************************************************************

	BOOL IMGEXP ImgDLLGetGIFDimensions(...)

	Purpose :
		Query a GIF file for image dimensions

	Param				Type			Use
	fileName			const char *	path to open for reading
	width				UINT32*			width, in pixels
	height				UINT32*			height, in pixels

	modifies global error value, check with	ImgDLLGetLastError()

	Return
		TRUE on success

***************************************************************/

BOOL IMGEXP ImgDLLGetGIFDimensions(const char * fileName,
							UINT32 *width,
							UINT32 *height);

/***************************************************************

	HGLOBAL IMGEXP ImgDLLReadRGBFromWMF(...)

	Purpose :
		read a windows metafile to a buffer of RGB BYTEs.

	Param				Type				Use
	filename			const char *	input file
	uWidth			UINT32	*			width of image
	uHeight			UINT32	*			height of image
	uDefWidth		UINT32 *			some WMF images do not have a set size.
											you must specify a default image size.
	uDefHeight		UINT32 *			
	clrBack			COLORREF			background color

	modifies global error value, check with ImgDLLGetLastError()

	Return
		HGLOBAL . 
		Caller must use GlobalUnlock to get a ptr to this buffer!
		Caller is responsible for calling GlobalFree on this buffer!

***************************************************************/

HGLOBAL IMGEXP ImgDLLReadRGBFromWMF(const char * fileName,
													UINT32 *uWidth,
													UINT32 *uHeight,
													UINT32 uDefWidth,
													UINT32 uDefHeight,
													COLORREF clrBack);

/***************************************************************

	HGLOBAL IMGEXP ImgDLLRead8BitFromBMP(...)

	Purpose :
		Read an 8-bit BMP file to a 8-bit Buffer. Does not read
	RL-encoded BMP files. file must be BMP 8 or less. 
	returns DEPTHMISMATCHERR if BMP16 or higher.

	Note that an 8Bit buffer is *not* an RGB buffer! You must
	use ImgDLLRGBFrom8Bit to create a 24-bit buffer from this.

	Param				Type			Use
	fileName			const char *	path to open for reading
	uWidth				UINT32*			width, in pixels
	uHeight				UINT32*			height, in pixels
	pal				RGBQUAD*			ptr to a 256-element RGBQUAD array. from file

	modifies global error value, check with	ImgDLLGetLastError()

	Return
		HGLOBAL . 
		Caller must use GlobalUnlock to get a ptr to this buffer!
		Caller is responsible for calling GlobalFree on this buffer!

***************************************************************/
HGLOBAL IMGEXP ImgDLLRead8BitFromBMP(const char * fileName,
									 UINT32 *width,
									 UINT32 *height,
									 RGBQUAD *pal);

/***************************************************************

	HGLOBAL IMGEXP ImgDLLRead8BitFromGIF(...)
														 
	Purpose :
		Read a GIF file to a 8-bit Buffer. 

	Note that an 8Bit buffer is *not* an RGB buffer! You must
	use ImgDLLRGBFrom8Bit to create a 24-bit buffer from this.

	Param				Type			Use
	fileName			const char *	path to open for reading
	uWidth				UINT32*			width, in pixels
	uHeight				UINT32*			height, in pixels
	pTranscolor			__int32			index in pal of transparent color
	pal				RGBQUAD*			ptr to a 256-element RGBQUAD array. from file

	modifies global error value, check with	ImgDLLGetLastError()

	Return
		HGLOBAL . 
		Caller must use GlobalUnlock to get a ptr to this buffer!
		Caller is responsible for calling GlobalFree on this buffer!

***************************************************************/
HGLOBAL IMGEXP ImgDLLRead8BitFromGIF(const char * fileName,
									 UINT32 *width,
									 UINT32 *height,
									 __int32 *pTranscolor,
									 RGBQUAD *pal);

/***************************************************************

	HGLOBAL IMGEXP ImgDLLRead8BitFromPCX(...)

	Purpose :
		Read a PCX file to a 8-bit Buffer. returns DEPTHMISMATCHERR if 
		PCX-24 or higher.

	Note that an 8Bit buffer is *not* an RGB buffer! You must
	use ImgDLLRGBFrom8Bit to create a 24-bit buffer from this.

	Param				Type			Use
	fileName			const char *	path to open for reading
	uWidth				UINT32*			width, in pixels
	uHeight				UINT32*			height, in pixels
	pal				RGBQUAD *		ptr to a 256-element RGBQUARD array. pal from file

	modifies global error value, check with	ImgDLLGetLastError()

	Return
		HGLOBAL . 
		Caller must use GlobalUnlock to get a ptr to this buffer!
		Caller is responsible for calling GlobalFree on this buffer!

***************************************************************/
HGLOBAL IMGEXP ImgDLLRead8BitFromPCX(const char * fileName,
									 UINT32 *width,
									 UINT32 *height,
									 RGBQUAD *pal);

/***************************************************************

	ImgDLLReadRGBFromTGA(...)

	Purpose :
		Read a TGA file to a buffer of RGB bytes.

	Param               Type            Use
	fileName            const char *    path to open for reading
	uWidth              UINT32*           width, in pixels
	uHeight             UINT32*           height, in pixels

	modifies global error value, check with ImgDLLGetLastError()

	Return
		HGLOBAL . 
		Caller must use GlobalLock to get a ptr to this buffer!
		Caller is responsible for calling GlobalFree on this buffer!

***************************************************************/

HGLOBAL IMGEXP ImgDLLReadRGBFromTGA(const char * fileName,
                             UINT32 *width,
                             UINT32 *height);

/***************************************************************

	BOOL ImgDLLSaveRGBToTGA(...)

	Purpose :
		Write a 24-bit TGA file from a 24-bit RGB buffer

	Param				Type			Use
	fileName			const char *	path to open for writing
	pRGB				BYTE *			ptr to the image
	uWidth				UINT32*			width, in pixels
	uHeight				UINT32*			height, in pixels

	modifies global error value, check with	ImgDLLGetLastError()

	Return
		TRUE on success

***************************************************************/
						 
BOOL IMGEXP ImgDLLSaveRGBToTGA(LPCSTR lpFileName,
							BYTE *pRGB,
							UINT32 nWidth,
							UINT32 nHeight);

/***************************************************************

	BOOL IMGEXP ImgDLLGetTGADimensions(...)

	Purpose :
		 Query a TGA file for image dimensions

	Param               Type            Use
	fileName            const char *    path to open for reading
	width               UINT32*           width, in pixels                                             
	height              UINT32*           height, in pixels

	modifies global error value, check with ImgDLLGetLastError()

	Return
		 TRUE on success

***************************************************************/

BOOL IMGEXP ImgDLLGetTGADimensions(const char * fileName,
                            UINT32 *width,
                            UINT32 *height);

/***************************************************************

	BOOL IMGEXP ImgDLLSaveColormappedToTGA(...)

	Purpose :
		Write an 8-bit TGA file from a colormapped buffer

	Param				Type			Use
	fileName			const char *	path to open for writing
	pRGB				BYTE *			ptr to the 8-bit image
	uWidth			UINT32			width, in pixels
	uHeight			UINT32			height, in pixels
	nColors			UINT32			number of colors in pPal
	pPal				RGBQUAD *		ptr to nColors RGBQUADs

	modifies global error value, check with	ImgDLLGetLastError()

	Return
		TRUE on success

***************************************************************/

BOOL IMGEXP ImgDLLSaveColormappedToTGA(LPCSTR lpFileName,
														BYTE *p8Bit,
														UINT32 nWidth,
														UINT32 nHeight,
														UINT32 nColors,
														RGBQUAD *pPal);

/***************************************************************

	HGLOBAL IMGEXP ImgDLLRead8BitFromTGA(...)

	Purpose :
		Read a TGA file to a 8-bit Buffer. returns DEPTHMISMATCHERR if 
		not TGA-8

	Note that an 8Bit buffer is *not* an RGB buffer! You must
	use ImgDLLRGBFrom8Bit to create a 24-bit buffer from this.

	Param				Type			Use
	fileName			const char *	path to open for reading
	uWidth			UINT32*			width, in pixels
	uHeight			UINT32*			height, in pixels
	pal				RGBQUAD *		ptr to a 256-element RGBQUARD array. pal from file

	modifies global error value, check with ImgDLLGetLastError()

	Return
		HGLOBAL . 
		Caller must use GlobalUnlock to get a ptr to this buffer!
		Caller is responsible for calling GlobalFree on this buffer!

***************************************************************/
HGLOBAL IMGEXP ImgDLLRead8BitFromTGA(const char * fileName,
													 UINT32 *width,
													 UINT32 *height,
													 RGBQUAD *pal);

/***************************************************************

	BOOL IMGEXP ImgDLLDrawSolidRectOnRGB(...)

	Purpose :
		Draw a solid color rectangle on an RGB image

	Param						Type           Use
	pRGB						BYTE *			pointer to your image
	width						UINT32*        width, in pixels                                             
	height					UINT32*        height, in pixels
	rectStartX				UINT32			start rect at this position	
	rectStartY				UINT32			start rect at this position	
	rectWidth				UINT32			width of rect
	rectHeight				UINT32			height of rect
	clr						COLORREF			color to fill with

	modifies global error value, check with ImgDLLGetLastError()

	Return
      TRUE on success

***************************************************************/

BOOL IMGEXP ImgDLLDrawSolidRectOnRGB(BYTE *pRGB,
													 UINT32 w,
													 UINT32 h,
													 UINT32 rectStartX,
													 UINT32 rectStartY,
													 UINT32 rectWidth,
													 UINT32 rectHeight,
													 COLORREF clr);


/***************************************************************

HGLOBAL IMGEXP ImgDLLCreateCPngIS(...)

	Purpose :
		Create a PNG Compression structure for single-line
	PNG compression.

		This is to be used in conjunction with ImgDLLWriteNextCPngISLine
	and ImgDLLDestroyCPngIS.

		You must call ImgDLLDestroyCPngIS to free the memory associated
	with this object!

		See ImgDLLv4.rtf for example

		This routine can take a large variety of input image
	formats, not just packed RGB!. There is not much error checking 
	done on the input data. Be sure that what you are passing is in the
	format you say it is!! 

	Writes any text fields added with ImgDLLAddPNGText

	Please read the PNG Notes in the ImgDLLv4.RTF file.

	Param				Type				Use
	imageFileName	const char *	file to write
	inWidthPix		UINT32			image width, in pixels
	inHeight			UINT32			image height
	inWidthBytes	UINT32			width of an image row, in BYTEs
	bitDepth			UINT32			1, 2, 4, 8, or 16 bits/channel
	colors			UINT32			number of colors in palette

	inPalette		RGBQUAD *		palette entries. there must be at least
											as many RGBQUADs as specified by "colors".
											if your image does not use a palette, pass
											NULL for this parameter.

	colorType		UINT32			this tells the PNG writer which format the
											input image is in, see PNG_COLOR_* definitions

	gammaVal		double				if you know the display gamma of the device this 
											image was created on, pass a value equal 
											to 1 / display_gamma. according to the PNG docs,
											a value of .45 is acceptable for most PCs

	filterMask		UINT32			filter to apply to the image. as of LibPng-0.96,
											the only valid value is 0.

	modifies global error value, check with ImgDLLGetLastError()

	Return
		HGLOBAL to be passed to the other CTifIS functions

***************************************************************/

HGLOBAL IMGEXP ImgDLLCreateCPngIS(const char *imageFileName, 
											  UINT32 inWidthPix, 
											  UINT32 inHeight, 
											  UINT32 inWidthBytes,
											  UINT32 bitDepth,
											  UINT32 colors,
											  RGBQUAD * inPalette, 
											  UINT32 colorType,
											  double gammaVal,
											  UINT32 filterMask);

/***************************************************************

	BOOL IMGEXP ImgDLLWriteNextCPngISLine(...)

	Purpose :
		Write the next scan line to a TIFF file previously
	opened with ImgDLLCreateCPngIS.

		This is to be used in conjunction with ImgDLLCreateCPngIS
	and ImgDLLDestroyCPngIS.

		See ImgDLLv4.rtf for example

	Param				Type				Use
	hCPngIS			HGLOBAL			returned from ImgDLLCreateCPngIS
	pImageRow		BYTE *			pointer to the image row to write

	modifies global error value, check with ImgDLLGetLastError()

	Return
		TRUE on success. FALSE when end of file or error. 
		check for IMGNOLINES from ImgDLLGetLastError()

***************************************************************/

BOOL IMGEXP ImgDLLWriteNextCPngISLine(HGLOBAL hCPngIS,
													BYTE *pImageRow);

/***************************************************************

	BOOL IMGEXP ImgDLLDestroyCPngIS(...)

	Purpose :
		Release the memory associated with this object. This
	object was previously allocated by ImgDLLCreateCPngIS.

		This is to be used in conjunction with ImgDLLCreateCPngIS
	and ImgDLLWriteNextCPngISLine.

		See ImgDLLv4.rtf for example

	Param				Type				Use
	hCPngIS				HGLOBAL			returned from ImgDLLCreateCPngIS

	modifies global error value, check with ImgDLLGetLastError()

	Return
		TRUE on success

***************************************************************/
BOOL IMGEXP ImgDLLDestroyCPngIS(HGLOBAL hCPngIS);

/***************************************************************

	HGLOBAL IMGEXP ImgDLLCreateCTifIS(...)

	Purpose :
		Create a TIFF Compression structure for single-line
	TIFF compression.

		This is to be used in conjunction with ImgDLLWriteNextCTifISLine
	and ImgDLLDestroyCTifIS.

		You must call ImgDLLDestroyCTifIS to free the memory associated
	with this object!

		See ImgDLLv4.rtf for example

	Param				Type				Use
	fileName			const char *	path to open for reading
	widthPix			UINT32			width of image, in pixels
	height			UINT32			height, in pixels
	bitsPerPixel	UINT32			24 or 8 . if 24, data must be 24-bit RGB. if 8, data must be 8-bit
											and you must supply a palette of 256 RGBQUADs
	pPal				RGBQUAD *		ptr to a palette of 256 colors.

	modifies global error value, check with ImgDLLGetLastError()

	Return
		HGLOBAL to be passed to the other CTifIS functions

***************************************************************/
HGLOBAL IMGEXP ImgDLLCreateCTifIS(const char *imageFileName, 
											  UINT32 nWidthPix, 
											  UINT32 nHeight,
											  UINT32 nBitsPerPixel,
											  RGBQUAD *pPal);

/***************************************************************

	BOOL IMGEXP ImgDLLWriteNextCTifISLine(...)

	Purpose :
		Write the next scan line to a TIFF file previously
	opened with ImgDLLCreateCTifIS.

		This is to be used in conjunction with ImgDLLCreateCTifIS
	and ImgDLLDestroyCTifIS.

		See ImgDLLv4.rtf for example

	Param				Type				Use
	hCTifIS			HGLOBAL			returned from ImgDLLCreateCTifIS
	pImageRow		BYTE *			pointer to the image row to write

	modifies global error value, check with ImgDLLGetLastError()

	Return
		TRUE on success. FALSE when end of file or error. 
		check for IMGNOLINES from ImgDLLGetLastError()

***************************************************************/
BOOL IMGEXP ImgDLLWriteNextCTifISLine(HGLOBAL hCTifIS,
													BYTE *pImageRow);

/***************************************************************

	BOOL IMGEXP ImgDLLDestroyCTifIS(...)

	Purpose :
		Release the memory associated with this object. This
	object was previously allocated by ImgDLLCreateCTifIS.

		This is to be used in conjunction with ImgDLLCreateCTifIS
	and ImgDLLWriteNextCTifISLine.

		See ImgDLLv4.rtf for example

	Param				Type				Use
	hCTifIS				HGLOBAL			returned from ImgDLLCreateCTifIS

	modifies global error value, check with ImgDLLGetLastError()

	Return
		TRUE on success

***************************************************************/
BOOL IMGEXP ImgDLLDestroyCTifIS(HGLOBAL hCTifIS);

/***************************************************************

	HGLOBAL IMGEXP ImgDLLCreateCPcxIS(...)


	Purpose :
		Create a PCX Compression structure for single-line
	PCX compression.

		This is to be used in conjunction with ImgDLLWriteNextCPcxISLine
	and ImgDLLDestroyCPcxIS.

		You must call ImgDLLDestroyCPcxIS to free the memory associated
	with this object!

		See ImgDLLv4.rtf for example

	Param				Type				Use
	fileName			const char *	path to open for reading
	widthPix			UINT32			width of image, in pixels
	height			UINT32			height, in pixels
	bitsPerPixel	UINT32			24 or 8 . if 24, data must be 24-bit RGB. if 8, data must be 8-bit
											and you must supply a palette of 256 RGBQUADs
	pPal				RGBQUAD *		ptr to a palette of 256 colors.

	modifies global error value, check with ImgDLLGetLastError()

	Return
		HGLOBAL to be passed to the other CPcxIS functions

***************************************************************/
HGLOBAL IMGEXP ImgDLLCreateCPcxIS(const char *imageFileName, 
											  UINT32 inWidthPix, 
											  UINT32 inHeight,
											  UINT32 nBitsPerPixel,
											  RGBQUAD *pPal);

/***************************************************************

	BOOL IMGEXP ImgDLLWriteNextCPcxISLine(...)

	Purpose :
		Write the next scan line to a PCX file previously
	opened with ImgDLLCreateCPcxIS.

		This is to be used in conjunction with ImgDLLCreateCPcxIS
	and ImgDLLDestroyCPcxIS.

		See ImgDLLv4.rtf for example

	Param				Type				Use
	hCTgaIS			HGLOBAL			returned from ImgDLLCreateCPcxIS
	pImageRow		BYTE *			pointer to the image row to write

	modifies global error value, check with ImgDLLGetLastError()

	Return
		TRUE on success. FALSE when end of file or error. 
		check for IMGNOLINES from ImgDLLGetLastError()

***************************************************************/

BOOL IMGEXP ImgDLLWriteNextCPcxISLine(HGLOBAL hCPcxIS,
													BYTE *pImageRow);

/***************************************************************

	BOOL IMGEXP ImgDLLDestroyCPcxIS(...)

	Purpose :
		Release the memory associated with this object. This
	object was previously allocated by ImgDLLCreateCPcxIS.

		This is to be used in conjunction with ImgDLLCreateCPcxIS
	and ImgDLLWriteNextCPcxISLine.

		See ImgDLLv4.rtf for example

	Param				Type				Use
	hCPcxIS				HGLOBAL			returned from ImgDLLCreateCPcxIS

	modifies global error value, check with ImgDLLGetLastError()

	Return
		TRUE on success

***************************************************************/

BOOL IMGEXP ImgDLLDestroyCPcxIS(HGLOBAL hCPcxIS);

/***************************************************************

	HGLOBAL IMGEXP ImgDLLCreateCTgaIS(...)

	Purpose :
		Create a TGA Compression structure for single-line
	TGA compression.

		This is to be used in conjunction with ImgDLLWriteNextCTgaISLine
	and ImgDLLDestroyCTgaIS.

		You must call ImgDLLDestroyCTgaIS to free the memory associated
	with this object!

		See ImgDLLv4.rtf for example

	Param				Type				Use
	fileName			const char *	path to open for reading
	widthPix			UINT32			width of image, in pixels
	height			UINT32			height, in pixels
	bitsPerPixel	UINT32			24 or 8 . if 24, data must be 24-bit RGB. if 8, data must be 8-bit
											and you must supply a palette of "colors" RGBQUADs
	colors			UINT32			colors in palette
	pPal				RGBQUAD *		ptr to a palette of "colors" colors.

	modifies global error value, check with ImgDLLGetLastError()

	Return
		HGLOBAL to be passed to the other CTgaIS functions

***************************************************************/

HGLOBAL IMGEXP ImgDLLCreateCTgaIS(const char *imageFileName, 
											  UINT32 inWidthPix, 
											  UINT32 inHeight,
											  UINT32 bitsPerPixel,
											  UINT32 colors,
											  RGBQUAD *pPal);

/***************************************************************

	BOOL IMGEXP ImgDLLWriteNextCTgaISLine(...)

	Purpose :
		Write the next scan line to a TGA file previously
	opened with ImgDLLCreateCTgaIS.

		This is to be used in conjunction with ImgDLLCreateCTgaIS
	and ImgDLLDestroyCTgaIS.

		See ImgDLLv4.rtf for example

	Param				Type				Use
	hCTgaIS			HGLOBAL			returned from ImgDLLCreateCTgaIS
	pImageRow		BYTE *			pointer to the image row to write

	modifies global error value, check with ImgDLLGetLastError()

	Return
		TRUE on success. FALSE when end of file or error. 
		check for IMGNOLINES from ImgDLLGetLastError()

***************************************************************/

BOOL IMGEXP ImgDLLWriteNextCTgaISLine(HGLOBAL hCTgaIS,
													BYTE *pImageRow);


/***************************************************************

	BOOL IMGEXP ImgDLLDestroyCTgaIS(...)

	Purpose :
		Release the memory associated with this object. This
	object was previously allocated by ImgDLLCreateCTgaIS.

		This is to be used in conjunction with ImgDLLCreateCTgaIS
	and ImgDLLWriteNextCTgaISLine.

		See ImgDLLv4.rtf for example

	Param				Type				Use
	hCTgaIS				HGLOBAL			returned from ImgDLLCreateCTgaIS

	modifies global error value, check with ImgDLLGetLastError()

	Return
		TRUE on success

***************************************************************/
BOOL IMGEXP ImgDLLDestroyCTgaIS(HGLOBAL hCTgaIS);


#ifdef __cplusplus
}
#endif


#endif