************************************************************************
           Welcome to Irie Pascal for Windows Version 1.00
************************************************************************

Please make sure that you have the following files:

Documentation:
--------------
readme.txt    - This file
user.txt      - The Irie Pascal User's Guide
progref.txt   - The Irie Pascal Programmer's Reference Manual
orderus.txt   - The Order Form for US dollar Registrations
orderca.txt   - The Order Form for Canadian dollar Registrations
orderuk.txt   - The Order Form for UK pound Registrations
shareware.txt - Describes the shareware concept (derived from documentation
                produced by the Association of Shareware Professionals (ASP)).
                NOTE: I am not a member of this association.

Programs:
---------
ipc.exe       - Irie Pascal Compiler for Windows
ivm.exe       - Irie Virtual Machine Interpreter for Windows

Sample programs:
----------------
samples.zip
   or
samples.exe

The sample programs are provided mostly to help you veryify that
Irie Pascal has been installed correctly. You may however find a few of
the sample programs like split.pas, lines.pas, calc.pas or ascii.pas useful.
