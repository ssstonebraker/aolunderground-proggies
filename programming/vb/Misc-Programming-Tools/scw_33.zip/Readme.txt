+-----------------------------------------------+
| SmartChart 3.3                                |
| 32-Bit release for Windows 95/98/NT           |
| Copyright (c) 1998 ProFile Software & Systems |
+-----------------------------------------------+
| Address:  29 Mishol Hadas st.                 |
|           Jerusalem    97277                  |
|           Israel                              |
| Tel:      972-2-5865429                       |
| Fax:      972-2-5710364                       |
| Sales:    sales@profilesoft.com               |
| Support:  support@profilesoft.com             |
| Web site: http://www.profilesoft.com          |
+-----------------------------------------------+


Table Of Contents
-----------------
1.  Introduction
2.  Integrating with SmartChart
3.  The Input File
    3.1.  The Structure of the Input File
    3.2.  The Data Section
    3.3.  Adding Titles and Controlling Fonts
    3.4.  Multiple Series
    3.5.  Controlling the Y-axis Scale
    3.6.  Batch Execution
    3.7.  From Here...
4.  Displaying Many Values in Line Graph
5.  Adding Graphs to Your Web Page Using SmartChart
6.  The User Interface
7.  Summary of All Reserved-Words
8.  Common Error Messages
9.  New Features since Version 3.1
10. New Features since Version 3.2
11. Order information


1.  Introduction
----------------
SmartChart is a product of ProFile Software & Systems,
that provides a simple and fast solution for creating
and displaying graphs from within custom application. 
SmartChart can be used with any programming language or
RAD tools that can generate a text file and execute a
program.

With SmartChart you can run off-line (batch) processes 
enabling generation of several graphs directed into 
different channels such as a printer, a BMP file, a JPEG 
file and the clipboard. This feature enables you to add 
graphs to your web page (see section 4).

Communicating with SmartChart is a simple task: your 
application just needs to create a simple text file and
execute SmartChart with the file name as its argument. 
This way of communication saves the overhead of interfacing
another process using DDE/OLE, and most important -- saves 
time and money during development.

SmartChart also saves you the time needed to deal with the
implementation of graphics, printing and the MMI.
It provides a simple and friendly interface that the user
can master in no time.


2.  Integrating with SmartChart
-------------------------------
The communication with SmartChart is extremely simple; your
program should create a script file containing the values,
titles and other optional attributes, and execute SmartChart
with the file name as its argument.


3.  The Input File 
-------------------

3.1.  The Structure of the Input File:
--------------------------------------
The input file is similar to a Windows .INI file.
It consist of sections, where each section contains statements
of the form x = y.

There are three kinds of sections:

A. Data Section:
   Contains the values to be displayed in the graphs, and the
   labels of the X axis in the bars and line graphs. This 
   section must appear in the input file, while the other
   sections are optional.
   The data section starts with the statement: [DATA]

B. Declarations Section:
   Contains declarations where each kind is optional and has
   a default value(s) in case it doesn't appear in the input
   file. In this section you can specify titles, control fonts,
   control the Y axis scale and more. The declaration section
   starts with the statement: [DECLARATIONS]

C. Batch Section:
   This section provides the capabilities to execute a set of
   commands with or without opening SmartChart's main window 
   and without user intervention.
   Using this section you can generate graphs and redirect the 
   output to different channels, such as a printer, a BMP file, 
   a JPEG file and the clipboard.
   The batch section starts with the statement: [BATCH]

The syntactic structure of the input file is extremely simple
and flexible:
  * You can write remarks using the reserved word 'Rem' at 
    the start of a line.
  * Tabs, spaces and empty lines are discarded to enable
    indentation.
  * reserved words are not case-sensitive.
  * The line order in the declarations section is insignificant.
  * Sections can appear many times in the input file, at
    any order.

3.2.  The Data Section:
----------------------- 
We'll explain the syntax of the input file in a tutorial
fashion, using a simple example, where at each step we will add 
more features. 
Suppose we want to display a sales graph of the factory 
"Turbo-Motors Inc." for the period of January '96 up to
June '96. The following input, when executed with SmartChart, 
will produce five types of graphs. The X-axes in the bars and
line graphs will have labels for each data item.

Rem *** example #1 ***
[DATA]
January   = 70
February  = 90
March     = 160
April     = 85
May       = 76
June      = 91 

To the left of the '=', there are the X-axis labels and to 
the right of the '=', their corresponding values.

3.3.  Adding Titles and Controlling Fonts
-----------------------------------------
Now, let's make this a little bit more interesting by adding a 
declarations section:

Rem *** example #2 ***

[DECLARATIONS]
Rem *** specify titles:
Main_Title = Torbo-Motors Inc. 
Sub_Title  = Sales in Jan '96 - Jun '96

Rem *** specify fonts:
Main_Title_Font = Times New Roman
Sub_Title_Font  = Courier New
Graph_Font      = Arial
Legend_font     = Courier New

Rem *** Choose first graph to be displayed...
Default_Graph   = Pie3D

[DATA]
January   = 70
February  = 90
March     = 160
April     = 85
May       = 76
June      = 91 

As you can see, we added titles to our graphs, and determined 
their fonts. The fonts settings are optional and can be 
controlled from within SmartChart. In addition, axis titles may
also be added using the x_title and y_title declarations.
For a summery of all declarations, see section 6, "Summary of
all reserved-words".
Remark: For convenience, you may enclose strings, such as
titles, in double quotes.

3.4.  Multiple Series
---------------------
The above example had only one series of values. Now, let's add
some more series. Suppose "Turbo-Motors Inc." have three
departments: Cars, Trucks and Vans. 
We wish to show the sales graph in all three departments.
Example 3 shows how to define more than one series of values. 
SmartChart supports up to six series.

Rem *** example #3 ***

[DECLARATIONS]

Rem *** specify titles:
Main_Title = Torbo-Motors Inc.
Sub_Title  = Sales in Jan '96 - Jun '96

Rem *** Choose first graph to be displayed...
Default_Graph = Pie3D

Rem *** Override default names of series
Series_Names = Cars, Trucks, Vans

Error_Message = Please contact the support | Phone No. XXXXXXX

[DATA]
January  = 70, 50, 90
February = 90, 30.5, 75
March    = 160, 85, 120
April    = 85, 110, 115.5
May      = 76, 95.2, 12
June     = 91, 12.34, 15

The declaration "Series_Names" overrides the default names given
by SmartChart. These names are: "#1", "#2", "#3", ... The names 
of the series appear in the legend of the bars and line graphs, 
in the bottom of the pie charts, and in the menu when selecting 
the "series" menu item. Since the pie charts can display one 
series at a time, selecting the series is done by choosing the
name of the series from the main menu or by clicking the right 
mouse button and selecting the series name from the pop-up menu.
You can specify the first series to be displayed as a pie chart
using the following declaration: Default_Series = name-of-series.
Since the lines in the declaration section may be at any order, 
one can specify the default series name before declaring the
names of the series, therefore the following combination is 
legal:

Defalue_Pie = Trucks
Series_Names = Cars, Trucks, Vans

Not all series can be displayed as a pie chart. If a series has
negative values or all its values are zero, than this series can
not be displayed as a pie chart. In this case, the name of the 
series will be grayed in the menu. 
If there are no series that can be displayed as pie charts, than
the pie buttons will become gray (disabled). The pie graphs enable 
display of up to 60 values (slices). If more values present, the 
pie buttons will become disabled.
If you specify in the Default_Series declaration a name of 
a series that can not be displayed as a pie chart, an error
message will appear on execution.

3.5.  Controlling the Y-axis Scale
----------------------------------
The default scale of the Y-axis can be changed using the proper 
declarations in the declarations section. The graph/settings
menu option enables on-line control on the Y-axis scale.
The Y-axis is divided into 10 intervals. There are two
attributes which control the scale of the Y-axis:
* The minimum value - can be changed using the 
  declaration: Min_Value = value.
* The incremental step - can be changed 
  using the declaration: YStep = value.

Note: when setting these values, make sure that the following
holds: min_value + 10*y_step >= max_value, where max_value is
the largest value in all series. Otherwise, an error message
will appear on execution.

3.6   Batch Execution
---------------------
The batch section enables you to execute a set of commands with 
or without opening SmartChart's main window and without user 
intervention. Using this section you can generate graphs and 
redirect the output into different channels.
This section contains a batch program with commands for
selecting graph type, selecting series and redirecting the
output to the printer, a BMP file, a JPEG file and to the
clipboard.
The batch section, like the other sections, can be placed
anywhere in the input file and may be partitioned into
sub-sections.
Following is the set of the batch commands. The parameters
are marked with '*'.

- Bar; Bar3D; Pie; Pie3D; Line  
  Select the graph type

- Series *name-of-series*   
  Select the series specified by *name-of-series*

- Generate_Bitmap "filename.bmp" *width* *height*
  Render the graph directly into a bitmap file. The filename,
  width and height of the bitmap are all optional.
  Only The following combinations are legal:
  * Generate_Bitmap 
    The destination file name, width and height are not
    specified, default file-name and default dimensions will
    be used.
  * Generate_Bitmap filename.bmp  
    The width and height are not specified, default dimensions
    will be used.
  * Generate_Bitmap "filename.bmp" 640
    The height is not specified, default height will be used.
  * Generate_Bitmap "filename.bmp" 640 480
    Both the file name and the dimensions are specified.
  
- Generate_Jpeg "filename.jpg" *width* *height*
  Render the graph directly into a jpeg file. The file name,
  width and height of the image are all optional.
  See "Generate_Bitmap"

- Copy *width* *height*
  Render the graph directly into the clipboard. The filename,
  width and height of the bitmap are all optional.
  See "Generate_Bitmap"

- Print
  Print the current graph with the default printer.

- Exit
  Quit SmartChart without opening the main application window.

Example of a batch program:

[Batch]
Bar
Copy
Pie3D
Series Trucks
Print
Series Cars
Print
Copy
Line
Generate_Bitmap "example.bmp" 640 480
Bar3D
Generate_Jpeg "example.jpg" 640 480
Exit
[Declarations]
.
.
.
[Data]
.
.
.


3.6.  From Here...
------------------
The above examples can get you started. The rest of the options 
are described in section 7, "Summary of all Reserved-Words".


4. Displaying Many Values in Line Graph
----------------------------------------
SmartChart allows you to display up to 1000 values in a line
graph in one screen (without scrolling).
Up until now, the amount of data that could be displayed in one 
screen was limited to 25 values. The reason for this limitation was 
that the x-axis names were overlapping. SmartChart allows you to 
display up to 1,000 values in one screen as line graph by changing the 
method of displaying column names. When the programmer instructs 
SmartChart to display more than 25 values in one screen, the column 
names disappear (except those that are especially marked) and when the 
mouse crosses the lines, the value and name of the column are displayed 
in a Tool-Tip window.
In order to determine which values will be presented in the a-axis of
the line graph, you should add a '/Ticker' (or a '#' sign) to the data 
line. Only titles marked as tickers will be displayed in the line graphs
when more than 25 values are being rendered.
In addition, the line values will not appear in this mode. The switch to
the above mode is done automatically when the programmer/user requests
to display more than 25 values in a screen.
Example: 
January = 25.3, 11.7 /ticker
February = 11.7, 22.1 #


5. Adding Graphs to Your Web Page Using SmartChart
--------------------------------------------------
With SmartChart you can easily add graphs to your web page
(providing that your web server runs Windows NT).
You just need generate the input file with a batch section that 
saves the graph in a Jpeg file, and use its URL. In the end of 
the batch section, use the 'exit' command.

Example:

[Declarations]
.....
[Batch]
Bar
Generate_Jpeg "myURL\Bar.jpg"
Bar3D
Generate_Jpeg "myURL\Bar3D.jpg"
Pie3D
Generate_Jpeg "myURL\Pie3D.jpg"
Exit
[Data]
.....


6. The User Interface
---------------------
SmartChart provides a simple MMI that the user can master in
no time. All five types of graphs may be selected either from 
the tool bar or from the menu. We minimized the functionality
of SmartChart to enable a simple-to-use graph viewer, therefore
no complicated option are given to the user. The advanced 
options, such as "open file" and "graph settings" can be 
removed using the appropriate declarations in the input file.
SmartChart can be used as a graph server for an application or as
a stand-alone program, where the user is provided with
advances options.

SmartChart has full keyboard support, including "Hot keys".
The following is the key-action table:

Key	          Action
------------------------------------------
Alt+1          Bar Graph
Alt+2          Pie Graph
Alt+3          3-D Bar Graph
Alt+4          3-D Pie Graph
Alt+5          Line Graph
Ctrl+S         Save
Ctrl+P         Print
Ctrl+C         Copy to clipboard
Ctrl+O         Open file
Left Arrow     Scroll values to the left
Right Arrow    Scroll values to the right
Home           Scroll values to the start
End            Scroll values to the end
Pg Up          Scroll few values to the left
Pg Down        Scroll few values to the right

7. Summary of all Reserved-Words
--------------------------------
- Main_Title = *string*
  This declaration enables you to specify the main title to be 
  displayed above the graphs. *string* is the title-string and
  may be enclosed in double quotes.
  If the size of the title is too long, than the size of the
  title's font will be automatically adjusted to fit the window.
  example: Main_Title =  "Torbo-Motors Inc."
  default: no main-title.

- Sub_Title = *string*
  This declaration enables you to specify the sub-title to be
  displayed above the graphs. see Main_Title for more information.
  example: Sub_Title = "Sales in Jan '96 - Jun '96"
  default: no sub-title.

- X_Title = *string*
  Set a title for the X axis.
  default: None

- Y_Title = *string*
  Set a title for the Y axis.
  default: None

- Main_Title_Font = *name-of-font*
  This declaration enables you to control the font of the main
  title. *name-of-font* specifies the name of the typeface of 
  the font as defined in the [FONTS] section of WIN.INI.
  If the font name does not exist, than the system font will be
  used automatically (no error message will be given).
  example: Main_Title_Font = "Times New Roman"
  default: "Times New Roman Bold"

- Sub_Title_Font = *name-of-font*
  This declaration enables you to control the font of the
  sub-title. See Main_Title_Font for more information.
  example: Sub_Title_Font = "Times New Roman"
  default: "Courier New Bold"

- Legend_Font = *name-of-font*
  This declaration enables you to control the font of the
  legend. See Main_Title_Font for more information.
  example: Legend_Font = "Times New Roman"
  default: "Arial"

- Graph_Font = *name-of-font* 
  This declaration enables you to control the font of the text
  in the graph, including the Y-axis values, X-axis labels, 
  and the values above the bars and around the pie charts.
  See Main_Title_Font for more information.
  example: Graph_Font = "Times New Roman"
  default: "Arial"

- Default_Graph = *name-of-graph*
  Enables you to choose the first graph to be displayed when
  executing SmartChart. 
  *name-of-graph* must be one of the following names:
  "bar", "bar3D", "pie", "pie3D" or "line". As in all reserved
  words, the graph's names are not case sensitive.
  example: Default_Graph = Pie3D
  default: Bar3D

- Series_Names = series1_name, series2_name, ... 
  This declaration enables you to label the series. The names
  must be separated with commas and the number of names must
  agree with the number of series as defined in the data
  section, otherwise, an error message will appear on execution.
  example: Series_Names = Japan, Thailand, India 
  default: "#1", "#2", "#3", ...     

- Default_Series = *name-of-series*
  Enables you to choose the first series to be displayed as a 
  pie chart. *name-of-series* is the name of the series as
  defined in the Series_Names declaration. If the names of the
  series are not defined, than you may use the default names,
  for example: Default_Series = #3. The names of the series
  are not case-sensitive.
  example: Default_Series = "Japan"
  default: the first series that can be displayed as a pie
           chart.

- Bar_Values = on/off
  This declaration enables you to toggle the display of the
  values above the bar graph.
  This option is available for the user via the "Graph Settings"
  dialog box.
  example: Bar_Values = off
  default: on.

- Bar3D_Values = on/off
  see Bar_Values.

- Line_Values = on/off
  see Bar_Values.

- Pie_Values = on/off
  This declaration enables you to toggle the display of the 
  values around the pie chart.
  This option is available for the user via the "Graph Settings"
  dialog box.
  example: Pie_Values = off
  default: on.

- Pie3D_Values = on/off
  see Pie_Values.

- Pie_Legend = Values / Percentage / Both
  Determine what to display in the legend of the pie 
  charts (values, percentage or both).
  This option is available for the user via the "Graph Settings"
  dialog box.
  example: Pie_Legend = Both
  default: Values

- Min_Value = *value*
  Enables you to set the minimum value of the Y-axis scale in 
  the bars and line graphs. Make sure that *value* is not
  greater than the minimum value of all series. 
  Using this declaration and the Ystep declaration, you can
  fully control the scale of the Y-axis.
  This option is available for the user via the "Graph
  Settings" dialog box.
  example: Min_Value = -100
  default: automatic

- YStep = *value*
  Enables you to set the incremental step of the Y-axis values
  in the bars and line graphs. With the Min_Value declaration,
  you can fully control the scale of the Y-axis. Make sure that
  the following holds:
    min_value + 10*y_step >= max_value, where max_value is the
    largest value in all series.
  This option is available for the user via the "Graph Settings" 
  dialog box.
  example: YStep = 50
  default: automatic

- Values_In_Bar = *number*
  Use this option to determine the number of values that will
  fit in the bar graph. This value may range from 1 to 25.
  This option is available for the user via the "Graph Settings"
  dialog box.
  example: Values_In_Bar = 10
  default: automatic

- Values_In_Bar3D = *number*
  see Values_In_Bar

- Values_In_Line = *number*
  see Values_In_Bar

- Error_Messgae = *error-message*
  Enables you to display a message in the error dialog-box when
  an error occurs (such as "contact the technical support...").
  *error-message* is the message string.
  Since a declaration is limited to a single line, you can break
  the message into more than one line using the '|' character.
  example: Error_Message = "contact the support|Telephone: 99-99"
  default: no error message.

- Allow_Open_File = yes/no
  If this option is "no", than the "Open" and "Close" menu items
  from the "File" menu option will be removed. Set this option
  to "no" in order to simplify the user interface or to prevent
  the user from opening undesirable files.
  default: "yes" (allow open files).

- Allow_Save_File = yes/no
  If this option is "no", than the "Save" and "Save As" menu
  items from the "File" menu option will be removed. Set this
  option to "no" in order to simplify the user interface or to
  prevent the user from saving undesirable files.
  default: "yes" (allow open files).

- Allow_Graph_Settings = yes/no
  If this option is "no", than the "Settings" menu item from the
  "Graph" menu option will be removed. Set this option to "no"
  in order to simplify the user interface.
  default: yes (allow change of graph settings).

- Enable_Objects = yes/no
  Using this declaration you can turn on or off the user selection 
  mode. In this mode the user can select objects, move and resize them.
  This mode can also be toggled from the edit menu.
  default: yes

- Window_Size = Normal/Maximized/Minimized
  Set the initial window size.
  default: Normal.

- Language = English/Hebrew
  SmartChart supports right-to-left user interface for hebrew users. 
  Using this declaration you can determine the language.
  default: English

8. Common Error Messages
------------------------
In this section we will cover some of the most common error
messages. The rest of the error messages are straightforward
or extremely rare.
	
- "file error or file not found." 
  An error occurred while SmartChart was trying to open the
  input file. The file could be damaged or missing.            

- "default graph syntax error."
  A declaration of the form Default_Graph = ... must have a
  name of a graph on the right hand side of the '='. The
  names are: Bar, Bar3D, Pie, Pie3D, Line.

- "number of series does not agree with previous declaration."
  This error occurs when not all lines in the data section have
  the same number of values.

- "'=' expected."
  All lines within a section (except those who declare a 
  new section) must be of the form x=y. If the '=' character
  is missing, this error will appear. 

- "default pie - series does not exist."
  The name of the series that was used in the Default_Series
  declaration was not declared in the Series_Names declaration.

- "can not display this series as pie chart. Probably has 
  negative values."
  The series that was chosen to be displayed as a pie in the
  Default_Series declaration can not be displayed as a pie.
  Series that have negative values or all their values are
  zero can not be displayed as pie charts.

- "--- expected."
  A group of error messages which occur when the right-hand
  side of the declaration does not match the type of the
  declaration. For example: "Incremental step expected".

- "file has no data section."
  This error occurs when an input file has no data section.
  This section must be in the input file.

- "syntax error."
  The most common error message. This error occurs when a line
  begins with an unknown word. 

- "show-values error. Should specify on or off"
  This error regards the Bar_Values and the Pie_Values
  declarations.

- "incremental step error. Probably too small."
  This error occurs when the incremental step is too small, such
  that min_value + 10*ystep < max_value; 

- "number of series names does not agree with the data."
  This error occurs when the number of series names as defined
  in the Series_Names declaration is not equal to the number of
  series as defined in data section. 

- "too many values in series. no more than 50 values allowed."
  A series can hold up to 50 values. If more values declared, 
  this error message will appear.

- "too many series. no more than six series allowed."
  SmartChart currently supports up to six series. If more series
  declared, this error message will appear.


9. New Features since Version 3.1
----------------------------------
Version 3.2 provides a user selection mode, when the user can select
objects (such as titles, legends etc.) move and resize them.
This version also fixes few bugs from ver 3.0.

10. New Features since Version 3.2
-----------------------------------
Version 3.3 allows you to display up to 1000 values in a line
graph in one screen (without scrolling). In this version we've
also added tool-tip windows that pop up with the x-axis label
and its value when the cursor is positioned above the bars and
lines. Version 3.3 also fixes few bugs of previous versions.

11. Order Information
---------------------
SmartChart is licensed for a specified number of users.
A single registered copy of SmartChart may use several people
and may be copies to several computers, according to the number 
of licenses. When ordering SmartChart, you need to specify the
number of users. 
You may also order a license for unlimited number of users 
(restricted to the organization).
When payment is received, you will be sent a registered copy of
the latest version of SmartChart on a single diskette or by
e-mail, which you may copy according to the number of licenses
you ordered. SmartChart is shipped on 3.5 inch disks only.
See OrderForm.txt for pricing information.
Inorder to register SmartChart, fill up "OrderForm.txt" and 
send it to us by fax, mail or e-mail. 
If this file is missing, you can download it from our web site:

http://www.profilesoft.com

for additional order information, e-mail us at:

sales@profilesoft.com

for technical support, e-mail us at:

support@profilesoft.com
