//******************************************************************************
// PLC: DATA TYPES                              Copyright 1998 Adept Software **
//******************************************************************************

#ifndef PLC_DT_H
#define PLC_DT_H

#include "Adept.H"
#include "PLC_Main.H"

//******************************************************************************
//******************************************************************************
// INTERFACE

#define PLC_DT_DEFAULTRADIX	10
#define	PLC_DT_STRING_MAX	200

enum
{
	PLC_DT_INT=1,
	PLC_DT_FLOAT,
	PLC_DT_STRING,
};

//******************************************************************************
//******************************************************************************
// GLOBAL ROUTINES

bool	PLC_DT_GetBool		(PLC_DATATYPE *Value);
bool	PLC_DT_SetBool		(PLC_DATATYPE *Value,bool Data);
sdword	PLC_DT_GetInt		(PLC_DATATYPE *Value);
sdword	PLC_DT_SetInt		(PLC_DATATYPE *Value,sdword Data);
float	PLC_DT_GetFloat		(PLC_DATATYPE *Value);
float	PLC_DT_SetFloat		(PLC_DATATYPE *Value,float Data);
char	*PLC_DT_GetString	(PLC_DATATYPE *Value);
char	*PLC_DT_SetString	(PLC_DATATYPE *Value,char *Data);

//******************************************************************************
//******************************************************************************
#endif
