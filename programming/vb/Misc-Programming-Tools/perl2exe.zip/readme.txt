README.TXT for Perl2Exe

Please view the file pxman.htm for all documentation.

