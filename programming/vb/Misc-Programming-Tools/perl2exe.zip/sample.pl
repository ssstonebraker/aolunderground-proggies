#!/usr/bin/perl

print "This is the sample.pl script\n";
print "ARGV = ", join(" ", @ARGV), "\n";
print "Script = $0\n";
print "Env sourceExe = $ENV{'sourceExe'}\n";

print "foo = $foo\n";   # test -foo command line switch

for ($i = 0; $i < 2; $i++) {
 print "i = $i\n";
}

