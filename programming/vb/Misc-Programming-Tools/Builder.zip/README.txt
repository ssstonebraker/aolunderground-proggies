---------------------------------------------------------------------
                      LambdaMOO-Builder Standard   ( Beta 0.4 )
---------------------------------------------------------------------
                      Implementated by TimTaler (alias Rene Frerichs)
---------------------------------------------------------------------


Hi,

you have just downloaded the LambdaMOO Builder for Win95.



INTRODUCTION:

The LambdaMOO Builder is a GUI to develop textbased virtual realities with the 
LambdaMOO-Server 1.8.0p6. The current version (Beta 0.4) is based on the blank
LambdaCore-97 and was implementated with Delphi 3.0 Prof in the first half of
the year 1998. Many thanks to the people who programmed the WinMOO-0.1.0beta7.
Its a handsome alternative to the unix based LambdaMoo-Server and can be run
under Win95. I used it to develop locally the KuMOO and it seems to be as stable 
as the original. 

You can receive further information about the KuMOO under 
	
	http:\\www.geocities.com/CollegePark/Lab/1092/index.html

Please be aware, that this is a beta version of the LambdaMOO-Builder.
I like to continue to develop it, because it seems to be useful especially
while implementing verb-code or simply browsing through the system-code. 
I would be very happy, if you could send me some comments or suggestions about
bugs or further needed function. I know there are still many bugs, because its 
a tricky thing to extract the valueable informations out of a stream without
control bytes. If you have any better ideas or algorithms than mine, please 
tell it to me. I will try to integrate as many ideas and suggestions as I can.

!!! Please remember that you need wizard or at least programmer permission to use the 
!!! functionality of this tool.


The source-code is still undocumented, so you have to dig through it.



FIRST STEPS:

First you should connect to a MOO, by clicking on the top left button and type in the 
telnet-address and port. After that login to the MOO by typing "Connect ..." in the 
commandline. When you have regulary connected, you could use the functions of this tools.
Try pressing the "Browse Objects" Button in the Objectinspector and all objects owned 
by you will be displayed. You could now check the verb- or property-lists. Should you like
to edit a verb, simply doubleclick on it and the sourcecode will be loaded in the 
SourceCode-window. If you like to change the perms or parameters, you could could do it too.
If you are sure to change the verbcode permanently, click on the "Submit"-Button above the 
"Stop-Transmission" Button, which you could click, when the transmission doesn't terminate,
because the received data is corrupted. In addition there is a timeout of 60(!) seconds.
Do you like few objects,but don't own 'em?
Simply configure the toolbar and add the object to one of the tabsheets. Should you want
to create a child of them, click on the corresponding button and it will be created. 
I think this is useful, so that you don't need to notice them on a sheet of paper and 
store 'em for later sessions.
There are three 



Objectinspector:
When you have connected to a MOO, click in the Objectinspector the "Load Player"-
Button. All players of the MOO will be listed. 
Choose a player and the player informations will be displayed (Props, Owned Verbs, Inventory).
Now you can browse through the objects by clicking in the Audit- or Inventory-StringGrid. 
The Verbs and Props of the selected objects will be displayed below.

If you like to edit a verb, doubleclick on the verbname
and the verbcode will be loaded into the sourcecode-window. When you have finished
editing the code, click the yellow arrow and the sourcecode will be submitted.
The result (error or not) will be display in the compiler-result-window.

Toolbar:
In the Toolbar you can save objects you didn't own, but often like to create a child
from them. By the menuentry or the speedbutton, you can open the configuration-window.
Here you can add new TabSheets and Buttons. During implementation a double-click will 
then create a child object.

Helpbrowser:
The help browser enables you to browse throught the MOO-online help by simple double-
click on a word. If the word is in the help-index, the description will be displayed.


Further windows:
There are few information windows like the "who is connected" and the "browse all objects"
-window. 

!!! But beware, you should only use it, if you have your MOO locally running, or there
!!! is really less trafic in the MOO. It takes approximately 60(!) seconds per 200 objects.
!!! In later versions you will have the opportunity to browse through all objects by
!!! clicking in the TreeView.




TECHNICAL:

For a first overview of a conceptional view of the entire tool, please read the 
"technic.doc" file.




TO DO:

- further configuration options of the "browse objects" window
- grafical display of the room-arrangement (I think not earlier than Beta0.6)
- further information-windows:
        detailed player-status (builded objects, etc...)  
- improved extraction of the valueable code-pieces
- mailinglist support of the mailtool


If you have an questions, comments or suggestions email to


			timtalertim@hotmail.com

Many greetings    TimTaler