Hello, every body.

This is my win32program disassembler version 0.2.
This time I got rid of preccx dependencies. 
This means pure C code for decoding. 
And I totally redesigned program so,
speed is improved dramatically( at least as far ad i played with),
accuracy is improved, 
more information is displayed.
And, Oh yes, I added "hint" facility,
this means you can direct disassembler -- 
    some part of program is "code" 
    or "byte data" or "address" or
    "whatever it is significant"...	(actually only some part of
	                                 hint is implemented at this time}

in "hint file"-text file you may create.
you can specify information as follows:
    
	a,A: address
    b,B: byte data blocks
    c,C: code blocks	 - implemented
    d,D: dwords
    f,F: floats
    g,G: doubles
    q,Q: quad words
    t,T: 80 bit reals	 - implemented
    w,W: words
    n,N: null strings
    p,P: pascal strings
    x:   end of hind file

format is as follows:
column  1: you give conversion specifier,
           which is a,A,b,B,c,C,d,D,f,F,g,G,q,Q,t,T,w,W,n,N,p,P, and x
column  2:     you need to give   ":" colon
column  3-10:  you need to give   start address
column  11:    you need to give   "-" minus
column  12-19: you need to give   ending address

last line should be 
    x:

what is difference between lower case and upper case?

for lower case you don't need to give column 11-19.
this means there is no ending address, so only one
instance of start location is changed as directed.

for upper case the blocks between start_address and end_address
is changed as directed.
here, end_address is not included.
so in the following example,
the location from 0040512E(included) to 00405368(not included)
is converted to 80 bit reals.


<example for hint file> two lines between -------'s
-------------------------------------
T:0040512E-00405368
x:
-------------------------------------

The usage of hint file is as follows:

    dsassm02 "yourfile.exe" "hint.txt" > "yourfile.txt"

        if you have hint file or

    dsassm02 "yourfile.exe" > "yourfile.txt"

        as you did with disassem.


+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
You can contact me if you have any questions or problems.
e-mail: sangcho@alpha94.chongju.ac.kr
homepage for disassembler: www.geocities.com/SiliconValley/Foothills/4078/
phone:  +82-431-229-8491 (South Korea)
p.s. i like to receive nice postcards from you.
if there is anyone who wants to express his/her gratitute
he/she can send me a nice postcard.

my snail address:
Sang Cho
Department of Computer and Information Engineering
ChongJu University
ChongJu 360-764
South Korea