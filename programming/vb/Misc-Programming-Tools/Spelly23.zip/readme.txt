=======================================================================
= Spelly 2.3            (c) 1998 by Yonat Sharon            28-Oct-98 =
=======================================================================

Spelly is an add-in to Microsoft Developer Studio.
It adds the ability to spellcheck source code and comments, including
identifiers with under_scores and MixedCase. It can check HTML text 
while ignoring the tags.

Please send bug reports and suggestions to <yonat@usa.net>.
Latest version available at http://www.kinetica.com/home/yon/4dev/ .

Disclaimer:
This software is provided as-is. Don't blame me if it trashes your
source files, your system, or your life.

============
Installation
============

0. If you are using Windows NT, make sure that you have administrator's
   privileges.

1. Copy all Spelly.* files to the add-ins folder of Developer Studio:
   C:\Program Files\DevStudio\SharedIDE\AddIns

2. In Developer Studio, go to the "Tools" menu and select
   "Customize...".

3. Go to the "Add-ins and Macro Files" tab (the last one). Mark the
   checkbox next to "Spelly" as checked, and click "Close".

4. Developer Studio adds a new toolbar with the Spelly button.
   You can move this button to another toolbar by pressing the Alt key
   while dragging the button.

To deactivate Spelly, perform steps 2-3, but uncheck the checkbox next
to Spelly.

To completely uninstall Spelly:
1. Exit Developer Studio.
2. Delete all Spelly.* files from your Developer Studio add-ins folder.


=====
Usage
=====

Click the "Spelly" button to spellcheck the active document. Click on 
the "Spelly (no code)" button to spellcheck only comments and strings 
(In HTML documents, checks both text and comment tags).

To check only a portion of the document, select it and then click the
Spelly button.


================
Acknowledgements
================

Mark Bartosik <mark@rcp.co.uk> helped me solve a nasty COM reference 
leak. Thanks Mark!

I used the CLabel class by Norm Almond <nalmond@hotmail.com> from 
http://www.codeguru.com .
