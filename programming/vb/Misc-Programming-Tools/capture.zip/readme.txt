Capture DLL Version 1.0 [Shareware version]

What's new:
-----------
Version 1.0 :
First release version.

Zip Content:
------------
In this Zip file, it contains Capture DLL (Win32 version).

--- Capture.h
 |- Capture.lib
 |- Capture.dll
 |- Capture.hlp

Note: Capture.lib is a Visual c++ library file, for other compilers user, please use other program (for BCB user, you can use implib.exe) to make a suitable library file.

Sample:
-------
Only BCB3 sample yet.

For any questions, suggestions or bug reports, please send an email to me.

My email address : sega1@hkstar.com AND
My web page 	 : http://home.hkstar.com/~sega1/

IMPORTANT: Please fill my survey about this producton in my web site! Thanks.
My survey URL 	: http://home.hkstar.com/~sega1/capture_survey.html

Regards,
H.Y. Kwok
1st, August, 1998

