The Beginners Basic Helpfile v3.0 (Professional Edition)
--------------------------------------------------------

This version of "The Beginners Basic Helpfile" is shareware.  
This means that you will need to pay a small fee for you to receive
the extra 12 tutorials and the extra number of supplement articles.

Also included within the registration fee is a complete QBasic 
support pack which features loads of different programs for you to 
load into QBasic and try out.  You will be sent an Email newsletter 
which will include various tips and tricks for QBasic programmers.

The registration fee is a minor contribution to myself for spending 
so much time writing this helpfile.  Here is a brief run down of the 
different cost's involved.


   United Kingdom            -  �8.30 Total

   United States             - $14.50 Total

   Anywhere else             - $14.50 Total


If you live in the United Kingdom I would gladly except a Cheque,
Postal Order or Cash.  If you live outside the United Kingdom, I 
would gladly except a Postal Order but not Cheques.  All 
Postal Orders should be made out to be UK Pounds Sterling.  If this 
is a problem, I can except Postal Orders in U.S Dollars currency.

When you send me your registration, please try and include your full 
details.  For example your mailing address and email are very 
important.  For your help, I have included a file called order.txt.
This is an order form for you to fill in and use.

My address is as follows:

	Steven Salmon - Registration
	22 Repton Gardens, Grange Park
	Hedge End, SOUTHAMTON
	Hants, England
        SO40 2AE.

	Telephone Enquires: +44 7775 664613

	Email address: helpfile@basic.globalnet.co.uk

As soon as I receive your order, I will dispatch and send immediately. 
Please make sure that you state if you prefer to receive the Helpfile 
across the Internet or by post.  If you forget to tell me, I will 
email you directly and ask.
