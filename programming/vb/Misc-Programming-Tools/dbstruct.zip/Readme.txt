DB Structurer utility ver. 1.2
=======================================

Overview
--------
DBStructurer utility is intended for the developers working in Delphi 2.0 or higher. 
It allows to keep the information of database structure together with the description of tables, fields and indexes and quickly prepare the reports in a kind, convenient for the user. 
You can print report, save it to file or transfer to Word document.
For more information see html-file in \Doc subdirectory.


Installation
------------
You need BDE 3.0 or higher be installed on your computer. To install program just unpack zip archive in any directory on your hard disk.
For example: pkunzip -d Dbstruct.zip C:\DbStruct
During the first start DBStruturer create BDE-alias STRUCTS_DB and subdirectory \DB where the descriptions of structures of databases will be stored. If you want to move them on other place (for example on a network drive) you have to move all files in \DB subdirectory and change the PATH parameter of STRUCTS_DB alias in BDE Configuration.


Conditions of distribution
--------------------------
The program is distributed as shareware. Registration costs 20$. Read file register.txt for additional information about registration.
The demo-version is free and has restriction: 
The structure of 2 first tables in report will be printed only.

The registered users can also receive full source code of program. Contact author to get it.


Copyright Notes
---------------
DBStructurer (c) Copyright by Korzh Sergey, 1998
e-mail:korzh@ukrpack.net
http://korzh.hypermart.net
On this page you can find information about new versions of this tools
and other our products 