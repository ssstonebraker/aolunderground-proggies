Overview of the Add-In:  Latest version V2.0a 
=============================================

The feature to set bookmarks (using Ctrl-F2) in a text file available in the Dev Studio editor is very useful when going through a HUGE source file. The drawback is that, once the text file is closed you lose all the bookmarks set in that particular file and it's a pain to set them all again. 

So, anyway I guess you know what this add-in does by now. It, remembers the bookmarks set in a file and re-sets them back if the file is opened later in Dev Studio.

Personal Note:
--------------
Thank you to everyone who is using this add-in and for the time taken to e-mail me with useful comments and suggestions. (26th January 1999)


Installation:
=============

Copy the bookmark.dll file (after downloading it ofcourse) where-ever you want (I put them in 
Devstudio\sharedide\AddIns). In, Dev Studio, go to the Tools menu and select 
Customize... 

Go to the last tab (Add-Ins and macro Files). You should be able to see the Book Mark add-in 
in the list box (if you saved it in the path above. If you've saved it in a different path, 
you'll have to browse for it yourself). Once, you checked the bookmark add-in, click close 
and the add-in is now ready. 

Un-Installing:
==============
Un-check the bookmark addin (in the tools customize page). Delete, the bookmark.dll and also, a file called bookmark.dat (which is automatically created by the add-in) and is stored in the directory you specified.


Usage:
======
The add-in runs without user interaction.

You do have a choice to set the options. You can enable or disable the bookmark add-in on the fly by clicking on the bookmark command button.


Options:
========
Disabling the bookmark add-in will now restore your bookmarks the next time you open the file.

The user also has the option of saving the bookmark locations

1)	When user closes a document OR

2)	When user saves a document (for the paranoid, like myself who thinks that Dev Studio will crash anytime for 	any reason)

The delete file button simply purges any bookmark locations that you might have accumulated during your long hours of coding

Advanced Page:
==============
This is a new addition to the add-in. It's called advanced for lack of a better name.

The first version of the add-in was quite inflexible in the manner that the user couldn't selectively remove bookmark locations stored in the file. Well, now the user can selectively remove a line or the whole file. I'll let you play around with the add-in.

Update: (4th September 1998)
===================================
Now the users can remove files or lines in the advanced page with the use of the keyboard. Just press the delete key. The user can also open any file by using the F3 key. Double clicking on the line number will open the file and scroll to the line number and highlight the line to give you an indication as to where the bookmark is set. F3 works with both Files and Line numbers.

Update: (2nd December 1998)
===========================
DevStudio process did not seem to terminate itself properly when users would open a file from the dialog box (using the F3 key or choosing the menu option available). I don't know why this seems to happen, so to prevent from DevStudio's process not terminating properly, I have removed the functionality whereby the user can open a file until I find out exactly why this happens.

Update: (26th January 1999)
===========================
Bug fixes:
----------
Could not delete files from the list (in the advanced page) which did not exist on the drive. (Thanks to Matthew Ellis for finding the bug) This is now fixed.

Additions:
----------
When navigating code using the browse facility, the add-in would remove the highlighted piece of code, regardless of whether there was a bookmark set for that file or not. (Thanks to Matthew Ellis for the suggestion)

Functionality of opening a file from the advanced page has been re-introduced once again. I did not seem to find anything wrong after endless hours of painful debugging. F3 key should now work again.


Known Issues:
=============
There is one problem (actually it's a minor annoyance). Everytime, the user hits save, the editor will scroll. The cursor will remain at the same place but the text scrolls (which can sometimes dis-orients' users). There doesn't seem to be any good way of achieving this. :-(

Important:
==========
This add-in has been tested under Windows 95/NT and works for VC5. It has also been tested under Windows 95/NT running VC6 and it seems to be running. If however you have a problem please let me know.

Thanks,

Jignesh Patel
jigneshpatel@hotmail.com
http://www.geocities.com/SiliconValley/Lakes/4411/


