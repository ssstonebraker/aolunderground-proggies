Highlighter v1.1 for Windows
----------------------------

This information is duplicated in ReadMe.html which you can read in
your browser.  It also contains direct links to the Solent Software
website and for email feedback.

About Highlighter
-----------------

Highlighter is a syntax highligted source code printer for all
common languages. Print files based on name, location and
date or print direct from explorer or by drag and drop. Add 
headers, footers and margins and save different options for
separate projects. Languages supplied: assembler, C++, basic,
delphi, pascal, java and HTML.

Installation
------------

Run the program SETUP.EXE.  You will be prompted for a directory
in which to install Highlighter.  The necessary files will be copied
and appropriate registry entries and start menu shortcuts created.

Uninstallation
--------------

Open Control Panel|Add/Remove Programs and select Highlighter or
select Uninstall Highlighter from Start Menu|Programs|Highlighter.

Year 2000
---------

Highlighter is fully year 2000 compliant.  All dates are calculated
within a 50 year window so for example if you are in the year 2000 and
enter the year as 99 Highlighter will know you mean 1999 and vica versa
when the date is 1999 and you enter 00.

Virus checking
--------------

Highlighter has been virus checked with the latest version of 'Dr 
Solomon's Anti-Virus Toolkit', one of the best anti-virus products
available.

Trialware
---------
Highlighter is trialware. You are permitted to use the trial version
for up to 30 uses.  If you want to keep using Highlighter after this
period you must buy the full version. Highlighter costs �15 (Pounds
sterling) - approximately $25.  You can order online using a secure
server or order by mail, phone or fax.  For full information visit
http://www.solent.force9.co.uk/highlighter/register.html.  For more 
information open the file HIGHLIGHT.HLP and see the topic 'Buying 
Highlighter'. For licence information please read the file LICENCE.TXT.

You may freely redistibute the trial version of highlighter but
please pass on the original HLTxxx.ZIP file.

Contacting the Author
---------------------

Highlighter was written by Solent Software.

email: mike@solent.force9.co.uk

Website: http://www.solent.force9.co.uk

Online registration: http:/www.solent.force9.co.uk/highlighter/register.html

Mail:
Solent Software,
Daisy Villa, Brook Avenue,
Warsash,
Southampton,
Hampshire.
SO31 9HP
England.


