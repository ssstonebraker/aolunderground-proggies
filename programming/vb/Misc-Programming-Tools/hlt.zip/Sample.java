// Java language test file
public class Sample {
	char c;
	string s;
	int i;
	public void init(){
		s = "This is a test";
		c = 'c';
		i = 12;
	}
}


