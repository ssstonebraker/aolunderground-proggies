void main () {
asm {	// This is inline assembler 
	mov ax,cx;
	add ax,0eh shr 2;
	cmp bx,'a';
	mov al,byte ptr[bp+6];
	rep movsb;
} }

