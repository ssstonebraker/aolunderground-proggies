// C language test file

#include "stdio.h"

void main() {
	printf("This is a test");
	printf("%c%i",'$',32);
}


