RegionBuild is part of GameSetup Developer Kit (GSDK)

I wrote this tool due the heavily request on several newsgroups for 
programming "non-rectangular" windows. 
The main code is grabbed from GameSetup.

Please note: Currently are only 256 color uncompressed bitmaps surpported.


To create a region from a bitmap load it by selecting it in the filelistbox. 
Click inside the image to set the transparent color for it. 
Now you can save or test your region by pressing "Create region" or "Test". 
The calculation of a region can be time expensive sometimes so please be patient. 
A progressbar in the statusline will show you the progress.
Thats it!

How you can use the regions in your program
===========================================
Take a look at the sample program I've put into the archive. 
It's really simple!

Note: 
The sample program will look in the resource type "RGN" for the region you request.

btw: You can use Regions for all your controls of course!


So long,
Philipp Kursawe
philipp@east-development.com
10/19/98
