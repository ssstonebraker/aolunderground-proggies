SDA - Shareware Developer Assistant v2.01
Copyright � 1996-1998 Doesn't Byte Software
All rights reserved.
____________________________________

Installation: 

Run Setup.exe and follow all prompts.
____________________________________

Distribution:

The shareware version is freely distributable.  
____________________________________

Contact:

Doesn't Byte Software
1311 Boston St #2
Anchorage, AK  99504

E-Mail: support@dbytes.com
   WWW: http://www.dbytes.com/