-Autorun Maker, By [The Real] Swift (A.K.A. James DeMattos)

-Mail:
- +
-XxNuclearxX@aol.com
-SwiftGeneration@aol.com
- +

-About:
- +
-Made in VB6
-DOS-like look intentional
- +

-Other:
- +
-(C) Swift Productions
- +

                 Enjoy.