yo people
this is nyte...
these are all the sources i could find on my hard drive..gently coms, thats almost the full one, the Mchat belongs to gently..theres like one form missing to that, but its nothing it maybe has 10 lines of coding, its not very good, so anyways..ill be passing out visual basic projects too..like gently..my tanks...that kinda stuff..so theyll be at either:
www.lenshell.com/vb2.htm [beav] 
or..
www.mr-koww.com [koww]

i would like to thank chrono, hadez, alpha
for giving me source to read over..
i'd like to thank beav.. and koww..for reproducing these sources..
i would also like to thank beav for everytime he put my lame ass progs up on lenshell -=X
but i've gotten older now, and i know what i am doing, i know what looks good, so..i no longer have lame ass progs..now, these are a few of MANY sources that i have..and...if you know me then you definattly know that i have done alooooooooot more programming than that..last time i checked last night all these sources came to about 175 pages..but...that was not even half of gently included..and not even half these sources included, so its a good 600, 700 pages now..and that is just skimming the surface of what i have programmed over the last 3 years..heh 
sooooooo anyways......
aolers, have a good life looking at people scroll..
have fun getting gagged by bitches that dont know how to use a host..

this is nyte..
signing out..
-=[
later

-nyte.3k