Idler by Gnome

This program is perfect for the chatroom owner.  Ever have the fear of a bot attack and that you will be lagged out eventually?  Well, this simple program will let you idle in chatrooms without having another AIM Client running or cloning AIM!

Things to be expected:
Working about/help form,
A hide feature that will enable you to hide the Idler window.

AIM- Cousin Gnome
YIM - cousingnome
Email - cousingnome@yahoo.com
Please specify when you message me.

www.cousingnome.tk

Note:  If this program was downloaded from somewhere other than www.cousingnome.tk, please be kind and let me know.