Color Rocker made by aLex
contact: aim(thugginaLex)
email(ioseralex@aol.com)
if you need help, email me
if you dont know what the
buttons do then just wait for
the tool tip to pop up with 
instructions :P, enjoi! 100%
made by aLex, idea from 
darren, help from myke
and nitroid, also sinac


Update( This is alex. DigiEnt has been closed down and renamed to Veniversum Studios. Also that aim does not work. If you need
to contact me, email me at menaces@gmail.com, or visit veniversum.net. Thank you.)



TO USE THIS PROGRAM, USE WINZIP AND EXTRACT THE FILES
DOUBLE CLICK ON THE BANNER TO ENTER THE PROGRAM!!!!!
NOTE: THIS PROGRAM ONLY WORKS ON WINDOWS XP!!!!!!!!!!!!!!!!!!!!!!!!!