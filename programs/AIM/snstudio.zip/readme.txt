Name: Screen Name Studio
Author: Ninja
E-Mail: i_am_ninja@yahoo.com


Notes: This program uses proxies to make AIM names. The reason for
using proxies is because after making so many names from one ip, AOL
will rate your ip for 24 hours. By using proxies you can make as many
names as you want, and not have to worry about the rate limits. You
must use HTTP proxys. SOCKS proxys WILL NOT work.