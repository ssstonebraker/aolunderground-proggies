Thank you for downloading FaderColorz 1.0 Beta!

This version isn't really BETA, I just put it up for download to see what people think.
If I get enough positive feedback, I will definatly exapnd my color code list.  ALOT!

So if you like this software, TELL ME!  E-Mail Sweedishboym@yahoo.com or AIM DJBurns66.

* * * USAGE INSTRUCTIONS * * * 

1) Make sure AIM Fader Suite is NOT OPEN
2) Highlight the color code you would like to use (JUST the numbers!  NOT the text!)
3) Paste the codes into the Colors.txt file making sure there are NO spaces on top and that there
is NO text.
4) Save Colors.txt and close it.
5) Open up AIM Fader Suite and VOILA!  

I am going to try and contact the creator of this software and see if he can build in the preset
colors.  But for now, enjoy!  And if you like what you see, make sure you tell me so you can see
more!