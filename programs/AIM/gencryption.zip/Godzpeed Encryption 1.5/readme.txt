\\\\\G0DZP33D ENCRYPTION///// vers. 1.5 build 3
BY Jake Godspeed

Install Notes....

Bring up your buddy list, Select "My AIM" and scroll down to "Edit Options" and select. Or a quick way to do is push F3 when u have ur buddy list up. 
Once your in preferences, scroll down to Security on the list on your right and click it. Now click advanced at the very bottom. Once that window appears..choose import at the very top and browse to your AIM directory which is usually "C:\WINDOWS\PROGRAM FILES\AIM" and click on the folder titled "Godzpeed Encryption 1.5" and select the file named "godzpeed_encrypt" and click ok/open. Just type the password and itz tht easy.

Password: 4181603690056



Enjoy!
Greetz: Cerjam0, dannymix, mardog53,trupro

Send commentz and hate mail to godzpeed@patmedia.net




