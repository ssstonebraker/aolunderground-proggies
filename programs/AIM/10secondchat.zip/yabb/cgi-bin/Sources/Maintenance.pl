###############################################################################
# Maintenance.pl                                                              #
###############################################################################
# Yet another Bulletin Board (http://www.yabb.com.ru)                         #
# Open Source project started by Zef Hemel (zef@zefnet.com)                   #
# =========================================================================== #
# Copyright (c) The YaBB Programming team                                     #
# =========================================================================== #
# This file has been written by: Christian Land                               #
###############################################################################

sub InMaintenance 
{
    $title = "$txt{'155'}";
    &header;
    print <<"EOT";

<table border=0 width=100% cellspacing=1 bgcolor="#000000">
 <tr>
  <td bgcolor="$color{'titlebg'}">
   <font size=2 color="$color{'titletext'}"><b>$txt{'156'}</b></font>
  </td>
 </tr>
 <tr>
  <td bgcolor="$color{'windowbg'}">
   <font size=2>
    <br>
    $txt{'157'}
    <br>&nbsp;
   </font>
  </td>
 </tr>
</table>
EOT

    &footer;
    exit;
}

1;