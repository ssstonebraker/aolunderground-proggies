Buddy Tell v1

OK this was mainly made to tell your friends if u changed your screen name orwhatever
with ease, .... i know its kinda a pain in the ass to do that so just leave this thing runnin
for like a couple days and boom, everyone will know. Everything works as it should
i think so if u find a bug then let me know, jimb0@mac.com < at that screen name.

if u didnt get this at aimthings.com then go there now!

-Jimbo