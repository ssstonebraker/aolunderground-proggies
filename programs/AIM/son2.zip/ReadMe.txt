Suspended Or Not v2
-----------------------------
By Splisks
http://www.aimforums.net
http://www.splisks.org
-----------------------------

Help With Errors:

Any errors You get on startup, involing system errors or .ocx/.dll errors,
Refer to the Registering Folder included in the zip.




Programs:

Version One:
-----------------
I included version one in the program to check one AIM screen name at a time.

Version Two:
-----------------
This is basically a multi name checker to check list files you got to manage your own
or other AIM names you want to check if they are active or suspended.

Believe it or not this comes in handy, it's easier then adding a name to your
regular AIM startup list, checking, then deleting. With this you can check 
many names in minutes.




About:
-----------------
I oringnally created this program for myself to help check a lot of names I have.
Then I told people about it, they were interested in it and wanted it too.
Some now here is version two of the popular version one.

Version One was oringnally made in back in around March 2003. You can download version
one also on Lenshell.com




Final Notes:
------------------
Hope this helps manage your screen names with ease.

Post any errors at http://www.aimforums.net

Thank you.



-Splisks