Away Message Server 3.0
-----------------------
run awaymessage server set the port and password if you want that on
then you can access the webpage by going to http://yourip:port
if you are behind a router you have to set up port forwarding and 
if you have a firewall open the port you set