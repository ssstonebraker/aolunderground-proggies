*NOTE* If the cloner is not working because the bots are not signing in, then dont use spaces then u`ll be a fucking genius ;X

Email me if any questions, comments, or Ideas

Peeininthesno@hotmaill.com
or IM at PEEIN IN THE SNO

or contact CerJam at cerjamz@gmail.com or IM at XZU

~PEEIN IN THE SNO~
~CerJam~