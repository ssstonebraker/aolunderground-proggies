======================
DeadAIM - Version 1.02
======================

Welcome to the DeadAIM 1.02 readme!

DeadAIM has been designed and written to remove those annoying
adverts from AOL's Instant Messenger. It couldn't be easier to
use either.

Steps for use:

1:	UnZip the DeadAIM.exe and DeadAIM.dll files into your 
        AIM directory (Normally "c:\program files\AIM95").

2:	Change your Start Menu AIM shortcuts to point to the
	DeadAIM.exe instead of aim.exe
	
Thats it!

DeadAIM with automatically deal with the registry entry that
is set to start AIM when Windows starts the first time DeadAIM.exe
is run.

Updates
=======

Version 1.02 has a fix to deal with quick resizes and when only
the outline of the window is shown when resizing. The tree view
and buttons were not being sized/placed correctly.

Version 1.01 includes a minor change to help solve a problem on
some machines when AIM is taking longer than normal to load due to
other tasks running at the same time.

--
Enjoy :)

JDennis

JD@JDennis.net
http://www.JDennis.net/