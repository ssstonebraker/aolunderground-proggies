XRegister 1.1 Readme
By Brandon Scott
SynVB Team

1) To use XRegister, you can register one name at a time and enter your username, password, and email, you can also generate a fake email allowing you to register almost unlimited names.

2) To register a list of screen names make a TXT file and have the follow format.

screenname:password
screenname:password
screenname:password
screenname:password
screenname:password

;you can also have comments in your list, just use the ; char at the beginging

3) Any errors and or bug reports report to stonecoldrules13@yahoo.com