if you get an error saying the installer is unregistered and expired...  it will work if you change 
your system clock back a few years, install it, and change it back to the 
correct time.