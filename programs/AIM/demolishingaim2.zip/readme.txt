---------------------
File: Demolishing AIM 2.0
By:   Tacoboy
For:  AIM 4.0
Opts: Over 150

This is the best AIM Prog (I think, and the 1st best is 187 Final, 
but that doesn't work for AIM 3.5 or higher). Its got more options,
more organized,smaller iface,cool sounds than Demolishing AIM 1.0.
Enjoy. I wanna say sup to jessica (dragonstar).

---------------------