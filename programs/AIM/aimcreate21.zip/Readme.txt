Aim Create 2.1 by Dizix    3/26/02
-----------------------------------------

Well I didn't plan to release anymore versions of Aim Create simply because there are so many other aim creation programs out there but some people on the aol-files forums wanted a random email function so I added it.

New to this version:
- Random email function 



- Dizix
Diz@em-c.org