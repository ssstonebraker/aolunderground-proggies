       title:vizuaCollect2.o 
       coded by steve 
       http://chaotic-code.com
	
 ================================================

the only code i borrowed was the remove duplicate sub, thank you
PatorJK. As for the controls (ActiveX), tocSock(tocSock.ocx) and the 
common dialog control (mscomdlg32.ocx). This collect's screennames, and 
DOES NOT I REPEAT DOES NOT SPAM. Well actually, if you type in '!spam' in the
chatroom in joins then it will reply with 'chaotic-code software'. This is the 
first public release so it only joins 3 chatrooms (one for each collector). The chatrooms
are 'sex and the city';'celebrity gossip'; and ;'the osbournes'. Thats exchange 5 by the
way ;). the next version will have more options. for more programs like this visit my 
site http://chaotic-code.com if you are into delphi or vb then you will love 
my site :)
	
			-age

irc: irc.fuckin-elite.org - #main 

peace