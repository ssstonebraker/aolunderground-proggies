Whats up people? If your looking here, you are totally fucking 
lost! First, off make SURE you have AIM 5.2! http://aim.com. Next, open the zip file and extract all the files (if your 
reading this, it was already done!).. next open up AIM! Go to
My AIM then, Edit Options, then Edit Prefrences. Then go down to Security
and click Advanced! Click import and then on the dropdown menu where it says
".p12".. make it say ".pfx", find the folder and click the file "aimjunkycert". Then you have to click open.
 It will ask you for you to make a pass (you can make this whatever you want, 
BUT you need this to login! Then it will ask for the certificate pass. 
This is "aimjunkyownzyou"! After that.. YOUR DONE! PEACE OUT!

i/m me on aim at: Y x GQ!!! PEACE!