First Time use:
1) Exit AIM then Run the installer.
2) then Run profileamp and aim
3)  goto Preferences>Sign On/Off, click Connection
	click Connect using proxy
	enter these into the proxy server box also make sure the protocal is socks4
	Host = 127.0.0.1 or localhost
	port = default is 8080
   Select Ok
-----------
problems?
if you get a error saying connection refused make sure profileamp is running and under 
options says stop, if it still doesnt work try and use a different port such as 1080,etc..

If you use windows 95 or 98 you must goto
http://www.microsoft.com/downloads/details.aspx?FamilyId=98A4C5BA-337B-4E92-8C18-A63847760EA5&displaylang=en
and download that file for profileamp to work.
