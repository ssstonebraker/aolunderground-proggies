sonicnoodles 10 bot booter
Updated
'// added ini file and organised log on process better

make 6 to 10 names up , (the more the better), and log into Oscar (quick buddy) 
Deploy your new task force to destroy enemys with a hail fire of
connect to talk errors,
im floods and errors, 
buddy list send errors, 
chat invite errors,
file send errors

boots most peoples versions of aim as of 30/01/03
upto aim5.2

