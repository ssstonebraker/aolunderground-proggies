This AIM prog is the first prog to have a working IM
punter (go to ims/punters/already have an open im), 
IM background fader, hidden message sender(F2), 
timestamp manipulator, new chat lags, and over 50 bots.  Note:  
The only SN's we will go on are SpookyX187 and 
UPSETx187.  Any questions, comments, bugs email us at 
darkclown__upset@hotmail.com.