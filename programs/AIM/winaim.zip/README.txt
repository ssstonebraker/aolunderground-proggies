this _ONLY_ works with winamp Winamp 2.79 or earlier

winamp3 is gay cause it eats up resources like a bitch

i dont use it and any other smart person whouldnt either

[S/N](Duke7037)