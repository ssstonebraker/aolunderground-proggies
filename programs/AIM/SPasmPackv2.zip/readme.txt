SPasm v2.0
By: Jordanz

// Information about SPasm:
- SPasm stands for SP Another Screenname Maker.
- SPasm is used for making AIM screennames at a faster rate.

// How to use:
1. Add/load/generate your list of screennames to add to the screennames box.
2. Type in which password you want for those screennames/bots in the password textbox.
3. Load/add your list of proxies to the proxies box.
4. Begin spasm!

// Technical Information
- This runs with 5 winsocks, so it should be pretty fast (with a good proxy list).
- It will only switch from registering a screenname if the screenname is taken or invalid (bad amount of characters, etc.)
- All proxies need to be in server:port format, otherwise SPasm will automatically remove it from the proxy list.
- It will only switch from a proxy if the proxy gets a "rated" error, is a bad proxy, times out, 
  or if SPasm determines it to be a junk proxy. A junk proxy is a proxy that can recieve data but
  doesn't send the right amount of data back (thus, making it so the registration cannot be completed)
- It shouldn't take a whole lot of processing speed/memory (or hardly any at all), hence why it only uses 5 winsocks.

Please post any bugs you find on Sevenz forum in the SPasm thread.
Have fun making your screennames!