Chatage V1.1 By Stephen

=================================
Chat spammer i made...like it or not.
works with the latest AIM5.0 ..check it out. :]


Info

url http://chaotic-code.com 
    http://smprod.owns.it

aim: iamst3ve, bitch ass steve

email: root@chaotic-code.com

