AIM CLONE FOR AIM 4.3
by www.aimicons.net
-----------------------

Make sure you use AIM 4.3

Run 'CloneAIM' and just wait a couple seconds

a new instance of AIM should open on your screen.

Enjoy!