:: Ghost Update 1.0 
:: Coded By Moo2 
--------------------------->

You must be signed on AIM with the email you want to anonymously update the email to.
The email you are updating to must be an @aol.com account, otherwise this will not work.
This has only been tested on 5.2.3277 and 5.2.3292, it may or may not work on earlier or later
versions of AIM. It does not work on 5.5 at all.

===============================================

The purpose of this program, is to update an AIM accounts email address, without the original email knowing about it.


Example  :: You crack a screename. You sign on the screename. Open this prog. Put in your @aol.com email, update it with the prog. The original account holder cannot cancel the email change because they will not know that it occured.

***   I, Moo2, do not condone cracking ;-)



http://korey.knows.it