This is the first alpha release of Lighthouse 2.0

You have been chosen as a private tester. You can reverse engineer this and play with it all you want, but you may NOT release any information
you obtain by doing so. You may not distribute any of the contents of this file. You may not allow anyone but yourself to use, access, or copy
the contents of this file.

A few things to keep in mind:
-Settings don't get saved yet.
-There is no autoban, this will be in a plugin later.
-This is not fully tested. DON'T USE IT FOR ANYTHING IMPORTANT.

Microsoft .NET Framework 2.0 is required to run this. If you get weird error messages about missing files or invalid EXE kind of stuff,
this is probably why.

There are two EXE files. Lighthouse.exe and LighthouseLauncher.exe. The Launcher allows you to pick a profile, and also provides the ability
to restart lighthouse in the event of a crash. If you want to run Lighthouse.exe directly, you will have to provide it a single commandline 
argument containing the path to the profile you want to use.

If you choose to design a plugin based on the interfaces provided in LighthouseShared.dll, keep in mind a lot of things will probably be changed
before the next release. If you have to recode your whole plugin, don't complain to me!

Anyways, enjoy.

-turbzy