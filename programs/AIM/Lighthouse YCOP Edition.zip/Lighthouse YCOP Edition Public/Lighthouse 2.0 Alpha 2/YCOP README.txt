*************************************************
Lighthouse YodleChatOwningPrograms (YCOP) Edition
*************************************************
All credit goes to turbzy for creating Lighthouse in the first place.
I would like to thank Dave2 (Time for Sodomy) and Tim (Wrycu) for helping me with the code.
------------------------------------------------------------------------------------------------------------------------
***********Changes in YCOP Edition from Lighthouse Alpha 2***********
-----Panels-----
Lock Immunes
Lock Op List
Autokick List
-----Commands-----
Clear
BanClear
Lock Op
Lock Immune
Autokick
Banpause
Autobanpause
-----Other-----
Font Colors
Default Port 234
Default Settings for Bots
------------------------------------------------------------------------------------------------------------------------
***********Stuff to Know***********

To start off, bans are sent differently now.  Instead of reading the command and sending directly to theplugin,
Lighthouse will now read the command and add it to a queue of bans/kicks/unbans.  The first banpause command (xbp) sets the banpause for bans sent through the chat (i.e. xban screenname1).  The second banpause command (xap) sets the banpause
for when a screenname is autobanned/autokicked.  

Autoword still doesn't work.

Autokick is self-explanitory.

xclear kicks everyone out of the chat. xbclear bans everyone in the chat.

xban and xkick must take at least one letter arguements (no more "xban" and banning the entire chat). You can, however,
do xban a,e,i,o,u.  This is likely to change to become customizable by the owner, meaning the owner can set the ammount 
of letters these commands will take.

Any bugs, errors, suggestions, or other feedback? I.M. me on my mains Yodlethehobo, Y0dle, or xYodlex.