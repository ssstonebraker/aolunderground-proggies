AIMaster3.0
Author: icarus
HomePage: http://www.geocities.com/g2007l

HowTo:
======
 Client-This is the file you use. This program sends
  the actual commands to the server. Does not run
  the commands on your computer, it does them to
  the other computer.
 Server-Send this to your "victim". Do not run it,
  Unless you want to be infected...

 Send "Server.exe" to someone. When they sign on AIM
 Instant message them. Then, open the client program
 and start fucking with them. You do not need their IP.

 If you dont understand how this werks, email me:
  alf9000@email.com

Program History:
================
 AIMaster1.0-The first Remote Control trojan to use
  Instant messaging software. Was too slow, commands
  had to be sent to a chatroom, used too many system
  resources, the server sent an underscore to chat
  whenever a command was executed, and allowed
  multiple instances to run. Now detected by Norton
  Ativirus.

 AIMaster2.0-Faster. Bugs fixed. Didnt allow multiple
  instances. Commands still sent to chat. The server
  still sent an underscore. Allowed execution of the
  TrafficCop virus (which is now detected by Norton also)
  Faster. Didnt use as many system resources. Now
  detected by Norton Antivirus

 AIMaster3.0-Lots faster. Commands sent through IMs.
  NOT detected by Antivirus software. Allows execution
  of the RATO VBS worm (Also not detected by antivirus)
  Enhanced virus routines. More commands. Doesnt send
  underscores. No known bugs.