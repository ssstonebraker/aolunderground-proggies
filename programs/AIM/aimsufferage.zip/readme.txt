Welcome to AIM Sufferage v1 by Splisks
--------------------------------------------------�

News And Updates:
--------------------------�

Feb. 02 - Add minor fixes for NO errors, and secret area. (it has mega killer)
Feb. 01 - Program made using oscsock.ocx.


About Program and creator:
-----------------------------------�
Program was based on an idea I had using Xeon's ghost toolz. 
so i decided to make my own version the way i wanted it.
you can download this at www.splisks.com
you can go there to see my other programs too.
happy havoc! ;x


Tip: there IS a secret area with a couple of extra GOOD options :D