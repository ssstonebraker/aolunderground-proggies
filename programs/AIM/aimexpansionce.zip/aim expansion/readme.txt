Setup
=====

This works differently then normal AIM filter like applications

1. Signoff
2. On signon screen click "Setup" button
3. In AIM Preferences window click "Sign On/Off" on the list (look left)
4. Click "Connection" Button
5. Check box that says "Connect using proxy"
6. Select Socks4 Proxy
7. Proxy server should be "127.0.0.1" and proxy port should be "1080"
8. Hit OK, then close out of the Preferences.
9. Hit "Start Proxy" on AIM Expansion
10. signon!


Profile Server
==============
Its like subprofile, only its your own webserver, just put files in the web
directory and it works like a web server would.

Put a link like this in your profile to have subprofile stuff
<a href="http://[IP address]:[port]/" target="_self">Click to view subprofile!</a>

Also on HTML and txt files, the profile variables are replaced
with the actual values!


CHANGELOG
=========
Version 2.1.123
* New Compact Edition, no more bulky interface.
* Got rid of some un-needed crap that actually slowed
  down performance
* Hopefully got webserver fixed!

Version 2.1.105
* Made installer
* Fixed Webserver Bugs, there was some problems
  with file sizes.
* Got the IM Forwarding Feature working correctly.
* This is the FINAL build of 2.x series.

Version 2.1.100
* New Icon and redesigned some interfaces.
* Designed cool new top log for the top
  of the program.
* Fixed alot of bugs related with instant
  messages and logging.
* Added new smiley set feature! Allows you
  to use custom smiley sets for AIM.
* Created new scripting engine, not really
  functional at the moment but it will get
  there eventually.
* I made the packet parsing much faster, and
  got rid of all the Variant data types.
* Fixed some bugs in the logging module, and
  added support for logging away messages.
* Added new connection information, for linked
  screen names and such.
* Removed account creation date feature until
  I can get it to work properly for all names.
* Added some direct connect commands, which
  can be found in Extra Tools, under commands.
* Built a new ICBM Parsing module to correctly
  parse and rebuild all packets quickly and
  effectiently.


Version 2.0.91
* Block Bot Instant Messages now works.
* Fixed bugs with Idletime and Away Messages
  Now works on LINKED NAMES!!
* Logging of incoming profile now works.
* Added new neat feature Set Custom Message
  Params, you can disable im's, limit
  the amount of incoming im's, and some
  other features.

Version 2.0.84
* Major bug fixes in binary module.
* Bug fixes to AIM Creation date.
* Minor bug fixes to Peeping Tom.

Version 2.0.70
* You can now view your Account Creation Date
* Added "Unlock AIM Expressions" Option
* Fixed a few UI bugs
* Redid I/O Packet meters bar.
* Got rid of Common Controls
* Fixed bugs in binary functions, may have caused crashes in
  previous versions.

Version 2.0.60
* Added 2 new privacy options, invisibility and an Ignore list!
* Added new tools menu, with 1 tool currently "Peeping Tom".
* Fixed bug with BOS socket being incorrect causing idle/away functions
  to not work.

Version 2.0.58
* Minor bug changes
* Added complete profile server
* Implemented more security features
* Implemented logging features
* Added some signon options

Version 1.0.32
* First Public Release