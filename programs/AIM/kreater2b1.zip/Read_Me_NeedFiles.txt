The Following Files Are Need For This Prog
Comdlg32.ocx - for the NotePad
And
mswinsck.ocx - for the WinSock mailer

the following are supplied:
AIMChatScan.ocx
VB5Chat2.ocx
if you dont have these to files when u dl this Prog then you should get
them they are needed for the following items:
VB5Chat2.ocx: bots, lister, m-chat
AIMChatScan.ocx: the above also!

You Should Have The Following Files With The Prog To:
b.xt, combo.xt, and Tank.lst
they are needed for the: WebBrowser, Phish Tank, and something else!(I Forgot)
if you dont have those files in the same folder as the prog then u can open
notepad and just save the File as b.xt, Tank.lst, or combo.xt