+-------------------------------------+
|                                                     
|Steal it was made by speel and        
|iam not to blame if you ge in trouble 
|aight so go steal some ips           
|-speel                               
|http://speel3k.net                   
|put mswinsck.ocx in your system32 folder                              
+-------------------------------------+
