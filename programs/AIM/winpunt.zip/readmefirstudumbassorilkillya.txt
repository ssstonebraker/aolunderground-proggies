When loading the program, if you get an error noting that oscsock.ocx is acting stupid, just goto start, run, and type "regsvr32 mswinsck.ocx" (excluding the quotes) and it should be fine. 

Also, if the punter does not seem to be working, give me an IM @ ATEX6927 to recieve an updated version, if made.


                  / \
		 A-TEX
           \\LENSHELL ONLY//
                  \ /
