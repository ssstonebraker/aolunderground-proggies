Welcome to Suspended Or Not? Build 1.1 by Splisks
--------------------------------------------------�

News And Updates:
--------------------------�

Feb. 26 - Program created and took about 15 mins total to make.

About Program and creator:
-----------------------------------�
Program is the first of it's kind. Instead of adding a name to the sign on screen 
to check if it's a suspended account then having to delete it, this will allow you just
to enter the screen name you wish to check and it will respond with the AIM
status. Just thought to make this to see what leet names I could and couldn't
crack with a private cracker I have.

Get more programs by splisks at www.splisks.com 

Enjoy -Splisks