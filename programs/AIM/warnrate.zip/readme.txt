Welcome to Warn Rate by Splisks
--------------------------------------------------�

News And Updates:
--------------------------�

Feb. 05, 2003 - Program made using tocsock1, fixed all errors, and bugs known.


About Program and creator:
-----------------------------------�
Program was created on the idea of Warn Mod by seven. I follow in his footsteps,
so I tried my best to pratice my skills in tocsock to create a simple program.
Hope you enjoy.
www.splisks.com get more programs!


Tip: Don't forget about rate limits. and if you don't have any here is a list of bots:

l33tbooter1:corp
l33tbooter2:corp
l33tbooter3:corp
l33tbooter4:corp
l33tbooter5:corp
l33tbooter6:corp
l33tbooter7:corp
l33tbooter8:corp
l33tbooter9:corp
l33tbooter10:corp