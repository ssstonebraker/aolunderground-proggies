=================
General Info
=================

If you use the custom lock characters, make sure you remember them or you will not be able to unlock your account. The locked logs saves the characters for you after the locked password in this format: "lockedpass{x-x-x-x}"


=================
Next Release
=================

 o Login Via AIM
  - ability to login your local AIM even though the account is locked

 o More Flexible Lock/Unlock
  - ability to lock and unlock without any limitations so you can unlock names that weren't locked with Password      Magic

 o Who Knows
  - Add whatever else I think will be good


=================
About
=================

Coded by Moo2
aimlabs software
