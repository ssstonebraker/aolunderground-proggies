Lab Theif Lite v1
-----------------------

PHP Script Method - Slower method, but it's good for people that our behind a router or other device and the Local IP Method will not work for them. If aimlabs.net is down, this method will not work.

Local IP Method - Very fast method, doesn't need aimlabs.net too work. May or may not work for you if you are behind a router or other device that interferes with your IP.

Lab Theif Created Originally By Moo2 and Fixer
Exploit Found By Fixer and Moo2


� aimlabs software 2003-2004
http://aimlabs.net


Other ::

1) Your victim must have add-ins enabled
2) Your victim cannot have an away message on.
3) Victim cannot have privacy settings.
4) Does not work on AOL users.