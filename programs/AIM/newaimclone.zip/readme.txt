Both these AIM cloners allow you to sign on up to 9 different names.
Please be advised that these cloners create directories in C:\Program Files\ that begins with AIM951, AIM952, AIM953 & so on.....
You may create shortcuts to the aim.exe file in every cloned folder you make. This way you will always have the 9 cloned versions of aim on your desktop.


Created by: CoMPuTer MAsSteR
Brought to you by: cyber-crimes
 