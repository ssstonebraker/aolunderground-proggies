new to 1.1: fixed the /.. `hack`, added a master name log, name log commands, a command list, and the option to auto respond with an im

to use hyper info: 1)open hyper info 2)put the directory that all the files are located in as your base directory 3)put a port in and check listen 4)click tools>profile link 5)input your main info page and click generate 6)paste the html code created into your aim profile

to use commands: just include them in your html or text files or whatever, and hyper info will replace them on the fly