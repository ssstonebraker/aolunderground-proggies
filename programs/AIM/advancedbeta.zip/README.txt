Advanced Version 1.0 Beta

+++Thanks for using my program! Although it's beta, and not all of the things work, Here's a list of what works...

-File Menu
1. URL
2.Re-Fade Title
3.Docking Prefs
4.Skin Manager
5.Change Caps
6.Credits
7.Help!

-IM Menu
1.IM Munky

-Chat Menu
1.IP Sniffer

-Other Menu
1.Fader
2.Munky Radio(Works if munky has his radio on.)
3.Sub Profile Hoster(Has non-changeable profile for now, but very good for an ip stealer)
4.Screen Name Formatter
5.Secret Area(Pass is MUNKY spelled Backwards)

-Server Menu
1.Change Server





+++Thats about it for now! Please visit www.8op.com/mrkoww for newest Versions!