Buddy Tell version 2.


Updates - has som chat options, has a better buddy list telling tecnique,
looks better, kills dupes in buddy list, lots of little things that make it
much better all around ;)


                -jimbo