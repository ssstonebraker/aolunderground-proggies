Thank you for using AIM Fader Suite.

This version does not have the auto updater, so please check with http://code-realm.cjb.net or newer versions.

Also, I love getting mail from people using my programs. Please use the contact button in thr program to send me a comment, question, or advice.