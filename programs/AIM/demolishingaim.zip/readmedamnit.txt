Demolishing AIM 1.0
http://tacoboysprogz.cjb.net
Created by: tacoboy

Thanks for dlin my AIM Prog,its my first one and this aim prog KICKS ASS
To make the sounds work,just unzip this

This AIM prog is mainly for 3.5 or higher.


















































Demolishing AIM 1.0 by tacoboy
Copyrighted 2000
All Rights Reserved TM
