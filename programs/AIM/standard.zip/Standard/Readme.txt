Standard by Gnome.

This is the first program that I have made.
This is the "beta" of the program meaning that it is still in it's trial phase and has some bugs and somethings are not enabled.  They would in beta is the mooSock likes me, but I guess it doesn't.

Thanks to:
Louis, for teaching me how to use sockets and helped with the coding.
Mike, for getting me VB, without it I couldn't have made it.
Kevin, for giving me his "sacred" boot code that he refused to passout to people.

Note:  This boot does NOT work on everyone.
Comming in the first edition:
Mobile and ghost logins
A better boot code
A code that the form will terminate if you try to boot me or certain people, the list will be released of the people
Maybe a profile that says I coded it
Any ideas, don't hesitiate to message me, but make SURE you specify that you are messaging me about this program.

AIM - Cousin Gnome
YIM - cousingnome
Email - cousingnome@yahoo.com
Site - www.cousingnome.tk

Also, tell me if this program is downloaded for a site other than www.cousingnome.tk, thank you and enjoy!

In the process of coding a chat and IM booter.

Beta is officially released on Sunday Feburary 6, 2005.  Superbowl Sunday.