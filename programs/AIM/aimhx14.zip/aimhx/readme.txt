go into AIM SETUP (wrench icon)
click SIGN ON / OFF tab
click CONNECTION button
change to
HOST: localhost
PORT: 5190
close window
close AIM
open AIM Hacker X
open AIM and sign on
to punt sum1 with AIM send them an IM with the following text: 
ug2g
if u recieve an error message they most likely have AOL and AIM Hacker X will not punt people off AOL, but u can always send them a RAPID IM

X