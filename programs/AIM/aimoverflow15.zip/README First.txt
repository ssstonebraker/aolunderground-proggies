Aim Overflow 1.5


this is for educational purposes only. under no circumstances am i responcible
 for any mishap u may get into due to use of this program. u are responcible for 
your own actions. enjoy



updated features:

bot login
stats
three more floods
logs in 50 bots rather than 30
keep track of who uve flooded
                          

                                     -jimbo