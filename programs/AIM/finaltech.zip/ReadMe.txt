Ok well here it is. this is a toc cracker all you have to
do is add sns to the notepad and pws to the notepad
before you open the cracker because it will error on your
ass. Once it opens you can add a pause in anyway you want
meaning you can make the pause ex (0.7,.07,7 etc...)
I added a few options to the cracker thanks to a friend 
and his ideas.  Any errors please let me know. Pz
 
 
-HeLL