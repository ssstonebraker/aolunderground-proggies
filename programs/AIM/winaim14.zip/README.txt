WinAim 1.4: tyler's version

Requirments: winamp 2.x        *wont work with winamp 3*
                     aim 5.x,4.x

this little prog will scroll the current song to the chat each time it changes. ive added a lot more features to it - scrambler,fader,votebot,welcomebot,djbot (vintage aol shit)

if you have any questions feel free to instant message me:  [SN](Duke7037)