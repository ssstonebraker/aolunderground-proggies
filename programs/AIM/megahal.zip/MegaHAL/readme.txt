+------------------------------------------------------------------------+
|                                                                        |
|  #    #  ######   ####     ##    #    #    ##    #                     |
|  ##  ##  #       #    #   #  #   #    #   #  #   #               ###   |
|  # ## #  #####   #       #    #  ######  #    #  #              #   #  |
|  #    #  #       #  ###  ######  #    #  ######  #       #   #   ####  |
|  #    #  #       #    #  #    #  #    #  #    #  #        # #       #  |
|  #    #  ######   ####   #    #  #    #  #    #  ######    #     ###r1 |
|                                                                        |
|          MegaHAL AIM Interface: Copyright(C) 2007 Brax                 |
|                                                                        |
|      Original MegaHAL in C: Copyright(C) 1998 Jason Hutchens           |
+------------------------------------------------------------------------+

Beta Release Date: January 17 2007

Howto:
Run from command line!!!!!
Execute megahal from command line with the following parameters [screenname] [password]. Pretty simple stuff. 
More complete howto coming soon when I'm not lazy.

After you have MegaHAL up and running simply message him once and the screenname you messaged him with will now have full access. Type /help to see the list of commands you have access to.

-Brax