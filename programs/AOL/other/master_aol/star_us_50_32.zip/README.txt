________________________________________________________

Master.TOL for AOL 5.0
________________________________________________________

Installation:  Place all files, except Master.TOL, in 
the root AOL directory.  The Master.TOL file should be
put into the AOL tool folder.
________________________________________________________

This file was made available by:  O0O, YTC, Glitch, and Koin
________________________________________________________