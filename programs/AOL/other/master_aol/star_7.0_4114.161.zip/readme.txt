MasterAOL for AOL 7.0 US GM


sup[z] to: adam, artem, atm, dime, infamous, nec, koin, plex, syg, xom and countless others.

Here it is, the first masteraol (star tool) for aol7.  To install just double click on the .exe file (you will need to input the path to your aol7), then copy over the master.tol file into your \america online 7.0\tool\ folder.  

Once you sign on you'll get the master menu, however it's a really crappy one.  To fix this delete 32-487 in the main.idx file using dbview (available at aol-files.com).  If you can't find dbview you could hex the main.idx and rename 32-487 to something else.  Once deleted, when you load aol the master menu will be 32-2543, which is also the aol4/5/6 masteraol menu.

Credit goes to Artem for hexing the main install file and the tool file.  I should mention that aol added extra security to the aol7 tools (masteraol and vpd), so be careful.  I am not aware of any security issues with this, however be careful.  In general aol7 is a big pile of spyware so i would stick to aol5 if possible :)

All files were scanned with newest version of norton antivirus updated.



-d4rk h4rk3r

___________________________________________

it has come to our attention that aol implimented scanners to scan the size of specific files  so they can see whether you're using star tool or any other add-ons that we're not supposed to be using when you sign off.  if you sign off and you see automatic updates popping up, that's aol removing your star tools.  the only way to prevent this is by killing the waol.exe process to exit, and not clicking sign off or the [x].

any questions email me: ed@koin.org

____________________________________________