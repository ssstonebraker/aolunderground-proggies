________________________________________________________

Master.AOL for AOL 4.0
________________________________________________________

Installation:  Place all files, except Master.AOL, in 
the root AOL directory.  The Master.AOL file should be
put into the AOL tool folder.
________________________________________________________

This file was made available by:  O0O, YTC, and Koin
________________________________________________________