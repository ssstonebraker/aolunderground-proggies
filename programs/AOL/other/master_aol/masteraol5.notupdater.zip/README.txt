Master.aol with Atomdebug for AOL 4.0/5.0
________________________________________________________

Overview:  These tools for AOL 4.0 and 5.0 allow 
you to invoke f1 tokens, WAOL snoop, change version 
numbers, new user reset, trace atoms and much more.
________________________________________________________

Installation:  Place all files, except master.aol, in 
the root AOL directory.  Master.aol should go in the 
c:\America Online 4.0\tool folder.  If you are 
installing to AOL 5.0, rename master.aol to "master.tol"
________________________________________________________

O0O, YTC and Glitch