This is a BETA version.  There are currently 0 bugs
More features will be added to the final version, and it will be a little more clean
So check back for updates, the final version will say FINAL