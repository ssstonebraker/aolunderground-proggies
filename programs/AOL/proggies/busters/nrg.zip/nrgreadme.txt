       
        [impulse] [impulse.creations] [i.c]

                    presents

                [nrg] (en-er-gy)

[aol.7 room.bust'r/run'r/server.help'r/download.add'r]



sup, this is impulse, this is my prog, it goes like this...

i recommend going to setup first to set all your options,
they should be self explanatory. 'keep.new' is to keep mails
as new when add'n mails.


room.bust'r:

type in a room in the combobox, and hit:
 bust to bust into the room
 or
 run to cycle through the room (ex: cerver,cerver2,cerver3)
 or 
 the plus '+' sign to add the room to the list
 or
 the minus '-' sign to remove the room from the list
 
(list must be saved, no auto-save, only auto-load of roomz.ini)


server.help'r:

type in the trigger, and the mails you are req'n or look'n for


download.add'r:

open your mailbox, and open the 1st mail you want to add. type
in the number of mails you would like to add starting with the
open one. put the pause (ex: .5 on my cable) in seconds and
click add to add the mails, hit stop at anytime to immediately
stop the process.


toolz:

various things, make sure you save your list manually, no auto-save,
but there is an auto-load. ims on/off. and you can scroll stats.


this is only release 1, if i see enough people using it, there will
deffinitely be another version, with features you wont believe, it
will be the ultimate server assistant.

questions/comments/suggestions.. email me: impulsecreations@hotmail.com