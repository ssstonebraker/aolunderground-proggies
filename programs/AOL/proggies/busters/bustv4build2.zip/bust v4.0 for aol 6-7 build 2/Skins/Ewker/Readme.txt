Skin = Untitled
App = Bust 3.5 for AOL 7
Artist = ewKeR
Date = 12.04.2001

--------------------------------------------
hey, thanks a lot for d/ling my 1st skin =)

this isn't an exceptionally great skin,
but I think it's comparable to the other
skins that have been given good ratings.

this is my first skin for this program.i 
decided to create it, because the program
didn't have too many skins yet and i thought
i could help out just a little bit in this
project by doing my part.  if the program
grows in popularity i will definitely create
some more, better skins, so look out for
those in the future.

--------------------------------------------
INSTALLATION:

very simple; create a subdir named ewKeR 
within the folder you have Bust installed, 
then unzip the files there.  once that's 
done load up Bust and choose the option to
'select skin'.  now navigate back to the
folder ewKeR and select apply.