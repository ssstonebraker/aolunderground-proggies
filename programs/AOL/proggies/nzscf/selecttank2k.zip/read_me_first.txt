program: select tank
version: public release
release date: june 6, 1999
programmers: rerun and seph
language: visual basic 3.0 professional.

note:  all vbx's and dll's must be extracted to your windows
       system directory in order for select tank to run correctly.
       also, the select!.exe must be placed in a folder in order
       for it to function correctly.  enought talk, enjoy >;)