SPIM SPANK SPAM BETA RELEASE ]
 ____________________________]
(______________________________
_________ for AOL4.0___________)
By Magoo `>
---------' this has not been tested on AOL5.0 because aol5 sucks

         DISCLAIMER
     I will take NO responsibility with the actions you take with
this program. This is against AOL's Terms Of Service and should be used
with good judgement.OK skip this bullshit have fun!

email: biological69@hotmail.com