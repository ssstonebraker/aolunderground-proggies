Here it is v.8 i finally put a room bust in it (although
its kinda buggy) the code is MUCH better i say that for
all the versions but this time there was a big change
there is still no save punt kill lists i dont think ill
ever put one in cause scrolling sux ..as it is now it
scrolls but ..its jus a little imagine a few days werth
of saved kills ..damn..

This anti was made to kill lags not im bombs or
color punts or whatever ONLY LAGS the way to defeat the
other types of punts is in the help in the program so 
read it an dont bother me saying this anti dont kill
and it was built for aolforwindows 3.0 16 bit..its the 
same damn thing as aol95 but its 16 bit for people that
dont have win95 ..if your usin aol95 (you can see what 
ver you use by lookin under the help) dont blame me if
you get the boot


I took out all the wavs an i was supposed to have some 
art but i didnt put it in either ive decided not to put
art of wavs in any other versions i might make unless
people really want it

Let me know what you think of the new looks an stuff i
dont change much but thats cause no one has complained
so far...

As always if you dont like it dont use it ..

Mailme at phishme@hotmail.com


                     -I3acK