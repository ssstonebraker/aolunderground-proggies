[BEFORE AnyThing MAKE SURE YOUR USING AOL for windows
16 bit if you dunno check under the help and about
america online it should say America OnLine 3.0 for 
windows if it dont then get it cause you cant use this]

shit i fixed

-added an ini for the person in the punter combobox

-added save manual an auto phrases so you dont have to 
retype that shit everytime you exit

- added bad ass 4.0 punts use them while they last cause
aol is already werkin on a fix for this shit

- recoded anti agin ..uh its prolly gonna be better 
least i think so eheh

-added mail me feature now you lazy mofos can mail me 
too eheh

-added a stop for the brag list (needed one bad hehe)

-fixt stupid punted save list problem now it saves an
all that shit like its supposed to

known problems:

- the manual anti ..its always been a bitch if you press 
it too much youll get an aol error with some punts
one press is plenty so settle down an let it do its job

- sometimes you can get an error if you let the punter
go on all day on some bitch jus stop it an start agin if
you really wanna punt them that much

features:

im on/off
anti pint
anti punt
punt string creation
punter
brag
upchat
anti 45 (did aol get rid of the 45 or is it jus me?)
idle bot
afk bot
pws/deltree scan
attention
mail me

ALL BORDERLESS FORMS ARE MOVEABLE jus grab the right 
edge an move them youll see what i mean

an the anti breaks only break shit antis like slams
or whatever so dont even bother aginst one of mine..

if youve used my I3acKs antis or exit light you know how 
things werk so dont bother me unless your retarded
an to all the bitches ridin my jock with your levels
an text level number wannabe type shit you all know
who your master is ..or why else did you copy me

if its got any MORE bugs (least ones i didnt talk about)
let me know at 

phishme@hotmail.com or use the mail me thing

as usual

later 

exit