sizzle nizzle?
ty for downloading my proggie bbl idle� and heres some tips for you:
dont try to pose as me cuz if you do and i find out i shall tree you...not in the chat...if you hex it..only 
---------------------------------------------------------------------------------------------------------------
if your idle reason is 'download' or 'upload' then it will scroll the download or upload line whichever one u put.
---------------------------------------------------------------------------------------------------------------
link this idler in the chat ;D  ;P lol

well.. i wont tree u if u take it as a threat......


-nyte