Blaze Idler By Swift; Forms included to help newbie programmers. Peace.

    -Swift