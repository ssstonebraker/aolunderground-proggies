 
     
 � l< 0 I2 e �  (  coder : kore ) -  afk / idle program  �

       ttype  coms to view commands you fags

	 have fun my thanks go out 
          filthgod for helpin me in certain areas
                 
                                - k0r3