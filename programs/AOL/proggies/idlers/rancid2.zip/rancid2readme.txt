rancid idle� by bany�n * rancid idle� by bany�n * rancid idle� by bany�n
rancid idle� by bany�n * rancid idle� by bany�n * rancid idle� by bany�n
rancid idle� by bany�n * rancid idle� by bany�n * rancid idle� by bany�n
rancid idle� by bany�n * rancid idle� by bany�n * rancid idle� by bany�n

hello banyon again this is an update for rancid idle v1 this fixes alot 
of the problems in the first version!

features-
---------
idler
public and private room portal
chat lamer ignorer
access profiles
IMs on
IMs off
auto mail writer
and other little things


programmer note-
----------------
to move the prog click the text on the menu bar


e-mail banyon-
--------------
gran_banyon@email.com

rancid idle� by bany�n * rancid idle� by bany�n * rancid idle� by bany�n
rancid idle� by bany�n * rancid idle� by bany�n * rancid idle� by bany�n
rancid idle� by bany�n * rancid idle� by bany�n * rancid idle� by bany�n
rancid idle� by bany�n * rancid idle� by bany�n * rancid idle� by bany�n