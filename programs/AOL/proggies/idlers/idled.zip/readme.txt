idled'01 by vsx

bugs, questions, comments - wgc@aol.com

info:
idled'01 sends download information to the chatroom...

name of file
file percent
time idle

but not only does it when downloading from aol, but
the web as well.

this can be done by selecting the "downloading from" option
------------------------------------------------------------------------

idled'01 works with:
aol version 5 and 6 (possibly aol version 4)

and

internet explorer versions 5 and 6

-----------------------------------------------------------------------

updates/addons/new versions can be found at:

http://www.taintedx.com 
as well as
http://www.lenshell.com

------------------------------------------------------------------------

files needed:
visual basic 6.0 runtime files (msvbvm60.dll)

runtime files can be found at:
http://www.lenshell.com