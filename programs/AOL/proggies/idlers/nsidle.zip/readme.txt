		   �N�N St�p Mp3z�

	sup yall..dis b xtcboi..i made dis idle for
	NS and NS memberz only!! do not pass dis
	shit out ta ne1..aiote..n type -cmds to view
	commands for dis thing..aite datz all..latez
			
					-xtcboi

        
        the trigger is  > ' <
	and -cmds