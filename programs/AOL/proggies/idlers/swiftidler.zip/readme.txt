 ,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,
 |                            Sw�ft Idl�r                            |
 '`'`'`'`'`'`'`'`'`'`'`'`'`'`'`'`'`'`'`'`'`'`'`'`'`'`'`'`'`'`'`'`'`'`'
 ---------------------------------------------------------------------
 ...........+ About +.................................................
   Sw�ft Idl�r is an Idler (Something that you leave in a chat room-  
   And it sends a line to the chat every minute) Coded By: Swift in-  
   Microsoft Visual Basic 6.0, Enterprise Edition. It uses DOS32 Bas  
   This is also my very First real Chat Idler. I hope you like this.  
 '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
 ---------------------------------------------------------------------
 ...........+ Greetz +................................................
 - Thanks to DoS for his VERY useful BAS.
 - Thanks to Beav for allways Posting my progs at his website        (lenshell.com), no matter how bad they suck or how insignificant.
 - Thanks to Masta, for making me want to be a programmer.
 - Thanks to HoBo and Dune for helping me so long ago with chatsend.
 - And, thanks to you for downloading this Idler.
 '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
 ---------------------------------------------------------------------
 ...........+ Warnng/other information +..............................
 I take no responsibility if you get in trouble with this program.  Usually, Hosts do not like Idlers. Avoid using them in public/user  chats. This program is made for AOL (America On Line), and as far as   I  know, it works with all versions. I take no responsibilities for  what  this program does to your system. T get a clean copy of it, if  you  think your copy is corupted or something, mail me at    TempFuzion@aol.com -OR- NeoSwift@aol.com. You can put this on your    site, it's freeware, as long as you acknowledge that you did not make  it... I hate posers, they are a waste of flesh. Otherwise, Enjoy.
 '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

                               ENJOY! 
       			             -Swift
