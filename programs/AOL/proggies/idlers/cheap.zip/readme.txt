------------------------------
         Cheap Idle
         By Tacoboy
 http://tacoboysprogz.cjb.net
------------------------------

This is a idler that is definently useful. It doesnt tell the reason, 
it only sends 1 line,its easy to use,its just
to the point. why do we need to know your reason idling? why do we
need to know the file your downloading? why do we need to know the time
your idling? If you wanted a idler that just sends text to the chat
every 1min you picked the right idler. hope u like it

-tacoboy