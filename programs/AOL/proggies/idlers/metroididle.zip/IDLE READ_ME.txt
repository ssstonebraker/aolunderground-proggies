Thanks for using M�tr�id Idl�r v� by.f�ng.
Complete source available, just send an email to Metroid887@aol.com to request it.




This is one of my first progs and I am very proud of its outcome.
I hope that you will enjoy using it.




Requirements: Aol7-9 +All Windows Versions




Pz Out,
-fang