<HTML><FONT  COLOR="#000080" BACK="#ffffff" style="BACKGROUND-COLOR: #ffffff" SIZE=5 PTSIZE=14 FAMILY="SANSSERIF" FACE="Abadi MT Condensed Light" LANG="0">                                            sup people<BR>
WELCOME TO BBL IDLE!!!<BR>
things you shouldnt do:<BR>

if you idle reason is download then the download line will 
show but if it isnt then it wont'

dont move this folder from c:\unzipped <BR>
because it will screw up the sounds...<BR>
dont try to pose as me....because you will fail....<BR>
things you can do if you want.....<BR>
adv. lenshell and tell ppl to download dis...<BR>
jus play around with it....<BR>
Greetz:<BR>
sup to marley<3 love you babe <BR>
xer.<BR>
cable.<BR>
nifty.<BR>
n0zl.<BR>
beav.<~~~thanks for puttin it on the site<BR>
colt.<BR>
hoax.<BR>
spyda.<BR>
colby.<BR>
hadez.<BR>
alpha.<BR>
cloud.<BR>
tron.<BR>
akujie.<BR>
flux.<BR>
everyone from progz,progs,pr�gs<BR>
l8r <BR>
-nyte</FONT></HTML>
