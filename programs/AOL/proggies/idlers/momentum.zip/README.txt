                     MOMENTUM IDLE TOOLS BY ENERTIA

LISTING ALL OF THE IDLE FUNCTIONS:

Advertise idle: Advertises momentum idle tools while it keeps you online.

Auto idle: it waits for the user-defined amout of time and if the system stays idle for that amount of time, it automatically turns on the messaging system for chat and IMs.

Chat Link idle: It sends a hyper link to chat while keeping you online.

Chat logger idle: It logs chat while keeps you online.

Message recorder idle: Takes IM and chat messages while keeping you online.

Normal scroll idle: keeps you online while sending a message you define

No scroll idle: keeps you online without sending to chat so you don't need to be in a chat room.

Request idle: It requests anything you want in chat while keeping you online. 