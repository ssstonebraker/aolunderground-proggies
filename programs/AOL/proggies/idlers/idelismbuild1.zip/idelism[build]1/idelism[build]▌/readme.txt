=================================================
|                                             idelism [ build ] �                                              |
|                                                        by                                                        |
|                                                  dangerous                                                   |
|================================================ |

about : a simple idler for aol 4.0 , 5.0 and 6.0
           with some more cool options.

thanks for downloading this.

AiM: itz dangerous
Email: dangerouslxl@hotmail.com
Web: http://www.dangerousaol.cjb.net