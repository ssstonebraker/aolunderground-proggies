9/5/02

solitaire was something i made because i was bored.
i got the form idea form hostyle. i used the same kinda chat
send as my sn collector prog because im a lazy ass  
well i hope you enjoy
if you have ANY question or comments contact me
						-seven

~contact~
seven@ascendence.net

stop by aol chatroom Online Games Help
to try and find me