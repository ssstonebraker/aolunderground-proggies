------------------------------
        PUMA Idler
        By Tacoboy
 http://tacoboysprogz.cjb.net
------------------------------

yeah i know i made another idler and its the best but i made this one
for people that wanna state the reason and put their link and all that.
this should be easy for you to use but if you dont know how to use it
contact me: ecwtacoboy@aol.com. and i just wanna say WSUP JESSICA