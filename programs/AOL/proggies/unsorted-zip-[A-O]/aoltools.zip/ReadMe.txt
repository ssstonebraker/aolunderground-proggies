the trigger for the room owner tools is +e
example: +e pat will eject pat123 or ImPaT123
+e t123 or +e 123 will also eject the same names