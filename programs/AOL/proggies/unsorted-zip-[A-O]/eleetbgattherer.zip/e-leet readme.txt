[e] e-leet screenname gather by dark

***This is the second beta of the program
***Please send me your suggestions on what it needs.
***Please send me reports of any bugs you find in the program.
______________________________________________________________

Updates in this version:
  Added User Handle Save/Load
  Added Setting/Stats Save /Load
  Added System Tray minimize Function
  Add User Selected Lobby and W/C Pause
  Added Two (2) New Collect Methods
______________________________________________________________

Send all comments/suggestions/rants/bug reports to:  [dark@reapers.org]
______________________________________________________________

| -sano |