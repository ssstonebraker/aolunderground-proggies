K you damn newberts!. i guess im finally finished with this piece of shit..
lol
Um this mp3 player is for aol 7-9
some of the things might not work for 9
i doubt it wont. it was strictly made for aol 8
Zohra you FILTH lol, for BUGGING ME all the time
here ya go!
pz<3 everyone


......biOnet ownzZzzzz