nothing much to say, but to set your handle double click 'Screen Names'
i wasnt gonna send this one in, but whatever
oh and if you want to source code for this just email me
oh and check out ascendence.net while your at it

---Contact---
seven@ascendence.net


		~~seven~~