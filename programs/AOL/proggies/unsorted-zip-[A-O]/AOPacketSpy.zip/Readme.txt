AOL Packet Spy Version 1 build 1
Visual Basic 6.0 Pro Design Environment
All coding written by Crazy
Readme.txt for AOL Packet Spy

----------------[Intro/Background]----------------

Okay, the idea of this spy, is to intercept AOL's client/server communication packets.
The idea behind this, was brought to my attention while reading GodsMisfit's document
on the AOL Protocol.  What this program will do is, after setting up AOL's client to connect
to your computer on port 5190, it will then connect to AmericaOnline.aol.com (aol's server, there
are other berp servers that can be used aswell.) After the connection to your computer, then to
AOL's server is complete, it will listen on that port, for incoming/outgoing packets.  Any packet
sent from the AOL server will be relayed to the AOL Client, and any packet sent from the
AOL Client will be sent to the AOL Server, but only after being recorded, cause after all, that was
the main idea behind this.  After you have logged your desired packets, highlight the ASCII you
want converted to HEX.

This program will NOT tell you how to construct and send AOL packets, for the main reason
that I, myself, am still learning how to do this. I made this for myself, for the sole reason that
most "packet sniffers" pick up ALL< outgoing/incoming data, most of which is completely
useless.

----------------[Instructions]----------------

The first and most important thing when you first open this program or rather, when you first
START the relay of this program is to go to Options > Set Client Connection.  Information on
what to do will be provided to you.  If you don't understand what is going on after you go to
the Set Client Connection, just click the button with the caption "..." and a pop-up will appear,
hopefully clearing up any bad thoughts or misunderstandings.

After you set your AOL Client's connection, go to File > Start Relay, load up the client
of which you set the connection, and click signon.  After doing so, you'll see packet data
being logged in the Relay List.  (right click this list for more options)

If you are confused, I have added a Help section to the program as well, and I have added
information about the Connection Setup in the Options menu too. If you have any questions
go to the Help > Contact and get in touch with me through any of those sources.

----------------[Outro]----------------

Expect more to come with this spy, just don't expect it soon.  I will first learn, and get very good
at AOL packet construction, then I will add clients and self constructions, along with
explinations to this program, so keep a look out ;)


Readme.txt Finished
Written by Crazy
Crazy@Hacker.vg
www.maraidesigns.com/~crazy