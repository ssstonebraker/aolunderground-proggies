          
......................................................................
.progrm name..............: ley cripta power
.program creator..........: Ley spider ley
.program description......: this program contains laggers and macros
.this program working for.: aol 7.0  at aol 9.0
.this program working for.: windows 98  at windows xp
.......................................................................


......................................................................
......any cuestions i.mail me to the next addres
......leyempireley@aol.com
......leyspiderley@aol.com
......leymidoryley@aol.com
.......................................................................