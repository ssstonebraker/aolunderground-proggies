              <�`�-�LeY cRipTa By : Alvaro�-���>
     \______________________________________________________/
  visit my webpage at: http://hometown.aol.com/leycr3atorley/index.html
        wassup?  thanks f�r d�wnl�ading my updated LeY cRipTa
   
     .ley cripta work's for : aol 7.0 - 8.0 - 9.0
     .this program was make'it por  windows xp
     .but work's for windows 98 too

     .any cuestions i.mail me to the next addres
     .leyempireley@aol.com
     .leyspiderley@aol.com
     .leymidoryley@aol.com

     .in the webpage addres you see on the top
     .you quen be see the page what i make'it for my girl
     .the pictures you goin a se thst's me and my girl

     .espero que se diviertan con este programa
     .mi nombre es Alvaro.. y les deseo suerte bye