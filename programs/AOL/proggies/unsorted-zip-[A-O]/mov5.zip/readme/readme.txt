this is the final version of Mario Online(maybe,not sure) Mario Online
5.0 has over 200 KeWL options,hope ya like it,mario is not responsible for anything
done with this here is an exsample
kid:i got tosed using mario online 5.0
kid:i'm gonna tell them itz your fault
me:nope,read the readme ;) or read the pop up msg box ;)
kid:::reads readme::
kid: grrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr!

heh,nice exsample huh?

peace -mario