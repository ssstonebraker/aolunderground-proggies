Dragon Toolz 1.8:
=================

Thank you for downloading Dragon Toolz 1.8 the set of anti-aol, mild hacking and useful tools! Dragon
Toolz is really a program I made in some of my spare time so that I had something to play with in IT
lessons and stuff, also I was wondering how hard it is to make an AOL program and its really easy! I
hope you enjoy the program and please dont get into trouble with it! Also if anyone would like to
make a program but doesnt know where to start the source code for this program is on sale at
www.dragontoolz.cjb.net for about $19.95 or �13.95. Have fun!
~Peter

PS thanx to the author of the wordlist I supplied with the Brute Forcer, and to http://www.jsiinc.com
for the list of sendkeys commands!