                           *** Battle Master 3.0 ***
                             *** By Jenova Ice ***
                              *** User Notes ***


AOL 4.0 - Everything on this helper works fine for me except for the AOL
4.0 part.  I neither like or use AOL 4.0, some people have told me it works
great, others have told me it doesn't.  If for some reason out of my control
the 4.0 part doesn't work for you don't complain to me because I don't
program for 4.0 and wasnt even going to originally make this 4.0 compatible.
Also, because I don't program for 4.0 I didn't take the time to make the 
manipulator or overflow guard work on AOL 4.0 so don't email me telling me
they don't work.

Overflow Guard - This has worked great for me, but some of my beta testers
couldn't get it to workf or them.  If it doesn't work for you then don't use
it.  I have a detailed explaination on how to use it so don't email me if it
doesnt work.  As said in the first section...this is 4.0 compatible!  Also
the overflow guard only guards against gold, not your stats.


OverFlow Guard - Instructions
1. In the first box you put who is hosting the game.  
2. In the second box you put who your guarding.
3. In the third box with the 0 you put your starting amount of gold.
4. In the forth box you put your level.

When FFE say..."SN gains ? exp and ? gold." The overflow guard should scroll
something about calculating gold, and you should see the box where you put
your gold amount rise.  When the guard calculates that another turn will
result in an overflow a message box pops up to let you know.  When you gain
a level your level will increase by one.

The overflow guard only protects you from gold overflowing, not stat
overflowing.  So if you overflow and your gold wasnt over than more than
likely it was your stats fault not the guards.  This guard isnt 100%
accurate so be forewarned.