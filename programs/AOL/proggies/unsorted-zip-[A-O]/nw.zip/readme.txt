nt - nick@bitstorm.net
site - http://hoto007.simplenet.com
-------------------------------------------------------------------

sup?
	thanks for taking your time and downloading my very first 
full prog for america online 4.o. this sweet shit has about 120 
options to choose from. there all useful and helpful too. not like 
gothic nightmares which has alot of things that you will never use.

this includes:

- room buster (50 times a second)
- phisher and manager
- decomplie protect
- chat clear
- add room (adds to text for copy)
- 15 bots
- chat and im manpiulator
- midi, cd and wav player

and much much more options!!
dont't forget to check out my aol download site which contains progs
for aim, aol3.o, aol4.o, pwc, phishers, room busters, etc.. i will
also be adding mp3's and sables playboy edition in the future if 
i get more clicks on my sponsor..l8er

site - http://hoto007.simplenet.com