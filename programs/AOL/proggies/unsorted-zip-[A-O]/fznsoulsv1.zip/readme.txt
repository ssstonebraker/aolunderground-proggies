[Prog Name:]     frozen souls v1.0  -=by netheren=-
[AOL Versions:]  9.0 SE Optimized and Security Edition
		 However, you can download "code updates"
		 for all versions of AOL at my web site:
		 http://neth_aol.tripod.com/
[Install Notes:] Unzip, run frsoulsv1.exe
		 DO NOT MOVE ANY FILES FROM THE UNZIP DIRECTORY.
		 If errors occur, obtain fs1comp.zip from:
		 http://neth_aol.tripod.com/fs1comp.zip
		 and unzip to:
		 C:\WINDOWS\System32\
[Other Notes:]   As simple as this prog appears at first glance,
		 it packs a hell of a lot more then it seems.
		 There are over 30 working features in this prog,
		 excluding secret areas. Why, then, are there
		 only ten buttons? INNOVATION! This prog combines
		 many features into one, allowing you to use them
		 much more widely to do what you want.
[Contact:]	 My e-mail address is: neth_aol@yahoo.com
		 I hang out in private room: frozen souls