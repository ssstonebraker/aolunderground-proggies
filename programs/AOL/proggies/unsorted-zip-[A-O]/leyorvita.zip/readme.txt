
....................::::::::: LeY oRviTa LeY ::::::::::...............


..................program name : LeY oRviTa


...............program made by : LeY cReaDoR.. "Alvaro"


.............program works for : aol 7.9    &   aol 9.0


.......................and for : Windows xp  &  Windows 98


.....any cuestion send mail to : leycr34dorley@aol.com