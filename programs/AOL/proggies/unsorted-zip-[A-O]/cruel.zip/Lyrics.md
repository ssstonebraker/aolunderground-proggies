Welcome my son, welcome to the machine.
Where have you been ?
It's alright we know where you've been.
You've been in the pipeline, filling in time,
Provided with toys and 'Scouting for Boys'.
You bought a guitar to punish your ma,
And you didn't like school,
And you know you're nobody's fool,
So welcome to the machine. 

Welcome my son, welcome to the machine.
Where have you been ?
It's alright we know where you've been.
You've been in the pipeline, filling in time,
Provided with toys and 'Scouting for Boys'.
You bought a guitar to punish your ma,
And you didn't like school,
And you know you're nobody's fool,
So welcome to the machine. 

Welcome my son, welcome to the machine.
What did you dream ?
It's alright we told you what to dream.
You dreamed of a big star,
He played a mean guitar,
He always ate in the Steak Bar.
He loved to drive in his Jaguar.
So welcome to the machine.
