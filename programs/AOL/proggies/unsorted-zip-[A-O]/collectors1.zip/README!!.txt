C�llector - S� .... By: seven

this is just a quick SN collector i made becuz there alot
of them out there but they're all fancy and have a bunch
of functions useless to a SN collector. mine aint fancy, and
i didnt want it that way. so thats about it

E-Mail = seven@ascendence.net
 
	sup to all the ogh regs, you know who you are
