- missing files -
Please do not ask me for files you have not obtained.
The only controls needed for my project is the Visual
Basic 6.0 Runtime files. You can simple download those
from microsoft.com.


- found bugs -
I do ask that if you find bugs that you report them to
me. I need any comments what so ever if it may help me
improve my work for the better.


- ranting on my work -
Take it elsewhere. I don't need to hear what you've got
to say if it happens to be bad. I only hope for the good
commentary. Please hold the rants to yourself.


      ______ The Words Of WaV! ______
     |                               |\
     |    aim: swcwhat               | |
     | e-mail: j_reeves9@hotmail.com | |
     |_______________________________| |
     \________________________________\|