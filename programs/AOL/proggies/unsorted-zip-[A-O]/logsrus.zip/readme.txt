Logs 'R' Us - Art and Code By: James de Mattos (Swift)

*Features*

*Automaticly Saves the log on each new line

*Automaticly removes scrolled lines. 

*Sweet looking I-Face - I dare you to find a better I-Face as sleek looking without special effects like this!

*Made by Swift!

(IMPORTANT!) After each session

E-mails/Screen Names:

	b3y0ndabyss@aol.com
	swiftgeneration@aol.com
	nelocus@aol.com
	xxnuclearxx@aol.com

Enjoy this Swift Production!

Last Edited: 1:48 AM 7/17/2003