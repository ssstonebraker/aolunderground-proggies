ChatLogger, By: Swift

This Simple Application Will Log Any And All Text In An AOL Chatroom.
It Does NOT Take In  Effect Color Changes Or HTML. It's Sleek And Simple.

The Only Notable Feature That it has Is That It Can Save As A Text File or an HTML File.

Enjoy This Swift Production.