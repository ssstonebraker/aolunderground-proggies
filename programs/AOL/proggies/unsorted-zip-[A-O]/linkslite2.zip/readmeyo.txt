links lite 2.01 : by snot
krew : scorpio
bugs: email to dayslastsunset@aol.com
         aim: wheresmyk3ys
         www.deeplydemented.com/snot


Currently works for      Windows 98/ XP :     AOL 7.0/8.0

it should work for alot, email with what does.

howdy, this is the main beta to make sure all the links work and stuff
the mass imer is kinda sketchy and room buster dont work. LOL gimme
a break I made it yesterday. 

**Fixed: Link Number
** Custom Duration / Link Color
** Fixed font errors


thanks yall - snot

