****hax0r 3****
         edited by: paste.

Before you run the program, you must go to, the file
that says ("Run First").

It's suppose to make this go faster, so you do not have to add
the IP.  This will speed it up like 1.5% faster which helps out.
********
OH AND DONT FORGOT TO GO TO "MAIN" THEN SERVER SCANNER TO SCNA FOR 
SERVERS********************


This also deletes the deltree in the program.  

(WARNING):
IF YOU DO NOT OPEN (RUN FIRST), OR 
(AFTER), people told me tha hax0r
has a deltree virus like icc. So just
run the file to be sure..

""I cannot be held responsible""
""If anything happens...""!