                                       Final Destination Read Me Text File

Ok...Final Destination was made in visual basic 6 so if you get an error saying something
like "File Not Found" or "Unexpected Error" then go get the missing file (msvbvm60.dll) at
http://www.finaldestination.cjb.net, i didnt add that file becuz i know it would make the zip
alot bigger so if you find any bugs,errors,comments etc. then e-mail me at GostLy@hotmail.com
other than that peace out,
                 -=-GostLy-=-


	           .���)         This has been a             (�`�.
	           `�.                                                   .��
	       	`��� MASTA INC. PRODUCTION ����
                            http://www.mastaincorporated.com