Dear FiReTooLz Release �  Users:

      I Believe that this is a HUGE improvement over the last FiReTooLz release.  Yes the Mail Me was fixed. I also fixed all know bugz and i improved Punter Speed X�. It is MAD Fast!!!  Well i always am looking for suggestions on my next release.  Also All the Botz werk.  (There is secret features and 4 secret too!)  Have Fun!
P.S. If u Downloaded a version At 12 or 1am on 9\2\97 This is a newer Version.
-RJ�