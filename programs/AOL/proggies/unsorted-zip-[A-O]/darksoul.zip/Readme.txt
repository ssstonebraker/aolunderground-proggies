		SuP PeePs,

	This is my very first program for any AoL....I am constantly upgrading and improving
it...if you want information about the next version..just use the mail
SouL feature on the prog...if you find any bugs please lemme know..
Thanks

			BeTa VerSioN 1.0    -- SouL