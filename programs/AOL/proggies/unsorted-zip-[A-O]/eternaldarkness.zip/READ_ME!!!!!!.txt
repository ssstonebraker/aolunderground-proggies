Okay, this iz HoaX.  If this prog iz missing any files, E~Mail me at H0ackz@aol.com (that'z a zero by the way).
There iz an Up-Date to this prog at www.LensHell.com, www.dawgzprogz.com, and www.geocities.com/bryanh6969.
The source iz also posted at www.dawgzprogz.com (my site).

                ���鮞
                      ]-[���