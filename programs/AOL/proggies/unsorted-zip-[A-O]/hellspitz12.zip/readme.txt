this prog/ccom needs vb5chat2.ocx and/or chatscan3.ocx , thanx for downloadin this prog.

    -kypnotik