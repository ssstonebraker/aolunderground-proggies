Hello not much to say. I have used so many faders, but they all suck. I don't care what anyone says I still like faders. So, why not make one? the other version i made i didnt send to anyone because I made it for me. If you have ANY questions or comments contact me.


----Contact seven---------------------------------
AIM Name: ogh loser, bong labs
E-Mail: seven@ascendence.net

check out ascendence.net