


***********************         --LeY FADER V2--     *****************************


PROGRAM NAME : ............. LeY FADER V2



PROGRAM CREATOR : .......... LeY cReaToR - ALVARO



THIS PROG WORK'S WHIT : .... AOL 7.0  - AOL 9.0



WHIT WINDOWS VERSION :...... WINDOWS 95  -  WINDOWS XP



IF U HAVE ANY CUESTION SEND MEE MAIL TO :...


.....( ALVAROTAPIA_2@HOTMAIL.COM ) OR ( LEYLORDZLEY@AOL.COM )......