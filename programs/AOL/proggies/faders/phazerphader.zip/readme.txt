Open HowToPP.exe befor using the Phazer Phader.

   I hope you like it... Peace.
                                -Swift