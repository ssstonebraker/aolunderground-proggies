1. Extract all Files to Same Directory.

2. Open "How to Use PP ���.exe" First!

3. Enjoy this Swift Production