())()()()(0

This is a HTML Fader. Not a AOL fader. 

If you would like the source code, then talk to me at: mink2k1@hotmail.com
or aim: mink3k


Name: A-QUARD - HTML FADER
Version: 3.2
Creator: James Farmer (GonGy)

Flash was made by me, James Farmer (GonGy). The skin was made by:
Beav. I hope you enjoy and good luck with your website/or anything in 
general!


-jim  '02

1/8/02

Happy Birthday Elvis!

()())()(999)()()(



http://www.jameslair.cjb.net

http://www.jamesmariobros.cjb.net

http://www.lenshell.com
