This has been brought to you by the azian guru. 
Another quality download.
Remember to scan everything to get just to reassure everything
is okay, just incase i missed anything. 
If this program is not working it is probally 
missing some dll files or vb runtimes
you can get those from my vb section.  
-------------------------
http://come.to/azian_guru
iamthe_guru@hotmail.com
-------------------------
If you did not download this from the site: Azian Guru's Domain 
then some lamer linked my uploads, report it to me if anyone 
has linked my d\ls so i can herb them. thank you.
--------------------------
Dont forget to sign my guestbook and check the messageboard.

updated this read me 4.5.99