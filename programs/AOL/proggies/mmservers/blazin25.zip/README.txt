Sup, this is heat. I want to give you a few tips before you go out serving =)
When serving make sure you have all those AOL programs you have closed or they will lag you
to death like Solar Winds. You can also close your virus detector or any other programs that
you don't need running when your serving because the server takes up a lot of memory when it is
running. I also recommend not doing anything on the AOL your serving on because anything
could mess it up completely, but the chat & serve option can be safe sometimes. If you find any
problems or bugs please email me at "iiheatii@aol.com".

Alternative Download - http://blazerver.hypermart.net/