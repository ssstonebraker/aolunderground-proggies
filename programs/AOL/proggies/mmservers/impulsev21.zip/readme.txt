�..deeznuts�.. [impulse app server v2.1]


���file info 

prog: impulse app server
type: recruiter
build: 2.1
first date compiled: 06/00
last compilation: 12/00
compiled w\: Microsoft Visual Basic 5 Enterprise Edition
art: bowzer
bas: skraz32.bas (thanks raz n san)
ocx: dos' widely used ocx's
group: deeznuts
author:	bowzer 
	aka
	syko
contacts:bowzer_oner@hotmail.com
aim: syko
compatible: aol 4/5 - :uses aol mail:
	    windows 95/98/me/2k?

requirements: AOL 4.0 or 5.0 installed
	      chatocx2.ocx by dos
	      for viewing greets: swflash.ocx




comments:

 sup peeps i made this recruiter for all you lazy peeps out there.. i made this a while back.. i dont think anything like this existed.. but recently i have seen a few like it... it was originally just made for my members, but other peeps wanted it.. so here it is.. its not a greatly coded program.. jus something i started on long time ago and got to work. so dont bitch if it skips sn's or freezes on you.. also a little note.. on the previous versions.. it somehow froze on people when it was turned on.. if that happens.. set the scroll interval to 60 secs, it usually does the trick. laterz. enjoy.

-bowzer

much props out to:
the deeznuts krew. my lady mzloca
top,neo,loop,sk,raz,chris,orion,peludo,shutdown,inept,shorty,
spider,sexz,champs,moo,lo0ny,tati,n0ze,mike,bo0t,uni,wena,outlawz,baller,drake,shadow,
vtec,lazy,fatso,ai,thuglife,as,thugstylez,od,trutalent,jayvee,
eh,n to everyone i forgot, be happy, cuz if i ever go ona hitlist, they wont know ur
my friends and kill ya too. haha. and stay up peepz
laterz

 �2000 �eez�ut� �nd�rgr���d
       �N
         -don't bite-

*props to Tenchi n Menace da originals of DeezNutz*

