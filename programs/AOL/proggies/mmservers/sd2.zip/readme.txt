====sd� by visi�n for aol v4.0 - v5.0====
version 2.0.0
created on 08.30.01
decription: MMer for AOL4.0(upgraded)-5.0
website: http://go.to/laoboyz
sys.requirements: 300mhz+, 56k+, aol4.0(upgraded) or aol5.0
required files: vb6 runtimes, chatscan3 or chatscan�
files in this zipfile: readme, sd�.exe, sn.lst
upgrade: replace ur old sd�.exe with this sd�.exe
====thanks for using my program!====