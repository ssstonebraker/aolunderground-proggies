This file was downloaded from bofen.com!

liquid inferno server for aol 4.0 & 5.0
coded and designed by -bofen-

!! HOW TO USE LI SERVER !!

Before serving, you must create your serving list(s).  To do this, you will need to open up the List Designer, which is found under the Options menu.  Once open, you can click 'Auto' and it will automatically run steps 1 - 4 of the list making process.  Which means it will do everything for you, it's entirely automated.  If you want to do everything manually, you can click on each step and click 'Run'.  So I suggest you just click 'Auto', since its faster and easier, but some people like to do everything manually so they can configure some things to their preferences.  Now, if you've already created lists before, and haven't changed anything in your flashmail, you may click 'Old Lists' and the server will use your previously made lists so you don't have to go through steps 1 - 4 of the list making process again.  Just make sure you haven't changed anything in your flashmail, otherwise people will be getting wrong mails and errors may occur.  Now you are ready to serve!  You can configure the suffix message and the mail message by clicking 'Messages...' under the Options menu.  Click 'Start' to start the server, and 'Stop' to stop the server.  You can pause the server by clicking 'Pause', which means it will stop sending requests, but still take requests.  You can then resume the server by clicking 'Resume' which will enable the server to start sending requests again.  You can click 'Finish' to have the server stop taking requests and finish sending pending requests.  Whenever you stop the server, a serving report will pop-up.  Click on 'Copy' to copy the report to the clipboard, or click 'Send' to send the report to someone.


!! LI SERVER SOURCE CODE !!

There should be a zip file called "source.zip" included with this zip file.  It contains the source code to Liquid Inferno Server.  The file is password protected, so you will have to buy the password to the source.zip file for only $15.00!  Mail me at bofen@hotmail.com if you are interested in LI Server source code.


!! OTHER INFO !!

website - www.bofen.com
email - bofen@hotmail.com