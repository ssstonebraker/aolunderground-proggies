New for this beta release: (bug fixes and additions)***
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
-Mistake in v.99 fixed, works on aol95 again
-Fixed for aol4.0 user's requests (ignores "<aolpromo>")
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
-New option to disable search queries.  
-Updated to automatically save the options you select!
-List sending has been improved! You can set time intervals to send them.
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
-type mismatch in mmer bots is fixed
-Illegal function call in mmer bots is fixed
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
-overflow error on aol95 server is fixed
-MMer bots have been repaired from room busting errors
-Updated even more for aol95 users
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
-Fixed the bug that causes the server to stop during room change
-Improved the performance of the server for aol95
-Fixed overflow error on mm bot (as far as i know if not mail me)
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
-Added Status bars so you know the percentage of completion for some tasks
-Added server message so you can get a message in all the mails that your serve
-Fixed the bug that caused 2 list max serves.
-45 minute bot should be repaired(i am not 100% sure because i dont dial aol)
-List sending bug that removes the top request in the pending list
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
-finally fixed that damn file not found error that happens.. 1 charachter of
 code can really mess things up cant it!
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
-Updated forms! New and improved colors!
-Fixed "out of string space error" on sending lists!
-Server Updated for All versions (especially aol95) to be more reliable!
-New Speed List option that allows you to send lists from your own mailbox!
-Room Buster has been fixed to work for aol95!
-Room Manager has been fixed to work for aol95!
-And anything else I forgot to mention
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
If you run into any bugs e-mail me at  MMEvicTioN@aol.com 
thank you for your beta testing of UnREAL!
Eviction


*** this line -=-=-=-=-=- seperates from each release of unreal.. so the line
at the top is the most current fix