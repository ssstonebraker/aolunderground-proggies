=============sdi� = special delivery=============

This was coded in VB6 enterprise edition
If you have problems you might need the following files:

-chatscan3.ocx or chatscan�.ocx
-vb6 runtimes

You have to save a list 1st in order to start the mmer.
-visi�n
==============================================