====sd� by visi�n====
version 1.0.3
created on 02.23.01
decription: MMer for AOL4(upgraded)-5
website: http://go.to/laoboyz
system requirements: 300mhz+, 56k+, aol4(upgraded) or aol5
required files: vb6 runtimes, chatscan3 or chatscan�
files in this zipfile: readme, sd1.exe, sn.lst
upgrade: replace ur old sd1.exe with this sd1.exe