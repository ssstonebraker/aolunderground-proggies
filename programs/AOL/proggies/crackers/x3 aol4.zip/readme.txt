X� Password Cracker  (By BoFeN)
---For AOL 4.0 (32-bit)---

You must be logged off of AOL and have the
'Sign On' screen visible.  You should be TCP/IP
connected although it will work with regular
connection but will be MUCH MUCH slower
than TCP/IP!

Ok, the default passwords in the pw list are:
[SN�]
[SN�]
[SN�]

So lets say a person's screenname was "JonDo1234"
[SN�] would be "JonDo1234"
[SN�] would be "JonDo"
[SN�] would be "1234"

Everything else on the pwc is pretty self-exlpanitory!

This is still beta, so let me know if something doesn't
work right on your computer or if there's anything that
I should add, just mail or IM me...


(Note: If you get an "unexpected error" message, that
means you need the newest version of the Common Dialog
Control)

http://www.bofen.com/