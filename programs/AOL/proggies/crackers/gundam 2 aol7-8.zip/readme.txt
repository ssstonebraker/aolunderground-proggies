-gundam v2-

well its not all that i promised but what i didnt add i made up for with a
method selector.  I'm not too sure about how good this will perform cause like
i didnt have very active beta testers that told me everythingthat was wrong.
i know that i personally had some problems while others didnt... its weird.
so anyway i recommend trying lobbies at first until you can determine whether
this is reliable or not.  anyway at least it dont steal cracks =P

-keith/sinn
