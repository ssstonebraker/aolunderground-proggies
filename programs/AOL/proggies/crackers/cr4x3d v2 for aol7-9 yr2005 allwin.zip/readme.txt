nothing much to explain about this prog really.. it cracks someones account
password... thanks to Br� for releasing BrUToC... huge thanks -=]