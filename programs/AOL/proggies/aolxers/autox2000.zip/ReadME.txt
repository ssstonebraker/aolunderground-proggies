*****Auto-x 2000*****



FEATURES:  16 Word X-List (totally Customizable to any word)

	   Auto X on Room Entry (you tell it a Screen Name, it X'es 
           it when its found in the room

           Room Buster (Totally Compatible with new AOL Rate Limits)

           Flawless Word Ditection (No-Error word reads gets them everytime)

           No Scrolling (cant get logged off for scrolling)



Version:  Version 1.0.5  For AOL Versions :  4,5


***Thank You for downloading my software, enjoy and piss some people off for me***


						-Intricate