_____----db realm db----_____

hey you! thanx 4 downloadin' from realm! 

peace out,
society

p.s. dont be a lamer with my prog and ignore every1. 
the c-coms option is located in the options button.
type .x [lamer] to ignore some1. YOU MUST HAVE C-COM ON 
DO THIS!!