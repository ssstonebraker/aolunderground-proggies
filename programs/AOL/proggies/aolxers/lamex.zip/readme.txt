=======================================================
                                               lame X'er by dangerous
                                                  for aol 4.0 and 5.0
=======================================================

sup this is a simple X'er i made in two days
noting really big its good i guess,
give it a try and enjoi.

thanks fo downloading it , if ur missing any files
u can go to my friend's beav's site [ www.lenshell.com]
in the vb section or prog files section and download any missing file(s).

thanks..
-dangerous

AIM: itz dangerous
Email: dangerouslxl@hotmail.com