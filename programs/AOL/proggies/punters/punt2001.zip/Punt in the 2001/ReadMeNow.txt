Name: Punt in the 2001
by: nk
for: ONLY aol 6.0
made in: Visual Basic 6.0
other info: I, nk, hate punters.  No way in hell would I ever make a punter unless someone asked me to.  PHAT, of FreeProgz.com asked me to make him Punt in the 2001 (version 2 of Punt in the 2000) for him as a FreeProgz exclusive because turtle, the original maker, was too busy.  So keep in mind although I made this program, I do not agree with what it does.  Thanks.

-nk-
-nkillaz.com-