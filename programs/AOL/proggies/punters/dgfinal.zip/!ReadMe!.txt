here is the deal...i wanted to make sure it was released for Halloween
so you need to download the wavs into a folder on your C: drive so 
they will work... the folder name NEEDS to be...    C:\DieGod   
they will all work then and if you want they DIEGOD.Wav to work in
the chatrooms then copy it to your windows\system folder...hope you
DieGod and remember it was my first so there will be alot better to
come...peace and have fun...dont forget to go to my site...

http://www.ritman.com/lenshell

keep checking ritman.com if AOL kills the page...we will always have
that domain -ritman.com- so try lenshell2, 3, 4 and so on...and even
try... 
http://www.ritman.com/lenshell/index.htm or .html  

we will never die!!!


Beav