Sup this is NoMercy...just to let you know this version of Static  (Static Gold)kicks serious ass!!!  
  All of the punt methods work Great!! I added more shit to it like im/Available checker
  afk bot (for aol3.0 only) and Improved the Room Buster it works great! it also auto detects
  if a person turns off ims during a punt! Sounds are cool too...if you got a version without sounds
  email me at xNoMercyx@mailcity.com....and dont forget to check out my site at NoMercy.Simplenet.com!!!
  And my bro's site http://come.to/AolProgz!!!

*Static Gold works with aol3.0 and aol95 doesnt work with aol4.0 but will punt 
the shit out of someone on it!!! hehe..later

Thanks for using Static Gold!!!
