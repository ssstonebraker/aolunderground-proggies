Worm's 1 IM Punter 3 By: Worm
�opyright 1997-1998 Worm Production
_______________________________________________________________________
  Well, I (Worm) have come out with the 3rd version of Worm's 1 IM Punter.
Thanks for chooing Worm's 1 IM Punter 3. This is the third version of:
Worm's 1 IM Punter. As you can see it has a lot more stuff and works a
lot better then the 1st and 2nd ones. First it has every AOL version
so you can punt people off every version of AOL. Plus I added a new
method called: AOL Combos. This will punt them with all of the AOL 
version strings. Making sure they get booted everytime.
 
I fixed many little bugs from the 2nd version and added new things to 
the 3rd version like a:

Room Bust
Killwait
Better Anti Punt
Better WAOL Error Mail Punt
New Punt Method
Idle Bot
and fixed some little problems..

 I would like to thank everyone who helped me and supported me while
making this program. Don't be surprised if you see another version of
Worm's 1 IM Punter.
_______________________________________________________________________
