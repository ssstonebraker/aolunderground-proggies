Important - 10:46 PM 6/28/98

Make sure you put the .dll and .vbx files in your 
C:\WINDOWS\SYSTEM Directory. If when you run the program
it says: File Not Found!, it's because you haven't added
these necessary files.

Enjoy the Program,
Zombie

P.S. - Look for my full program coming out very soon!