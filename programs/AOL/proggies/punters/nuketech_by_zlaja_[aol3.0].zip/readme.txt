    |\  | |   | | / |~~~ ~~~~~ |~~~  (~~~ |   |TM
    | \ | |   | |/  |__    |   |__  (     |===|
    |  \| (___) | \ |___   |   |___  (___ |   |
_______________________________________BY ZLaJa______

Thanks for downloading my punter,This is the newest
kind of punter on aol. It actually punts people off,not
like the old punters. It kicks people off in just 1 im
unless they are stupid fucks and sit there for hours
thinking that the WAOL error is gonna go away. This 
punter is 100% clean and safe to use it was not created
to damage people's computers or steal their passwords.
But if some lamers infect the punter with a virus i will
not be held responsible for it or any actions that you
decide to do with this punter. I have not found any bugs
so far but if you find something that is not functioning
mail me at zlaja@fcmail.com or ConvictBeta1@hotmail.com
I hope that you enjoy this punter and have lots of fun
with it on aol. The next version will be out pretty soon
it will have many great features like mass punter and so 
on.
 
-nuketech version�
-date 5/30/98
-contents:nuketech.exe,311.dll,vbmsg.vbx,dbpush.vbx
 readme.txt