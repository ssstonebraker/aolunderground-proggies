______________________________
-Chronic Trigger 1.0 By - Sky-
������������������������������
__________________________________________
Date Started:	December, 1998	
Date Compiled:	March 21st, 1999 (12:36am)
Build:		1.00.0009
Designed For:	AOL4.0 (4.0, and ONLY 4.0)	
E-Mail Sky:	Sky_Chronic@juno.com
AIM Name:	talk sky	
������������������������������������������

*******************************IMPORTANT*******************************

MAKE SURE THAT [WORD WRAP] is CHECKED under the EDIT menu!!!
	-Before running Chronic Trigger, make a copy of all the
	 OCXs into your system directory. Overwrite files if asked.

*******************************IMPORTANT*******************************	

	This was the first, and probably last program that I will ever write for AOL4.0, maybe even AOL period. AOL programing, (if you can even call it "programing"), has gone to the dogs. It seems that everybody knows a bit of VB. I know all you people have heard this speech 100 times over, but you have to admit it's true. Though I've said that i would quit before, I always came back. I don't know, I'm just bored sometimes. 

	The reason why it took so long to finish this was because I got so bored of working on it, I'd work on other things or just put it down completely for weeks on end. I could have gotten it out sooner if I just wasn't so fucking lazy. Oh well though, atleast I finished it at all...I'm surprised I finished it at all.	

	Anyways, this is a pretty decent AOL4.0 proggie. It's made to work with AOL4 and ONLY AOL4. NOTHING works on any of the other AOLs, so don't even try to use it on anything except AOL4.0. 


______________________
Things You Should Know
����������������������

* I'm POSITIVE that there are bugs to be found in C.T. To be honest, I don't give a fuck. I'm to sick and fucking tired of working on this piece of shit proggie to fix them so you'll just have to deal with them. Still, even if I don't care, tell me if you find a bug by using the [Mail Sky] feature.

* Alot of the feature are build on automatic saving and loading, instead of manual. For example, the phish tank automatically saves / loads your lists on loading / unloading the tank. This was a bad idea in some cases like the phish tank, but it was a good idea in other cases like the room buster. I autosave on alot of things over manual save / load because I'm lazy and it's easier for me. Plus, how many people in your household could possibly even use this proggie? Probably only the person that's reading this.

* Practically all the listbox's can be handled in this fasion: DOUBLE CLICK to remove an item, press ENTER in the textbox to add an item. Sounds simple enough and is simple enough, but some people just don't get it and think that C.T. is "broken" or "gay".



______________
Features FAQ's
��������������

* The [flash mailer] is a MASS MAILER. The only thing weird about it is that it only mass mails FLASH MAIL. (Which is the only mail that really should be mass mailed). I figured that everything else is so slow, (new mail, old mail, etc...). AOL4 flashmail isn't very fast, but it's the best you can do for mass mailing on AOL4. (I suggest aol2.5 to serve and mass mail)

* The [flash server] isn't in C.T. because serving is pretty much pointless on anything except AOL2.5. 

* I know punting is stupid. But, people like to do it so I decided to put one in C.T. Unlike other punters, C.T. WON'T PUNT YOU BACK! You know how AOL makes IMs reflect now? Well, that's not a problem anymore because C.T. takes care of that problem and you can all "PuNt ThE LaMuHs OfFLiNe" now. There's also a custom string feature in C.T. because the strings I put in there kind of suck. And I'm sure that people will find a new string that does some other shit...So if people do, there's a custom string feature blah blah blah.

* The mailpunter actually punts people. Error them right offline in 2 seconds flat. (Provided they open the mail.) This only errors people on AOL4 and does absolutely nothing to people on other AOLs.

* The link sender is one of those that actually sends a link to the chat, instead of saying "(Keyword to: http://bounce.to/sky)". So spammers, THIS SHIT WOULD BE GREAT FOR YOU! Thank pyrex for help on this one, I couldn't have done it without him. ;)

* The [SN Converter] only works for AOL4.0 and you'll have to re-install your AOL if you try it on ANYTHING but AOL4!!!

__________
Known Bugs
����������

* I know that most people won't be able to load the [WordPad] because it uses CMDialgue.ocx. For some reason, my VB is fucked up or something. I don't know, whatever...

* The [Toser's] methods don't all work because AOL changed the kids keyword and they took the IMs section out of the Notify AOL Area.


___________
Contact Sky
�����������

* You can contact me through e-mail by sending mail to:
     sky_chronic@juno.com
  Or send an Instant Message to my AIM name:
     talk sky

* Visit Sky Online at:
     http://bounce.to/sky

_____
Links
�����
* Oxo's MegaSite
     http://bounce.to/Oxo
* Pyrex Inc
     http://zap.to/pyrex_inc
     http://www.pyrex-inc.com
* Redux Inc
     http://come.to/redux-inc
* WinAmp.com
     http://www.winamp.com	