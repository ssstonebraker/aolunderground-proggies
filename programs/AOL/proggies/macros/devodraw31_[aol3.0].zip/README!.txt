You have downloaded this file from the...

- Aurora Webpage -
http://members.xoom.com/TrueStyleZ

This program is a freeware and should be freely distributed.

-Br8k aka StyleZ