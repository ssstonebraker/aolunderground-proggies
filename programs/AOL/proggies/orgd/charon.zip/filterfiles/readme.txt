This folder contains several files which Charon can use to filter 
proxies out from your lists.

Each file can be changed / modified - and you can create as many 
new files as you like (for instance, if you want to temporarily 
filter out a certain range but not modify the old "bad.ini" 
permanently - this now provides the option.

I don't maintain the contents of these files as I feel that "bad" 
is subjective to the individual.  All I've provided here are some 
sample ones which can be tailored accordingly.

Rhino.