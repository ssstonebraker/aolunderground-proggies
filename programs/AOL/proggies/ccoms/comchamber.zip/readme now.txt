	First of all i'd like to say thanks...
Thanks for downloading COM CHAMBER - RELEASED BETA����
As a BETA tester i want you to try and use every commands on this ccom
if you find a error please report it to killcanada70@hotmail.com, i will
reply to u with a thank you message and soon you may hear about a new
version of com chamber, without the error and maybe 10 or 20 more coms.

	You should have downloaded this file from a0de.cjb.net or 
lenshell.com or freeprogz.com, if you havent then someone has posted 
this prog..i dont really care just as long as it says its by a0de.
If it doesnt please report that site to me, ill go check it out.

	Anyway this is how you use this ccom for all the first timers
and people who arent too farmilar with a0de's style of progging.....

-----------------------------------------------------------------------
Steps to begin COM CHAMBER usage.

1. Fully customize its advertising appearance. you can do this by:
	- typing tfont *and a few letters of a favorite font*
	- typing ascii *and a ascii u'd like to use*
	- typing acol *and a hex color, i've added blue red green*
	- typing afont *and a few letters of a font*
	- typing fcol *and a hex color, i've added blue red green*
2. Add a few custom commands. You do this by:
	- typing encoms
	- after typing encoms, type vccoms
	- add a couple of commands
	- if you'd like to have the command respond with the person you
	  select like...kill a0de, then in the short text box type
	  "kill"...in the long textbox type "muhahaha i have killed
	  w%"..you will get "muhahaha i have killed a0de" if you type
	  "kill a0de" in the room..see how easy?
3. Start up the auto xer.
	- com chambers auto xer is just like solar winds, so dont be 
	  scared to add alot of trigs or immuned people.
	- you can add triggers by typing "axadd *and a trigger*" in
	  the room.
	- after you add some annoying words. immune your buddies so you
	  cant auto ignore them...you do this by typing "imm *and part
          of their screen name*"
4. Have fun. 

-
--
---    -            
----  --		     Copyright� 2000 a0de INC.
---  ---                        http://a0de.cjb.net
--  ----                     killcanada70@hotmail.com
-    ---