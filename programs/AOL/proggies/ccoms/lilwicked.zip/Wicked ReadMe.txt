GTA's LiL' Wicked Comz



I made this help file to help explain the commands.
First, a little about the prog. This was made by me,
gta. It took about a good two weeks, but I was working
on and off with it so that's why it took so long. I will
probably add more features to this prog. If you have any
suggestions feel free to e-mail me at GTA84@yahoo.com, 
please don't send mail to my AOL account. I don't want 
it to get filled up. =/
Okay here's a list of the comz and what they do.
Remember there is NO trigger.

brb -  tell the room you will be right back

dir & path  -   this is used for the mp3 player. For the
path part set it for where you keep your mp3's like I 
would type dir C:\My Music

exit  -  exits the prog

hide   -   this hides the i-face

idle & reason  - use this for when you are gonna do 
something like eat lunch. ex) idle im eating

idleoff  - turns off the idler saying that you are back

imson  - use this to turn your instant messages on

imsoff  - use this to turn your instant messages off

kw & keyword  - this is for going to AOL keywords or web
sites ex) kw www.aol.com

lol   - tells them room you are laughing out loud

mp3s? - this will tell the chat how many mp3s you have
considering if you set your directory before

newmail  -  this brings up your new mail

oldmail  - this brings up your old mail

pause  - this pauses your mp3

play & song  - use this to play your mp3s, you only have
to type in part of the song name considering the fact
you set your directory..lol..ex) play say

pr & room  - use this to enter a private room 
ex) pr progs

sentmail  - this opens your sent mail

signoff  - use this to sign off AOL and exit the prog

startup  - typing this in will give you a message box 
asking you if you want to show the i-face when you start
up the prog

stop  - this stops your mp3 

unpause  - if you have a mp3 on pause this will unpause
the mp3

unx & s/n - type unx and part of a persons screen name
to stop ignoring them ex) unx blink

x & s/n -  type x and part of a persons screen name
to ignore them ex) x 182

well, thats about it..feel free to e-mail me with any
questions, comments, or suggestions
-gta