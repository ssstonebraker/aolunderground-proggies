thanx for d/l'ing my prog , it took over a week outta my life, so enjoy it.
this is my first ccom , i hope you like it , it was fun to make.however,the coms have a
tendency to backfire when 2 people have it open in the same chat,watch out for that,its cool if you like that sorta thing. once again , thanx for d/l'in this.
aol mail : kypnotik@aol.com

     -kypnotik