mp3 pimp v1 by caloric

Hey! Thanks for downloading my program.
I made this with help from d0pey - http://www.punknboards.com/d0pey

Alright, first off you have to put your handle(name, nickname, etc).
You can do that by typing .handle yourhandle
in an aol chat room.

Next, you have to pick a directory either do that by typing
.setdir c:\windows\yourmp3directory
or by clicking the Directory button on the interface
typing in the directory then hitting enter.

There's a few small MINOR bugs in this but other than that
it runs perfectly. 

Scroll down for update info

Hope you like it,
Caloric
Webmaster@phatprogz.zzn.com
http://phatprogz.cjb.net

*Update 1.9.2
Fixed the DirectoryExists code cause it would say it DOESNT exist
when it does and say the directory DOES exist when it doesnt.
Tried to fix the Volume bug. Don't think it worked. Its an error in
the .ocx I believe.
Fixed the Unload bug cause it wouldn't unload completely when you
exited it from the interface.
*Update 1.9.1
I added ChatSend for AOL 5.0
I made it write to the .ini file so you don't have to 
keep putting what AOL you're using ;]
I don't have AOL 5.0 so I can't test it
so I'm just gonna have people that have get the new one
tell me if it works for aol 5
If it doesnt next update it will be fixed.
I fixed a few bugs like the Interface option refresh list,
I forgot to put the refresh code in so it wasn't working ;x
I think I fixed the idle bot cuz if you pressed stop it still 
wouldn't stop, so hopefully I fixed that.
If you have any suggestions e-mail me at the e-mail address
I put above. Have fun kids...
-caloric
