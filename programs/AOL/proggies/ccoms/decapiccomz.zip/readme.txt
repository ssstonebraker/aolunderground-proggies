
Thanks for choosing Decapi Ccoms. I have picked you to become a beta 

tester. A beta tester is someone that tests a program,and sees if there 

is any bugs, mishaps, problems, missing files, and stuff like telling 

what could be better,and what could be changed. In this zip file i have 

included all the files that this program needs, if a window poppes up 

saying you need a file (ocx) or (dll) then e-mail me telling me the 

file name you need. Every time I update Decapi Ccomz, i will 

automaticlly send you the updated version. PLease report to me any 

problems or bugs with this so i can improve it

							Munky