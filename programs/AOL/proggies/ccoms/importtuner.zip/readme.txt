import tuner beta

if they're any bugs in this program is probably either your computer/you fucking it
up so dont go around saying this is crap just because you unapreciate punk ass is too
fucking stupid to know how to use it.
-keith