WinAdv - By James de Mattos (Swift)

*Where does it go when I click Minimize?
 It goes to the system tray, on the bottom-right part of your screen by default.

*What does It Do?
 Advertises Winamp 2, 3, and 5 to aol 7, 8, and 9.

*What's Next?
 Chat Scan, that's all i can really think of now.

*What Else Are you working on or have you made?
 SmartSurf; It's my litle browser I made. You can find it at Lenshell.com

Enjoy This Swift Production