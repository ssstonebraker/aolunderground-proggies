				x-coms

Hey!  Thanx for downloading my 3rd or 4th prog.  My previous progs:

Xpire's Nauti Toolz
Xpire's Idle Toolz
X Phade

Heh, if you do ever come accross these, please don't download them.

Well, this prog is a c-com/mp3 player.  I made it in VB5 and is usable
for all AOL's.

Instructions:

***FIRST THING, GO INTO A CHAT OR CLICK "HANDLE" AT THE BOTTOM AND 
SET YOUR HANDLE*** ex:(.handle blah)
You only have to do this once unless you want to change it.


1) Go into a chatroom or just click "dir" and set your mp3 directory.
   (ex: C:\WINDOWS\DESKTOP\WINAMP\Mp3s)

2) Restart the program.

3) Then you can play an mp3 by double-clicking it from the list or
   going into a chat and typing ".play title".

*E-mail me if you get any error messages or need a missing file.  I'll
post it at my site.*


I didn't have a lot of time to finish this prog so there are a few,
1 or 2, bugs.  I probably won't fix them but they will be if I 
release x-coms2.  I'll release an x-coms2 if i get a couple hundred
requests, lol.  Please download this prog from:

http://www.angelfire.com/wi2/xpirenwa

Please do NOT send this prog to other people.  If they want it, they 
can download it themselves from my site.  I want this only so I can
get more hits at my site.

That's it for now, if you have any questions, e-mail me here:

xpireownz@hotmail.com

See ya and thanx a lot!
							        xpire


Prog from me and gta coming soon! ;]