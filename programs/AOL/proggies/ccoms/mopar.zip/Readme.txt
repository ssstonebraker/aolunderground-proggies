____________________
MoPaRz Toolz ReadMe

Sup Peeps! Thanx for d/ling my Prog. Ok, First Off...
MoPaRz Toolz is designed for AOL95, but it still works
on AOL3.0 16bit. This Version (v1.2) of MoPaRz Toolz has
a major bug fixed and a few new goodies have been added. The new items are M-Chat, Mass IMer, Hide/Show AOL,
and a PWS & DELTREE Detector. Now if you scan my program
your scanner will show that my program has 1 string of
deltree, that is my Detector's Code. So Just ignore, yo-
ur scanner, unless u are really paraniod. I hope you 
enjoy this verion of MoPaRz Toolz as much as everyone
did with version 1.0. Anyway, If u have a bug to report,
etc. then U can reach me in PR 'FireToolz'.  

				Enjoy Peeps!
                                -= MoPaR =-
