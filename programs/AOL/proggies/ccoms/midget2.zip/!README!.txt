sups people. this is the first beta. as of now, the ascii transferring doesn't work  b/c
i haven't gotten around to fixin it yet. but everything else does work. for presets, color and ascii styles, you can double click on one in 
list to load it. almost everything has a form to view the stuff from. i finally hit my 275 command mark so this will be the last beta until i
can get the transfers working. anyway, if you have this you know how to contact me so tell me any bugs that might be in here 
although i haven't found any that i haven't fixed as of yet. thanks.

-sm0ke
aol- ilism0keili
aim - cia sm0ke, fbi sm0ke, aopirnpinq