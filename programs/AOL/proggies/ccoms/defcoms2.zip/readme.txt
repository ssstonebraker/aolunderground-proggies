sup!  thank you for using my newest ccom called def coms version two!
this is probably one of the better ccoms out right now, it is errorless
on my computer but may act differently on yours.  if there are many bugs 
on the ccoms please email me at dj_bles@hotmail.com.  these ccoms are 
adaptable for both aol 4 and 5. also, sometimes possibly a command can
be stuck in a loop, so just close def coms and reload it again and 
everything should be fine.  

some cool features:

custom commands
networking commands (winsock mail, port scans, ping, ip)
macro type e.g. big sup
screen name features (new, delete)
double rooms e.g. dbl life, ck

thanks again for using this program.

-bles 

email - dj_bles@hotmail.com aim - b1es