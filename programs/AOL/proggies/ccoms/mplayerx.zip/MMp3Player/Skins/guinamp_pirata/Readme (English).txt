                           __.__       ___/\____   ___  __/\__  
            __/\__  _/\__ \    \ __.__/         \ /   \/  ____\
           /      \/     \ |    \\    \   _     ||     \ /   ___
          /  /\      /\   \/    / \    \ |_\___/ |     | \__/   |
         |   \|     /     <    /__/    / _  _   <     /         \
         |    /_____|    /_\          /    \_|  |\    \\____..__\
         /__.___\ /________|/.__  __./\___  ____/ /_____\  __\/___  _____
                                \/        \/     \/      \/       \/___  \ 
                                          /  /\      /\   \  /\    \ _/ /
                                         <   \|     /     |  \/____/|_   \
                                         |    /_____|    /_\  \   .___|   \
                                         /__.___\ /________|___\  |___  __/
                                               .:smaller:but:work:.   \/ 
                                     

                       Music Mp3 Player X  - Version 2.0 
                      Copyright � 2004  by  Ra�l Mart�nez      
                                                        
 
                           [   E  N  G  L  I  S  H   ]
 
                       
	�*�*~`~*��*�*~`~*���*~`~[ sKINS ]~`~*���*~`~*���*�*~`~*��

	   The skins files should be located in a sub folder in:

	   [Path Configuration]\Skins\, where path configuration is 
	settings in options on application, the folder name is the name of 
	Skin.
       
	   ejemplo: 

	    AppConfig=C:\     
 
	     + AppConfig [folder]
	     +----------\Skins  [folder]
	     +----------------\NameSkin [folder]
	     +---------------------------\Skin files

	   The configuration file for skin: for example transparent color, 
	top, left and color settings is in [skin.ini] file.


 		          <<<  Skin files only .bmp  >>>

                	      <<< NORMAL MODE >>>
     
	� main             > Main image normal mode.
	� payer_buttons    > player Buttons.
	� options_buttons  > Intro, mute, repeat, randomize buttons.
	� albums_buttons   > Previous, Front, Next Album buttons.
	� titlebar_buttons > Menu, Minimize, MiniMode, Close.
	� albums_picture   > Album image playing.
	� posbar_slider    > Posbar slider.
	� volbar_slider    > Volumen bar slider.
	� Listbar_slider   > Play list slider.
	� song_font        > Font current song.
	� num_font         > Font current time.
	� songinfo_font    > Font Kbsp, Hz.



			      <<< MINI MODE >>>

	� minimode                  > Minimode image.
	� payer_minimode_buttons    > Player Buttons.
	� titlebar_minimode_buttons > Menu, Minimize, MiniMode, Close.
	� posbar_minimode_slider    > Pos bar slider.
	� volbar_minimode_slider    > Volumen bar slider.
	� song_minimode_font        > Font current song.
	� num_minimode_font         > Font current time.



	
                   <<  Archivos de cursores solo .cur  >>>

                	      <<< NORMAL MODE >>>
     
	� curmain    > Cursor Normal mode.
	� curbuttons > Cursor all buttons.
	� curalbums  > Cursor all albums.
	� curposbar  > Cursor progress bar.
	� curvolbar  > Cursor volumen bar.
	� curlistrep > Cursor list rep.
	� curlistbar > Cursor list rep bar.



			      <<< MINI MODE >>>

	� curminimode         > Cursor MiniMode.
	� curbuttons_minimode > Cursor all buttons.
	� curposbar_minimode  > Cursor progress bar.
	� curvolbar_minimode  > Cursor volume bar.


	   If you like more skins visit http://www.geocities.com/skoria_36
	or make your skins with Makeskins.exe download it from the web       
	site..
