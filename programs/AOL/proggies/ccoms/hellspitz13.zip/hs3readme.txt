hey , thanx for d/l'in another 1 of my progz.
this ccom needs the folowing files:
chatscan3.ocx
playcd2.ocx
mswinsck.ocx <--all can be found at lenshell.com
  |
   \
   /
   \
  any questions or comments?
e-mail me at: iammisled@aol.com

thanx

  -kypnotik