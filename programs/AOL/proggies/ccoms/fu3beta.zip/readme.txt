[Fu�beta][By:Hadox]


Sorry The coms should be types lower cased but i will fix that
in next beta or full version.

[Regular Coms]

time- Tells you current time
date- Tells you current date
gagger- Loads gaggger
mp3- Loads Mp3
macros- Loads Macros
scroller- Loads Scoller
ulgagger- unloads gagger
ulmp3-unload mp3
ulmacros- unloads macros
ulscroller- unloads scroller
idle- Loads idler
fu- Scrolls fu1-fu10
pr *- Takes to private room
bpr *- Takes to bann provate room
killwelc- Kills Welcome Screen
adv- Advertises Program
handle?- Scrolls your current handle
imon- Turns Ims on
Imoff- Turns Off
kw *- Goes tokey word
web *- Goes to website
min- Minimizes program
max- maximizes program
exit- exits program
[Mp3 Coms]

r- Random song
ref- Refresh music directory
next- next song
pvs- previous song
stop- stops song
pos- scrolls music position
vol *- sets volume
v?- Tells you current Volume

[Hadox's Info]

Email- Hadox79@yahoo.com
aim- Hadox60

[SHouts]

Shouts to ZiON crew and all the peoples that have helped me Thank you.
And thank you for using my program.

