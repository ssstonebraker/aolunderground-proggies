this is rebel coms beta, it only has 66 commands, but the real version
is ganna have well over 150, anyway when u first load the prog:

-type: cmds
then u can view the commdands

-a0de 
email:	a0de@netzero.net
site:	a0realms.cjb.net
  