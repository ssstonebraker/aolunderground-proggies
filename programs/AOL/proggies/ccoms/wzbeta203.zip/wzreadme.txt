thanks for d/l'n new wing zero!
for this new version, you will need to make a folder called "factors"
in wutever directory the wing zero prog is in.
then you will need to transfer all your factors to that folder ... thanks

                     -jago-