sup, this is my first mp3player so it doesnt have a 
whole lot of shit on it.  Well i hope you like it, if
you find anybugs, or have any problems with it just tell
me.
aol: i arn poboy@aol.com, ilpoil@aol.com
aim: intoxicated po
icq: 81072311