The Hunted v1.5 by: Xr4y

email = hunter829@aol.com   &   y4rx@aol.com
aol s/n = hunter829    &   y4rx

~ more options will be added on newer versions ~

  ~ got anything you want me to put on the next version email me and tell me ~

~im not too sure what else to add to the hunted. so send me some ideas/suggestions~