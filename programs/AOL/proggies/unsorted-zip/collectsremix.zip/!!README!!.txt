well here we are another version of C�llector S.
the first one i made for fun, and the second one also
but this i put some effort into it still isnt all flashy
which i dont see why a simple prog like that should be
anyways if you want the source code just contact me

~~~contact~~~
seven@ascendence.net

if your ever chatting on aol
stop by ogh (Online Games Help)
i will most likely be there