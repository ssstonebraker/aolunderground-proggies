***Extract ALL FILES (Except the Theme White file) into the SAME DIRECTORY. Then, if you want to change themes, Look down at "CUSTOMIZE"

SmartSurf 1.0 

By: Swift

E-Mail: XxNuclearxX@aol.com, Swift Generation@aol.com

Want to make Joint program? mail me. Sorry, no aol progs.

Customize:

This program is very customizable. change all the .Bps in the file to your liking to make it like you like it. The default theme is with the .exe file in  the smartsurf.zip. And extra theme named "White" is included. I made it in 5 mins. Simply drag and drop all files of the them to where the program is located, and enjoy... Don't forget to keep a backup of the original theme(s) in case you want them back.

Other:

Enjoy this Swift Production 