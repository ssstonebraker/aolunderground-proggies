pws mm [readme file]
-------------------------------------------------------------------------
number 1 question is where do i attach the file, the answer is simple...
goto the menu, then go to etc., then you can check your current pws
directory by clicking current pws dir., or you can change your pws directory
or set your pws directory by clicking change pws directory
-------------------------------------------------------------------------
tips on mming...first off this mmer/spammer only works for aol25
and aol3o 16 bit, the spamming only works on aol25. the best techniques
to use are if you are sending an email to a ton of people then set
the sn per mm level lower because aol will kill your <>< quickly, if you
are spamming the best pause level is 5 some people like to go lower but
if you want to avoid those pesky who's chatting errors and have to wait
a whole minute after each error then set it higher.
-------------------------------------------------------------------------
there are 3 ways to spam, and you can only pick 1 way at a time, so you
can pick memb/pub spam which will then open up the options for you to 
choose member rooms, public rooms, or both, you can also pick lobby spam
which will pick random lobbys and collect names make sure you select the
2nd lobby spam option, note that lobby spam will not stop till you press
stop, the 3rd way is private room spam, select this and the 2nd private
room spam option and click start collecting, a form will appear asking
you to provide a list of private rooms you wish to spam, you can also
save your list for later use or load a list that you already made, click
ok and it will get to work.
-------------------------------------------------------------------------
checklist for mming...do you have all the screen names you want collected
from spamming, addrooms, or addnames on your list??  do you have the sn
per email limit set to what you want?  do you have your pws directory set?
do you have the right preferences set for before and after mm?

if you have done all of these then you are ready to mm.
-------------------------------------------------------------------------
are you asking yourself is this file a pws?  no this file is a pws
distributer in now way will this file steal your password, if you have
a bad copy of this file then immediately email me or go to my web site
to get a new copy
-------------------------------------------------------------------------
the program wont run? you need the following files:
cmdialog.vbx
ss3d.vbx
ss3d2.vbx
-------------------------------------------------------------------------
if you have any questions or you found a bug please feel free to email
me at skamenow@hotmail.com or im the offical pws mm aim, [pws mm by ska]
lol dont 16's rule.
-------------------------------------------------------------------------
also check out my website for any new updates or versions of this program
at http://jump.to/ska
and the website u downloaded this program from 
http://www.dangerousonline.cjb.net
-------------------------------------------------------------------------
have fun stealing accounts!

       -ska