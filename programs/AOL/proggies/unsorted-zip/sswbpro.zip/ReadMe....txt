

                  |`'`'`'`'`'`'`'`'`'`'`'`'`'`'`''`|
                  |SWIFT'S SIMPLE WEB BROWSER (PRO)|
                  |.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,|




	I made this for all the little kiddies that have AOL, but also can't
go to websites. Here is some websites if you want dif stuff...

Progs:
www.lenshell.com.

VB Downloads/Get VB:
www.8op.com/vbzone/index

VB Help, ETC.:
www.knk4life.com

Warez Downloads:
www.sonixdownloads.com

Appz, Misc:
www.archangelz.com

=======================================================================
Okay, I now that anything can happen, so, if you find a way to get in 
trouble with this damn thing, I take no responsibilities, iight 
kitties...? Thanks. and thanks for DLing this 
=======================================================================

=========
ShoutOutz

HBK: Yo, you helped me alot, ude, but you might not know it.
DOS: You don't know me, but I learn from your bas n' shit. Thanks.
T  Dawg   2k: Are you starting to make help files? Anyways, that damn
fader was f*ckin' phat, post it somwhere...
Soph: Thanks for teaching me the difference betweenmakeing progs and
copying subs, etc. and all from bas. You taught me to learn from them.
And all the bros from SWIFT PRODUCTIONS I forgot. Peace.

It may have been a dream, Swift Productions. But it was one I was 
living in. And it is and will be the one I will try to establish again.
              

              -Swift