,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.
|          Smart Surf 2.0          |
'`'`'`'`'`'`'`'`'`'`'`'`'`'`'`'`'`'`

WARNING! I Take NO Responsibilities Whatsoever!
If This Application CURRUPTS Your Computer in ANY WAY,
I Can Not Be Held Responsible. So.... Enjoy!!!

READ THIS TO MAKE IT WORK!!!:

1. Extract all Files to a Folder (I Sugjest C:\SmartSurf)
2. Extract all Other ZIP Files Included Into a Directory Of Your Choice. I STRONGLY Sugjest You Move Them With The .EXE (Not DIRECTLY With it, But UNZIPED in a Folder)
3. Double-Click SmartSurf 2.0.exe

*NOTE* When You First Load up SmartSurf 2.0.exe, You Will Need to Select a Theme Directory. If You Select a Directory Without a Theme, The Application Will ERROR, But You can Start Over by Loading it Back up.

4. Select a Directory, Click OKAY, And Have Fun Surfing Smart!!!

=========
* About *
=========

SmartSurf 2.0
By: Swift

Perm. E-Mail...: XxNuclearxX@aol.com
AIM............: LeftArg
MSN............: SwiftGeneration

Want to make Joint Application? Mail me!



==============
* New in 2.0 *
==============

- BIG!!! Added new Theme Selector!!! now you can change through themes seemlesly without adding and removing the .BMP and sound files!

- Easier to access menu! Is not that helpful?

- Three New Sexy Themes!

- Changed the old Menu Button Into a Home Button.

- Now Intro art can be ANY size; The window resizes to fit it.

- Drive Explorer window can now be resized.

- Replaced some code which slowed the loading process of pages.

- Larger (Wider) buttons.

- Added OPEN option, and switched the SAVE option (On the Main Window) to the more reliable Common Dialog

- Added Readme window. Now you can view the Readme File In The Program. Note That you Need to Have The readme.txt File In The Same Directory As The .EXE file or it will not work.

- Secret Place now has a little... :: cough :: more to offer.

- TONS of Code Improvements!!!



=============
* Customize *
=============

This Program is Very Customizable...

Intro Art can be any size. 
The Intro Windows Resizes to it automaticly.

Button Dimensions: 25(H) x 80(W)
Being a Bit Off in Size Doesnt Matter; The Buttons Stay The Same Size All The Time...

WHAT EVER YOU DO, DO NOT MOVE ANY OF THE .TXT OR .INI FILES AWAY FROM THE .EXE FILE!




================
* What's Next? *
================

- I will TRY to improve the pop up blocker to stop IE from loading also.

- Other implementaions not known to the programmer at this time.



==================
* Buy the Source *
==================

Interested in Buying the FULL Source to this Appliation? E-Mail me at XxNuclearxX@aol.com or SwiftGeneration@aol.com with the subject as "BUY SMART SURF". I Don't Know what the Price would be; We will Discuss it. This source Code is nice and neat, but NOT commented... As each of the versions come out, the cost will rise.



=========
* Other *
=========

Took a lot of gut to ditch the menu bottun... I am taking sugjestions from ANYONE. 

Mail me... XxNuclearxX@aol.com

Enjoy this Swift Production 

File Last Edited: 8:26 PM 2/26/2003
