[QUicky Collect]

Collecter i made in about 30 mins.
i just made it for the hell of it.
hope u like.