	PROGRAM: CHAT-LiNK v3 
	
	RELEASED:  02/21/00 at 8:19pm

	AUTHOR:  CDBurn(01,02,03,04,05)
	
	E-MAIL:  CDBurn@socal.rr.com	

	USE:  AOL 4/5 link in chatroom sender
	
	INFO:  I wanted a link in chatroom sender that worked, didn't crash, had support for small and 
	       large intervals, and could send different links in an alternating sequence.  And since I 
	       couldn't find any program that could support even half of those, I made one.  
	
	HELP:  Make sure you turn it ON by pressing the "ON" button.  And the same with the "OFF" 	       	       button.  
	       
	       If you get the a message box from AOL that says, "Message to Complex" then 
	       you need to shorten your link text.  AOL only supports a certain amount of characters
	       sent to the chatroom at one time.  There may be a way aruond this, but I don't know it.
	       If you do, e-mail me.  
	       
	       Yes, the linker works as an idler if you omit the address in the address box. 

	       Any other bugs or help please send to my e-mail address.

	CREDIT:  All credit goes to myself, the VB chatroom, KNK and his site, and DOS for his 	         		 incredibly useful dos32.bas and chatscan3.ocx-available at www.knk2000.com/knk.

	ADDED:   A Workstation lock option has been included.  This disables all hot-keys and without
		 the password YOU CANNOT disable it.  Keep in mind that if your computer is restarted
		 it can still be accessed.  To remedy this, I have installed a program called Access 
		 Denied that password protects upon boot-up.  It is recommended that you turn on 
		 the shut-off monitor option in your screen saver setup for windows because your
		 screen saver will not load while the workstation is locked.  Either this or just
		 turn off your monitor.  If someone figures out how to get around this workstation 
		 lock, let me know.  I'd be interested in how you succeeded in doing this.

		 Auto-Logoff has also been added.  This feature is the most valuble to me since another
		 member of my family uses this account in the morning.  I can leave the linker on at 
		 night and it will stop linking and logoff at the desired time.  I have made sure that
		 this logoff feature will log you off even when you are downloading files or have
	         pending files.  The program will answer no to the question "Would you like to download 		 pending files?"  Also, AOL will log you off due to inactivity.  Therefore if you enable
		 Auto-Logoff but do not turn on the linker and you do not use any third party idle 
	         program, AOL will most likely log you off before Auto-Logoff has a chance! Make sure
		 you take this into account as well.

	FUTURE:  Open for suggestions...		

	FUTURE:  I've began a workstation lock option(and it works) but am wondering whether I should 		 	 seperate it from this linker and make it it's own file since it has nothing to do with 		 linking.  Let me know what you think about on this one.

		 I want to include an auto-off feature which will turn off the linker and sign-off the 
		 user.  Would be useful to me...

		 Anything else you want added, lemme know by e-mail.
