STiNG Password Stealer Detector (PWSD) - Version 3.0 - FINAL - Released June 18, 1999, 10:10 PM, Central Time

THIS WORKS WITH AOL 4.0 AND 5.0!!!

In case you people do not know how to use this...
I tried to make it as simple as possible, but you never know about some people.   =\


Anywayz, to start it, you click "Scan for PWs"
To Exit, Click "Exit"
The File: C:\ (or D:\) is your default HD.
The box below it are the folders on your HD
The box to the right of that, is a list of the files in that folder.
Highlight the files you want to scan, and start it.
Thanks.  I wanna give a shout out to Beav for that kick ass intro art!
Check out his page: http://www.lenshell.com

For Version 4.0, I will try to add a full folder PWS Scan, and a 
single file and a full folder scan for deltrees, too.
Check out our page: http://sting.iwarp.com

Lataz.

-ReWiND (Mito08708@aol.com)