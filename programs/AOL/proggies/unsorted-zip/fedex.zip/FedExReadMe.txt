     Whats Up?? Well you did it...you got yourself one of the best mail
punters out for aol 4.0, and this is only the first version.  Well,
there isn't much to this little prog...you just enter the name in
the combobox, fillout the mail subject, select your options, and 
pick a method from the menu.  Thats it, it doesn't get any simpler.

Please Note: Error Method #1 only works for those on Aol 4.0 Beta i 
think...im not sure.  Also if you punt someone that is not on aol 4.0
it will Not punt them i think, and they probably will forward your mail
to Aol's staff if they are lame and get you and your account in some 
trouble (it happened to me a few times so i know from experience)

					Have Fun & Keep it Free
						-Dr. J
_______________________________________________________________________
			Release Info:
=Prog Name: FedEx Mail Punt  
=Prog Version: No official version number (First release)
=Release Date: Febuary 8, 1999
=For Aol Version: 2.5   3.0  Aol 95  {4.0}
=Coded By: Dr. J
=Visual Basic Version:  Dos   3.0  {4.0}   5.0   6.0 (Yes, there is a 
  VB for Dos!!)
=PWS/ Virii / Trojan/ Deltree: No, Dr. J is all About Free, Clean Progs 
  but i scanned it with McAffee, Norton and Dr. Solomons too.  Also if 
  you recieve this from an unreliable source you should scan it too, 
  though you would be better off just mailing me for a copy.

	*** NOTICE ***      and        *** WARNING ***
*** This Prog Is To Be Used at Your Own Risk Due to the fact that this 
   is an AOL Tos Violation and This Prog was only created and coded for 
   demonstrational purposes as a demonstration of the use of  Visual 
   Basic Programming.***
______________________________________________________________________
		What to look for in version 2.o:

- Hopefully more methods and strings w/ Possible Added Support for 
   Aol 2.5, 3.0, Aol 95 and 4.5 beta(if i can get it) with mail punt 
   strings for each version
- More Mail Subjects
- Mail punt string tester/maker to make and test your own custom
   mail punt strings
- Option of sending Annonymous Mail Punts and Mail Bombs from atleast 
   5 different servers
- Faster Mail Bomber (Or just a mail bomber that works...cuz when i 
     first made one it didnt do shit for some reason)
- More fetures including a Mass Mail Punt Option, and an automatic 
   return reciept checker/online checker, a mail punt Unsender
- Mail Fader
- Mail Spammer
- And much, much more that i havent even though of yet

Also Look For a Possible FedEx MMer or Server
....Til Then......Enjoy!!!