Rampage Toolz 1.1
-=-=-=-=-=-=-=-=-=-=-=-=-
Thankyou for downloading Rampage Toolz.  I can't garuentee that this 
file is virus free unless you downloaded it from 
http://www.oogle.net/rampage/  You can go there for help, the latest
version or just info.

For anything about rampage toolz including help remember to goto 
http://www.oogle.net/rampage