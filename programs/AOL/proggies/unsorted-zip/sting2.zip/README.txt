STiNG Password Stealer Detector (PWSD)

In case you people do not know how to use this...
I tried to make it as simple as possible, but you never know about some people.   =\


Anywayz, to start it, you click "Get this Bitch Started"
To Exit, Click "Exit and be vulnerable"
The File: C:\ is your default HD.
The files below it are the files on your HD
The box to the right of that, is a list of the .exe's in that folder.
Highlight the .exe you want to scan, and start it.
Thanks.

-ReWiND (Mito08708@aol.com)
