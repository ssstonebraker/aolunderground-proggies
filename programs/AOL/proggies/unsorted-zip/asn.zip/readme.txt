1. Run TSS Engine. and control exe Without this, the ASN.exe will NOT work!

2. Run ASN.exe. Enjoy.