      [ Thank You for Downloading Mirage v1.o By: DaWicked ]



This is the setup file for Mirage v1.o By: DaWicked
It may freeze on very slow computers or on all if a lot of 
programs are being used at once while trying to open the 
Setup file. So please close all programs before trying to open this.

also...
if the mass mailer or server do not work they say something like
"error" then do not try to open the server or mass mailer from
the start menu, find where you put the file on your hard drive
then go into the folder mmer or server and click on it from there
if that doesn't work then mail me at:
DaWicked@hotmail.com


