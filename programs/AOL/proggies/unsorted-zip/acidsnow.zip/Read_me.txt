O�`�l[A��d S��w]

O�`�l[By:Kn�ckl�s]

Started: 9/20/2000
Released: 10/31/2000
Released to pubic: 1/25/2002


Wow you have my first aol prog! It's for aol 4.0, and 5.0 Ok the reason why I didnt release this till now was because when i was working on this (aol5.0) i got kicked off for telling kids i was a chatroom host LOL. Anywayz then i started making aim progz and made my 1st one (Public Enemy 1.o) When aol6 came out, My dad end up getting aol again and finished this and I was embarresed cause this prog sucked so I held it off but now I decided to release it.


Cya and Enjoy
Knuckles