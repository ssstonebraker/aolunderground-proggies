Thank you for downloading Scandus Toolz by Colin/GameScan.
If you didn't get this program from scandus2002.com or download.com then I can't gurantee this is virus free. If you seem to be missing files from your computer to run this program download the Visual Basic Runtime files from the Scandus User System. The files you are missing should be included in that.

The OCX files that are in the zip file that you downloaded are required files.