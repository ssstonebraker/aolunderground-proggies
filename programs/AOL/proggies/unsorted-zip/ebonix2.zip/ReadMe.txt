ebonix scrizambla 2.0 by sir:

IMPORTANT!!!!!: 
THIS SCRAMBLER WILL ONLY WORK ON AOL 3.0 FOR WINDOWS OR AOL 2.5 TO SEE WHAT VERSION YOU ARE CURRENTLY RUNNING GO UP TO THE HELP MENU UP BY SIGN OFF THEN GO DOWN TO ABOUT AMERICA ONLINE AND CLICK THAT... IT WILL BRING UP A SCREEN, IF THAT SCREEN SAYS AOL 3.0 FOR WINDOWS OR AOL 2.5 OR AOL 2.51 THEN THIS SCRAMBLER WILL WORK 100%, HOWEVER IF IT SAYS AOL 3.0 FOR WINDOWS 95 OR AOL 4 THEN YOU CANNOT USE THIS SCRAMBLER PROGRAM.


INFO:

i believe this is the "good" scrambler players scrambler. it is one or two winners only..... and it is made so that if you are fast enough and the host has it on two winners, then you may win 2 times.  it has auto logs as well as chat commands such as
/hint - to scroll the scramble word letter by letter
/rescroll - to rescroll the scrambled word
/host on - to allow the host to compete in the room without cheating
/host off - to turn off the host-n-play feature
as well as others

i love this scrambler and would like to have all the good hosts use it so feel free to pass it around or put it on web pages. 

this program was made in visual basic 3 professional version and took about a month, look for possible future versions depending on the success of this program..... 

this program if uploaded by me is 100% virus free from all types of harmful virii.... i have 3 virus protection programs on my computer and 2 of them are updated monthly.

THANK YOU AND VISIT
http://welcome.to/sirware for future projects by me :)

Thanks, 
SiR
