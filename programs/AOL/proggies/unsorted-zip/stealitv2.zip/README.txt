+-------------------------------------+
|                                                     
|Steal it v2 was made by speel and        
|iam not to blame if you ge in trouble 
|aight so go steal some ips           
|-speel                               
|http://speel3k.net  
on irc : blogchat.sytes.net port 6667                 
|put mswinsck.ocx in your system32 folder                              
+-------------------------------------+

