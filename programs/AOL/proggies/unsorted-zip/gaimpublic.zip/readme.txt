hey stupid!
when you open this program click ??
AND READ THE ENTIRE WINDOW THAT COMES UP
