JudgeMent Day- By: Nautica

These files must be unzipped to the folder c:\unzipped for any of 
the WAV files to play!

So After your done with the unzipping the final folder for this prog
should be- c:\unzipped\judgementday\
Very Easy!

If you do not want these Wav Files to play all you simply have to do
is remove them from the folder c:\unzipped\judgementday\

Then you may move the folder to any directory you wish, but dont count
on ever hearing any Wav's unless they are in c:\unzipped\judgementday\

Also never rename the wav files or they also will not play!

This Zip file is so big because i included all the dll and runtime 
files you need to run this prog, also the Wav files take up a good 
amount of space!  

Well anyway I hope you enjoy this prog and again this is for 
educational purposes only and neither I or AOL are responsible for
what you or anyone else does with this prog!

ENJOY!!!!!