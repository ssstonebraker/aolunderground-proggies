This is for yourself to be enabled to Recover a faulty temporary file
I've put 2 sets, one in .html format (it has the icon of your browser)
and one in notepad as for a secondary backup, incase you don't know how to
or where to get the initial temp index script.

-xyr0x