Filesafe Professional 9
Coded in C by Stealth

http://members.xoom.com/Spytech98
steaith@msn.com


Installation:


-if you have used a previous version of Filesafe Professional:
Delete the x:\fsprof\ folder, x:\ being your drive
Extract FSINSTALL.DAT to your root drive/folder (ex.: c:\)
Run FSSETUP.EXE

-if you have not used a previous version of Filesafe Professional:
Extract FSINSTALL.DAT to your root drive/folder (ex.: c:\)
Run FSSETUP.EXE