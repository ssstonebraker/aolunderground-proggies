						6-19-98
sup peeps,
this is the second edition. there are hella lot more chat commands then anything around. next version might have more.  this version features toser and ignore.  take the time to go through all the commands and familiarize yourself with eveything!
						-police