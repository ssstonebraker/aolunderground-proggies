Thanks for downloading Destruction FINAL BETA 2.0!

For the ending sound to play. Place it into a folder in this
directory..

C:\Program Files\Destruction (Put the file in that folder)

(The Download may have been long, I know it lacks options. But its
a good I-face Etc. Just use it to its advantages! Later!
~ImMOrTaL

Any questions Or comments E-mail me at XxImMOrTaLxX@hotmail.com
Or E-mail beav at BeaV@lenshell.com (If he don't respond e-mail me)