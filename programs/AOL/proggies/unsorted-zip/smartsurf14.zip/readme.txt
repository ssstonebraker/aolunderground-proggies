*** Extract ALL FILES (Except the Theme Files) into the SAME DIRECTORY. *** Then, if you want to change Themes, Look down at "CUSTOMIZE"

*** SmartSurf 1.4

*** By: Swift

*** E-Mail: XxNuclearxX@aol.com, Swift Generation@aol.com

*** Want to make Joint Application? Mail me. Sorry, no AOL Progs.

==============
*** New in 1.4:

*** MP3 Player added.
*** Browser Text Size Options
*** Secret Place added.
*** Print Capabilities added.
*** New Menu Layout
*** "Find Text On Page" added.
*** Page Properties added.
*** Page Save Capabilities added.
*** Changed www. in text boxes to http:// (For Websites that Don't Have WWW in Them.)
*** New theme, Grey!
*** Edited About form a bit
*** Fixed some minor bugs not even mentioning here.

==============
*** Buy the Source:

*** Interested in Buying the FULL Source to this Appliation? E-Mail me *** at XxNuclearxX@aol.com or SwiftGeneration@aol.com with the subject *** as "BUY SMART SURF". I Don't Know what the Price would be; We will *** Discuss it. This source Code is nice and neat, but NOT commented..

==============
*** Customize:

*** This Program is Very Customizable. Change all the .BMPs in the File *** Directory to Your Liking. The Default Theme is Included with the *** .EXE File in the SmartSurf.zip, As with the NEEDED text files. To *** Switch Themes, Simply Drag and Drop all Files of the Theme to Where *** the Program is Located, and Enjoy... Don't forget to keep a Backup *** of the original theme(s) in case you want them back.
==============

*** Other:

*** Enjoy this Swift Production 