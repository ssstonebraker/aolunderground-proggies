IPJH (Internet protocol High Jacker)

by aShcan


Copy the text in the box that says "http://xxx.xx.xx" (the x's stand for your IP) into a Link box and make the text whatever you like. If it doesnt work it is because the person could be on a newer version of AIM or on Linux or Macintosh. 

[url] http://www.chaotic-code.com
[AIM] sjg311i s ts
[mail] cheesegalaxy@yahoo.com

-aShcan have fun
