
_________________
Ascii Helper ���

Sup! I made this program because, i was tired of using 
Windows' Character Map to make Ascii. So, I made this so
that it would be easy to make Ascii for progs, etc.
I hope you like this program! 

				L8ter
			     -= MoPaR =-
