bodini .02 SPECIAL FIX
by: spek

	Due to the NUMBER OF MASSIVE BUGS IN BODINI .02, and other bad
things i did, i decided to reupload a fix since I will not release a
version .03 for a while sinc ei want to fix all the bugs out of the
prog. The mass mailer and server should be done. Look for my special
secret area. If you find it, tell me what it is, and where you found
it. Report any bugs to the address below. peace...
								-spek


itsspek@hotmail.com
http://www.xclipticonline.com/spek