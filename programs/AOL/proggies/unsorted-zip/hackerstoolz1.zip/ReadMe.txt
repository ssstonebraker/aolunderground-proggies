	To User:

	Let me just say, this prog is an Aol7 and Aol8 Prog. All the options are for Aol7, the Aol8 features can be 
	found under the MAIN menu. I know there isn't alot of Aol8 stuff, but this is the FIRST Aol8 prog EVER. 
	There aren't tons of .bas files for Aol8.0 like Aol6.0 for someone to throw a prog together. I had to use a
	 API Spy by Oogle to find the all the API calls myself. Let me say, all of you guys haven't seen the last
	of me. I am planning on another prog just with 8.0 stuff. Let me guess, you thought the first 8.0 prog would
	come from Dreeg as a Methodus4? Nope, you probably never heard of me but im a excellent programmer
	and was a little late on the ao-scene. Visit my site for all the VB examples you need, and if you want the
	source to Hacker's Toolz 1.0, its FREE. Visit my site and email me. See you soon.

	From: Jordan

	        ;;                              ;;                          
	        ;;                              ;;                          
	        ;;                              ;;                          
	        ;;    ;;;;;;;;    ;;;;    ;;;;;;;;    ;;;;;;    ;;;;;;;;;;  
	        ;;  ;;;;    ;;;;  ;;    ;;      ;;          ;;  ;;;;    ;;;;
	  ;;    ;;  ;;;;    ;;;;  ;;    ;;      ;;    ;;;;;;;;  ;;;;    ;;;;
	  ;;    ;;  ;;;;    ;;;;  ;;    ;;      ;;  ;;      ;;  ;;;;    ;;;;
	    ;;;;      ;;;;;;;;    ;;      ;;;;;;;;    ;;;;;;;;  ;;;;    ;;;;
	
	www.geocities.com/jordansvb  -  hippiekiller@sad.net