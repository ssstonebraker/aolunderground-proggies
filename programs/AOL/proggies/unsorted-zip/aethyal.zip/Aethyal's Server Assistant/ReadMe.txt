^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
        �thyal Server Tools v1.o
                  -
        For America Online v 8.0

^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

INTRODUCTION:

  I,  �thyal,  created this server assistant  because I was  tired of only finding programs
  that would only  do one or  a few of the  jobs that I needed it to do.  Also,  I couldn't
  seem to  find  anything  that would work with  AOL 8.0.   My ideas  only stem  from other
  programs that  I  have seen,  so there's really nothing new here.  The difference here is
  that I have compiled a few usefull programs into one better (IMHO) program.

  Everything that I have left out are things  that can be easily be done manually or by AOL
  itself.  Please keep in mind that I made this program only for myself,  but have recently
  decided to spread it around hoping that it will help alot of people.  There are no stupid
  advertisings  that will be  automatically sent to the room  (just one that is a choice in
  the Room Buster).
  


^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
WHAT'S IT DO?:

 1. Server Assistant
    1a. How To Use It

 2. Flash / Download Assistant
    2a. How To Use It

 3. Room Bust Assistant
    3a. How To Use It

NOTE: AOL must be open and visible to use these functions
NOTE: A "Servers" subfolder is needed for this program, please do not delete it


^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
1.  SERVER ASSISTANT

    * Automatically stores your list of server names
    * Automatically stores your list of items to request based on the selected server name
    * Automatically stores your list of finds to request
    * Sends requests at 2 seconds apart (to make sure they are picked up)

1a. HOW TO USE IT

    * Store a server name, item, or find by entering in the name and hitting ENTER or
      clicking the "+" button.
    * Double-Clicking on a server name will request your status from that server
    * Double-Clicking on an item or find will request it from the selected server name

    * The Servers Menu can: request a list, request your status, request all items, or
      request all finds, remove a server or remove all servers.

    * The Items Menu can: request an item, request all items, remove an item, remove all items.

    * The Finds Menu can: request a find, request all finds, remove an find, remove all finds.
    


^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
2.  FLASH / DOWNLOAD ASSISTANT

    * Sends selected mail to the Download Manager
    * Gets mail from either your New Mail box or your Incoming/Saved Mail box
    * Select mails by "All", "Index (x-y)", "String", or "None (Unselect All)"
    * Displays percentage complete
    
    * Keep Mail As New feature (New Mail box only)
    * Auto Start Download feature upon completion
    
    * Frozen Download Recovery feature
    * Auto On feature for Download Recovery
    
    * Auto Flash Mails feature
    * Falsh mails by count (300, 500, 800)
    NOTE: You can not be downloading while using this feature.  This option will be added if I 
          need it (like I said, I made this for me).
          
2a. HOW TO USE IT
    
    Pretty basic here: select your options (Auto Start DL, Keep Mail as New, etc.), load your 
    mail, select your mails, and click start.  This, very simply, sends selected mail to your
    Download Manager.  Everything else I feel is self explanitory.
    
    The Frozen Download Recovery feature checks your Download Manager every minute to see if
    the item currently being downloaded is changing percentage.  If not it will be restarted.

    The Auto Flash feature will check your mail count every 30 seconds and if it's equal to 
    or greater than your selection (300, 500, or 800) Auto AOL will be ran sending your mail
    to the Incoming/Saved Mail box.
    
    
    
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
3.  ROOM BUST ASSISTANT
    
    * Automatically stores your list of rooms
    * CHOOSE to advertise on entrance
    * Option to switch to the Server Assistant on entrance
    
3a. HOW TO USE IT

    * The Bust Menu can: bust a room, remove a room, or remove all rooms
    * Double-Clicking a room will begin busting that room
    * Need I say more?