ok,
you must set up ALL of your options before you bait,which
is pretty easy. If your baiting winsock you must go to file->winsock window
then put it your aols to connect to then click on "connect aols".
Now your ready to bait.Just hit start and sit back.
p.s. this works great for me like 100% so i dont want to hear
complaints it was made for me and me only but here ya go.
-txt