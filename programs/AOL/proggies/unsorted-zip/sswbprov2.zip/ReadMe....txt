

                  |`'`'`'`'`'`'`'`'`'`'`'`'`'`'`'`'`'`'|
                  |SWIFT'S SIMPLE WEB BROWSER (PRO) V.2|
                  |.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,.,|




	I made this for all the bastards that have AOL, but also can't
go to websites. Here is some websites if you want dif stuff...

Progs:
www.lenshell.com.

VB Downloads/Get VB:
www.8op.com/vbzone/index

VB Help, ETC.:
www.knk4life.com

Warez Downloads:
www.sonixdownloads.com

Appz, Misc:
www.archangelz.com

=======================================================================
Okay, I know that anything can happen, so, if you find a way to get in 
trouble with this damn thing, I take no responsibilities, iight ...? 
Thanks. and thanks for DLing this program....
=======================================================================

=========
ShoutOutz

Beav: Yo, keep that site up, iight?
Canzas: Also a phat site, you helped alot in this.
All the dope ghetto progas in pr VB: Thanks for calling me a newbie dumbass so I 
could WANT to program, not dream about it.
And all the niquas that downloaded this shit: Y'all are dope, I hope you like it.
 
Peace, and thanks again for Downloading this.              

              -Swift