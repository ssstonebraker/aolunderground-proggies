Sup i was board and had a idea cause i am sick of losing in chatfeds so i made this little proggie.
All you half to do is press the move/etc... you want and it will say it in the chat
immitedley so good luck heh.

-Kliq