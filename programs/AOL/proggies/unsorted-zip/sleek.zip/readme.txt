the LEFT side of the program is the mover bar.
click and hold it to move a program around

the right side of the program is the menu.
click it tobring up the menu.

Yes, The secret place works. The password must
be put in the text box.. THEN click Secret Place.
if it's wrong, nothing will happen. If it's right,
you get to see a photo of the author of this program (me)

1. Run TSS Engine.exe and control.exe   If you don't, SS.exe WON'T WORK!

2. Run SS.exe