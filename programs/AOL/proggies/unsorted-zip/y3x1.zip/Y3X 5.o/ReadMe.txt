		Y3X 5.o by freeq  FYI's
		 UPDATED DEC. 31 1999
		**THIS IS THE FINAL UPDATE**

Updates:

Mass Mailer
Room Buster
Punter
Room Destroyer - Now you can actually stop it..heh heh
(you can always hit escape for stuff like that)
Added some more room annoying things ;)
Chat stuff

If there are any other bugs..e-mail me so I can update
it once again!

1) Y3X 5.o uses "Small Fonts" so if you don't have them
just cut and paste the smalle.fon file I provided into
your c:/windows/fonts directory

Also required to run this prog:
	Apiguide.dll
	Vbwfind.dll
	Vbrun300.dll
	Cmdialog.vbx
	dbpush.vbx
all these usually go in your windows/system folder

2) This prog is for AOL 5.0 Revision 156.45 (32-Bit)
however, some features like room buster and punter 
and other stuff that use IM's might work for AOL 4.0.

3) Send comments to freeq@angelfire.com

4) Feel free to distribute this prog.

5) This prog was made using VB3 16-Bit..I got tired of
making VB5 progs + I lost my VB5 ..I wanted to try 
something different even though VB5 progging is better.


Other stuff:

Punter - It uses Buddy Im's so make sure it can find the 
Buddy List window!!

Server - Make sure you highlight the room window before
clicking start or else it won't send to the chat room.