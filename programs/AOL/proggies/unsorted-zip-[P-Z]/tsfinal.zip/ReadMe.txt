The siege final
 
1.) click File | Settings
2.) type secrete the click save
3.) the password is plEasE unLOck