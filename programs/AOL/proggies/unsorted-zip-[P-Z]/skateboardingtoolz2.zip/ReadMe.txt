***********************************************************************
          I thank all beta testers for their cooperation!!!
      To view the beta testers, please look at betatesters.txt
***********************************************************************
Disclaimer:
Im not responsible if you get traced, in trouble, etc....!...
***********************************************************************
                    Notez To Newbiez:
If this is your first prog ever, you chose a good one ;) Most newbiez
start out with Methodus Toolz......which is lame these days. If they
made a methodus 3, it would probaly be very popular. You can mess 
around with this alittle, do some things, whatever. Have fun with this
if it is your first prog -=]
***********************************************************************
                    Thingz That Dont Work:
The only thing that doesnt work is the chat lagger...which is lame any-
way...oh yeah...the color flashers...
***********************************************************************
                        Problems:
The following are the problems i found:
1. Under chat, dont goto Macros, instead, goto bots. Because macros wont 
work.
2. Under chat, dont goto upchat, instead, goto AOL or MAIL, then upchat
Or it wont work.
***********************************************************************
                        Hidden Area?:
Yeah, its kinda hard to get the password. To goto the place to enter
the password, click on File, then Hidden Area -=]
***********************************************************************
                         OH CRAP!!!:
I just realized i didnt post my final news! So here it is:

2-19-01: Well i figured out that there can be red text, i just had to
switch to pallets -=] VB6=my best friend! Well 2.o is done, and im bout
to realease it. Can you believe i made this whole thing in only 3 days?
I cant. Not to mention i worked for 7 hours straight on it and totally
ruined my weekend...but it was worth it. I hope you enjoy this prog
-=]
***********************************************************************
                     Hidden Area & Iz It Me:
In the hidden area, nothing happens if you get the password wrong. Not
even a message box that says you got it wrong. The same goes with iz it
me -=]
***********************************************************************
                        Lame Options:
NOT REALLY...!...except for iz it me!
***********************************************************************
                        BETA Problems:
1. The iz it me/hidden area situation (which is still there)
2. Color Flashers didnt work (they still dont)
3. It wasnt Always On Top
4. If you goto chat, then useless crap, it will scroll your macro is
crap, which i forgot to fix.
5. THERE IS NO 5!!!
***********************************************************************
                      How this beats 1.0:
1. In 1.0, most options didnt work.
2. In 1.0, You can resize the iface and stuff.
3. In 1.0, it aint always on top.
4. In 1.0, The chatsends are ugly.
5. In 1.0, I didnt know "Call Pause" so your most likely to get
scrolled off.
6. In 1.0, there's the average menu!
7. In 1.0, There is no hidden area!
8. In 1.0, The iface aint as good (sorry hydro).
9. In 1.0, Nothing worked for AOL6.
10. 1.0 JUST SUCKS OK???????????????????????????????????????
***********************************************************************
                           6.0 Stuff:
Probaly not all the options work for AOL6, but most of them will. If
you have AOL5 or AOL4 loaded, you will experience the whole prog.
***********************************************************************
                        Any Bugs/Virii/etc.?:
NOT IF YOU DOWNLOADED IT FROM SKATEYSPROGZ.COM!
***********************************************************************
                           Conclusion:
Thanks for downloading. I hope you like this prog -=] I know it aint
the best prog out, but to me it is. Its my second full-prog. Im 
planning on also making a Skateboarding Toolz 3.o, so keep checking
for updates at www.skateysprogz.com
-Skatey
http://www.skateysprogz.com
Oo Skatey oO@aol.com
Skatey@SkateysProgz.com
AIM: NeoSk8er012
Skateboarding Toolz 2.o Started Feb, 2001, and ended Feb, 2001.
�2001
***********************************************************************
