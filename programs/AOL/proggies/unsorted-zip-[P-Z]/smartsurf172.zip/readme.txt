*** DO THIS FIRST!!!

*** Extract ALL FILES into the SAME DIRECTORY. 
*** Then, if you want to change Themes, Look down at "CUSTOMIZE"

*** IMPORTANT: A Default Theme is Included With The SmartSurf.EXE
*** It is VERY basic and has ONLY neceseties. I Suggest you Switch 
*** It with a Different Theme, Right Away.

*** NOTICE! THE SMARTSURF.EXE FILE IS IN THE SMARTSURF.ZIP!

*** WARNING! I Take NO Responsibilities Whatsoever!
*** If This Application CURRUPTS Your Computer in ANY WAY,
*** I Can Not Be Held Responsible. So.... Enjoy!!!

==============

*** About:

*** SmartSurf 1.72

*** By: James Thomas Jos� Demattos A.K.A. "Swift"

*** E-Mail: XxNuclearxX@aol.com, SwiftGeneration@aol.com

*** Want to make Joint Application? Mail me. Sorry, no AOL Progs.


==============

*** New in 1.72:

*** Intro Music now Can Be .MP3 or .WAV Files!
*** MP3 Player New Layout.
*** MP3 Player Bugs Fixed.
*** Resized Notepad; Better Fit.
*** Resized Drive Explorer; Better Fit.
*** Added Drive Selector for Drive Explorer.
*** New Theme, "The Trip".
*** New Theme, "Thug".
*** Old Default Theme Named "Red Phaze".
*** Added Calculator.
*** Added Doodle Widnow.
*** Removed Lots Of Uneeded Timers To Reduce Load Time.
*** New Favorite Places Window Layout. Nothing Much Different, Just Looks better
*** Renamed All of Menu Names to Avoid Confusion With Programmer.
*** Recolored Links Inormation Frame; Looks better with Diferent Themes.
*** Forecolor Selector (For Those Who Fool Around With Themes...) Take a look at "Customize".

==============

*** Buy the Source:

*** Interested in Buying the FULL Source to this Appliation? E-Mail me 
*** at XxNuclearxX@aol.com or SwiftGeneration@aol.com with the subject 
*** as "BUY SMART SURF". I Don't Know what the Price would be; We will 
*** Discuss it. This source Code is nice and neat, but NOT commented..


==============

*** Customize:

*** Intro Art Dimensions: 487 x 175
*** Being a Bit Off in Size Doesnt Matter; The Intro Image Stays The Same Size All The Time...

*** Button Dimensions: 24 x 76
*** Being a Bit Off in Size Doesnt Matter; The Buttons Stay The Same Size All The Time...

*** This Program is Very Customizable.... 
*** 1.) Change all the .BMPs in the File Directory to Your Liking. 
*** The Default Theme is Included with the .EXE File in the SmartSurf.zip, As with the NEEDED 
*** Text files. 
*** To Switch Themes, Simply Drag and Drop all Files of the Theme to Where the Program is.
*** Located, and Enjoy... Don't forget to keep a Backup of the original theme(s) in case you want *** them back. This is VERY important to remember... 

*** Change FORECOLOR in All Labels:
*** Change ForeC.TXT to One of The following Propertys.

*** 1 = White
*** 2 = Black
*** 3 = Grey

*** There are NO OTHER COLORS.
*** If the Property is Changed to a Different Numer, the Application *** will resort back to it's Default Colors, as in SmartSurf 1.4 (Which *** is Light-Grey and White)

*** Next Version Might Have More Color Options...

==============

*** Other:

*** Enjoy this Swift Production 

*** File Last Edited: 10:19 Est. AM 12/3/02
