                       The Hunted v1.0    

this prog was made by me Xr4y

doesnt have many options..cause my friend wanted it...so i will make another version of this prog.
if u have any suggestions / want me to add anything to this prog on the next version email me or im me


email = hunter829@aol.com or/&\ y4rx@aol.com      

im = y4rx & hunter829