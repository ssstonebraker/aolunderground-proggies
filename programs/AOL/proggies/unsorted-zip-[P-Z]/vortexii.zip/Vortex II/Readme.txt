Table of Contents


Intro

0.1 - Vortex II ?
0.2 - What happened to Vortex I ?
0.3 - What's so much better about Vortex II ?
0.4 - 1 winner only !?!?!??!?!

Part 1 - Basic hosting

1.1 - What do I do?!
1.2 - What's a log?
1.3 - Running logs
1.4 - What topic?!
1.5 - Scores

Part 2 - ADVANCED hosting

2.1 - Good habits
2.2 - Better logs
2.3 - Creating logs
2.4 - Game options?
2.5 - Remote hosting

Part 3 - Other stuff?

3.1 - 1v1 game
3.2 - Time trial
3.3 - Submit button?
3.4 - Partners
3.5 - Update?

Part 4 - Troubleshooting (aka "HELP IT DOESN'T WORK")

4.1 - The program won't open
4.2 - I got an illegal operation
4.3 - It won't send things to the chatroom
4.4 - I don't see any logs when I click load log
4.5 - It crashes when I use logs I made with other programs/made myself

Part 5 - Special thanks

5.1 - Name
5.2 - Ascii
5.3 - Icon
5.4 - Background
5.5 - Suggestions
5.6 - Testing help
5.7 - Support

Part 6 - Future features / bug fixes

6.1 - Feature suggestions
6.2 - I found a bug! What do I do?


---------------------------------------------------------------------


Intro

0.1 - Vortex II ?

I chose Vortex II as the name for this scrambler mainly because I couldn't think of a different name, but also because it's a step up from the first program.  In making this program, I wanted it to have the same basic features as the first one, but improve upon the stability of the program and get rid of some of the bugs.  I also wanted to add a couple of new things in.  I think that I've accomplished what I set out to do, and hope that you feel that way too.

0.2 - What happened to Vortex I ?

I'm not sure, really. As was pointed out to me by Damian (Iaissez faire), it seemed to be losing functionality.  For some reason, features that had worked in the past were starting to error, and the program just wasn't working as well as it should have.  Whatever the reason, there were problems that I didn't feel I could fix by altering the program as it was.  That's why I decided to make a new program from scratch.

0.3 - What's so much better about Vortex II ?

Well, HOPEFULLY, Vortex II will almost never crash on you.  It hasn't happened to me yet throughout my testing.  That's a major improvement.  I'm also confident that it won't skip, ever.  Accuracy is the most important thing in a scrambler.  There's a log maker this time around, to make it very simple for anybody to create their own log.  I wanted to make this program as easy to use as possible, and I think I did a pretty good job.  I've also added several new features; some are pretty interesting.  Finally, there's no option for 2 or 3 winners this time around, so all games with it will be 1 winner only.  

0.4 - 1 winner only !?!?!??!?!

Yes, 1 winner only.  Why did I choose not to include the option to play with 2 or 3 winners?  There were several reasons.  First off, if you're any good at playing scrambler, then you almost surely hate 2 or 3 winner games.  Why?  Because they let people who are much slower than you end up tying you.  A really fast player might win every point in under 2 seconds, and then 2 other players get their points in about 8 seconds.  At the end of the game, these three players are all tied.  Is that fair?  No.  That's what I feel is the main reason multiple winners are bad.  Also, they tend to slow up the game.  Each point potentially takes much longer when 3 people have to answer it instead of 1.  Scrambler games are more fun when they're faster paced, so again, multiple winners is no good.  You might say that it's not fair to the slower players to have 1 winner only.  But I say that 3 winners isn't fair to the fast players.  Since the fast players are the ones who tend to play the game more often and are really into it, I'd rather be unfair to the slower players than the fast ones.  If somebody is too slow to play a 1 winner game without complaining, then maybe they're too slow to play scrambler.  The point of the game is to type as fast as possible, and 3 winner games just don't promote this.  If you're a slow player, instead of whining and asking the host to make the game 3 winners, why don't you try to type faster.  You won't get any better by playing a simple 3 winner game where you easily get 3rd every time.  You might say "but everybody asks for 3 winner games".. and that's true, a lot of people do want the game to be 3 winners.. but I think that's because it's all they've played, and feel that it's all they have a chance of winning at.  If you challenge yourself, you might be surprised by how quickly you improve.  You might soon be able to win at 1 winner only games.  If you keep playing 3 winners, though, there's not much of an incentive to get faster.  I really don't know what else I can say about this.. if you're still not convinced that having 1 winner only is a bad idea, then go download a different program.

---------------------------------------------------------------------------------------------------------------------------------------------

Part 1 - Basic hosting

1.1 - What do I do?!

It's pretty simple, really.  First of all, you've got to make sure you're in a chatroom.  Then, you type a word or phrase to be scrambled into the top box, and a topic into the bottom box, and hit enter.  The program will send your word, scrambled, to the chatroom.  Once one of the players gets the correct answer, the program will let the chat know, then it will clear the box on top so that you can type in a new word.  This is really all you need to know to host, but you'll do a crappy job if you don't finish reading this.

1.2 - What's a log?

A log is a file that has a bunch of words or phrases to scramble already in it, so that the host doesn't have to sit around typing in stuff all the time.  With a log, all you have to do it load it up and start it, and then sit back and watch.  I've included a bunch of logs with the program to get you started, but I encourage you to make your own logs as well (which I'll cover later).

1.3 - Running logs

Running a log is very easy.  Just click on the button that says "Load/Run", and a list of all the logs that you have available will pop up.  To pick one, either double click on it, or click on it and then click "Ok".  This will take you back to the main program screen.  Now, click on the "Load/Run Log" button again to start running the log.  All you really have to do after that is wait for the log to end.

1.4 - What topic?!

Most of you have probably seen tons of hosts do a scramble saying something like "Winner pix topic".  Please don't do this.  You'll end up having every person in the chatroom shouting some suggestion at you, and they're probably mostly bad suggestions.  Pick whatever topic you like.. trust me, they'll play it anyway.  In my opinion, the best topics are long sentences/lyrics, or vocab that's tough to descramble.  You can host whatever you like, though.  Just please try to avoid topics such as states, colors, and names.  These topics are EXTREMELY played out.. anybody who's played scrambler more than once has probably played each of these topics 100 times.  Basically, any topic that consists of very short words that you don't even have to think about to descramble is a bad topic.

1.5 - Scores

When you've finished a log, or have to leave, or you're going to stop the log for any other reason, MAKE SURE YOU SCROLL THE SCORES.  There is nothing more annoying than playing a game for a half hour, just to have the host suddenly leave without letting everyone know how they did.  Any time a game is over, you should always always always scroll the scores. If you don't know how to do this, it's simple.. just click the button that says "Scroll".

---------------------------------------------------------------------------------------------------------------------------------------------

Part 2 - ADVANCED hosting

2.1 - Good habits

Good hosts have several good habits, some of which I've already mentioned.  They always scroll the scores after a game is over.  They don't use the same logs over and over and over again.  They don't do a "winner pix topic" scramble.  They come up with interesting/creative logs.  They host often, not just once a month or less.  They mostly stick to 1 winner games (which you'll do anyway if you're using Vortex II).  That's all I can think of right now, but that's a great start.  If you do all of those things, then you're already in the top 1% of hosts today.

2.2 - Better logs

Better logs does not mean colors or states or the like.  It doesn't mean adding even more colors to your colors log.  When I say "better logs", what I'd like to see is more of the creative type of log that is pretty rare these days.  I think that the best logs have some sort of theme to them, that makes the log both fun and challenging at the same time.  While I like vocabulary logs, don't make a vocab log with words that nobody will be able to descramble, because then nobody will play the log.  Try to mix moderately tough words into sentences to keep players thinking.  The game is less fun when all you're doing is typing what you see, without needing to descramble a thing.

2.3 - Creating logs

I got an unbelievable amount of e-mails asking me how to make logs for the Vortex.  It was a little tough to explain if somebody wasn't too computer literate, so this time around I tried to make it alot easier.  I included a log maker in Vortex II; it's pretty easy to figure out and easy to use, but I'll explain it here anyway.  To open up the log maker, click the button that says "Create Log".  This will bring up a new window.  First type the topic into the box on the right that says topic.  Then put the filename in the box below that (the filename is what will show up when you click the "Load/Run" button).  The box on top is for putting words and phrases into the log.  Just type a word or phrase into that box and hit enter, and it should appear in the white space below.  Keep adding words until you're done.  If you messed up and want to remove a line, just double click on it.  When you're finished, click "Ok".

2.4 - Game options?

You might be wondering what those buttons on the right side of the program do.  What they do is change the game a little.  Here's a short explanation of what each button does:

Inclusion - hides the word box so that the host can play along during a log without cheating
Case Sens. - if the word is scrambled as "BluE", players must type "BluE" and not "blue"
Reverse - if the word is scrambled as "blue", players must type "eulb"
OOO - scrambles not only the words, but the order of the words
Chat Com - allows players to type ".hint" and ".re" for hints and rescrolls
Show WPM - toggles the display of players WPM

2.5 - Remote Hosting

If you have to go afk, and you think you might be away for a while, you can pick somebody to control the scrambler remotely. To do this, type ".designate SN" where SN is the person's screen name.  Once they are designated, they can execute several commands (the host can also use these commands).  Here is a list with a description of how they work:

.designate - designates a new remote host
.scroll - scrolls the scores
.reset - resets the scores
.skip - skips a phrase in a log
.rand - randomizes a log (can also use .random or .randomize)
.stop - pauses the scrambler (use when you want to change logs while one is running)
.load - will scroll a list of available logs
.find X - finds all logs containing X
.pick X - X should be a number. Use this after using .load or .find, and it will select the           number of the log that you choose

I will soon be adding a .ignore command, as well as commands to turn on and off all of the checkboxes.

---------------------------------------------------------------------------------------------------------------------------------------------

Part 3 - Other stuff?

3.1 - 1v1 game

If you click the 1v1 button, a box will pop up asking you to enter two screen names.  For now, you'll have to enter these names EXACTLY.. that means you would have to put "Kwizatz" in as "Kwizatz", not "kwizatz".  After you enter the names and hit ok, start a game up.  The difference is that in this game, only the two people whose screen names you entered will be able to answer.  This could be useful if you want to have a tournament type of game, or something of that sort.  The 1v1 game ends once you reset the scores.

3.2 - Time trial

This button will give you a box similar to that of the 1v1 button, only this time you only enter 1 screen name.  This is now the only player who can answer.  When you scroll the scores, it will give you some different information than the usual score scrolling does.  This could be used to test out different players on the same log, and compare how they did.  Again, this type of game will end once you reset the scores.

3.3 - Submit button?

Most people won't have to worry about this button, as only certain screen names can use it: those who I feel are the best hosts around today.  Basically what it does is sends the scores of a game to my web page.  I will set up a page that will display stats on these scores and keep track of how many points each player has, how many games they've won, etc.  I'm not sure how it'll work out, but hopefully it'll be pretty cool.  If you think you should be allowed to use it, let me know.  I may not enable you immediately, but if I see you consistently hosting good games, I will.

3.4 - Partners

"Partner mode" is something I came up with to add a little cooperation into scrambler.  Players type join to get into a game, and they are then assigned a partner.  For each scramble, BOTH PARTNERS must type the answer correctly to get a point.  I haven't completely finished this, so there may be some problems.  A partners game will continue until you reset the scores. Here is how to run a Partner game:
When you click on the Partners button, it will send a message to the chatroom saying something along the lines of "Type join to get into the partners game".  On the host's screen, a window will pop up that has two listboxes, an OK button, a random button, and a cancel button.  As people type join, their screen names will appear in the first listbox.  Once you think everyone has joined, you will need to choose the teams.  You can let the scrambler do this by hitting the random button, or you can do it yourself.  If you choose to do it yourself, this is how:
Double click on a name in the first listbox.  This will move it to the second listbox and place a - next to the screen name.  Now the next name you double click will move to the second listbox and be placed next to the first name, like so: ScreenName1-ScreenName2.  The dash indicates that these two people are partners.  If if you made a mistake, you can double click on any team in the second listbox to move them back to the first one.  When you're done, click OK and you are then ready to begin the partners game.

3.5 - Update?

I've added an update button to the "Specials" category.  When this button is clicked, the scrambler will automatically and quickly (a couple seconds) check to see if there is an updated version of the program available.  If there is, you'll get a message to visit my site for the download.

---------------------------------------------------------------------------------------------------------------------------------------------

Part 4 - Troubleshooting (aka "HELP IT DOESN'T WORK")

4.1 - The program won't open

There's several reasons this might happen.  The easiest to fix is if you get a message about a missing export to mfc42.dll .. if you get this error, all you need to do is go to my webpage, download my version of mfc42.dll, and place it in the same folder as the scrambler.  If this wasn't your message, then you're in trouble.  Are you using Windows 2000, Windows NT, or a Macintosh?  If you are, then I'm sorry, but the program won't work for you.  It's only good on Windows 95/98.  If you are using Windows 95/98 and it still won't work, then e-mail me with the error you're getting and I'll try to help you out.

4.2 - I got an illegal operation

That's probably my fault :( .. if you get an illegal operation, it's probably because of a bug in the program. If this happens to you, I'd appreciate it if you e-mail me, tell me that it happened, and tell me what you were doing at the time (running a log, doing a 1v1 game, whatever).  I'll try to fix it in future versions of the program.

4.3 - It won't send things to the chatroom

This MIGHT happen if you're using AOL 2.5, 3.0, or maybe 6.0.  I tested it a little on 2.5, and it seemed to work, but I can't be sure.  I don't have AOL 3.0 or 6.0, so I have no way of knowing yet if it works for those versions, although it should.  If you're having this problem, please e-mail me about it.

4.4 - I don't see any logs when I click load log

The program automatically looks for logs in a folder named "Logs".  This folder must be in the same folder as the scrambler program.  If that folder doesn't exist, you won't see any logs. Also, if you don't have any logs in that folder, you won't see any logs.  This shouldn't be a problem if you used the self extracting .exe to install the program, as it automatically creates a "Logs" folder and fills it with a bunch of logs.

4.5 - It crashes when I use logs I made with other programs/made myself in notepad

Certain other scramblers (Tera, possibly others) create logs in different ways that will either crash, or in some other way mess up Vortex II.  Try to avoid using logs that didn't come with Vortex II or that weren't made with the Vortex II log maker.  If you want to use logs you made yourself in notepad, make sure that there aren't any blank lines in them, as that may mess up the scrambler.  If none of this applies to you and it still messed up, please e-mail me a copy of the log so I can try to find out what went wrong.

---------------------------------------------------------------------------------------------------------------------------------------------

Part 5 - Special thanks

5.1 - Name

Thanks to Eric (PowerFlame) for giving me the idea of naming the original scrambler "The Vortex".  I decided to name this one "Vortex II" not only because I couldn't think of a new name, but because I liked the name and thought it was something people would recognize.

5.2 - Ascii

Thanks to Joel (Xkf) for this ascii.  For some reason, some people don't like it, but I think it looks pretty cool.

5.3 - Icon

Thanks to Damian (Iaissez faire) for designing the icon.  Although he refused to make one until I came up with a name for the program, he ended up doing a good job.

5.4 - Background

Well, I don't have a background yet, so I can't thank anyone.  If you think you can design a background image that would look good even while covered by all the buttons and such, please do so and send it to me.  Several people sent me images (No1ColFan, x 2 a o, Coooooolio), but I didn't use them for various reasons.  Even though I didn't use them, I'd like to thank those people for taking the time to design and send me those pictures.

5.5 - Suggestions

I'd like to thank Chris (Eat Tophu) for suggesting the Time Trial feature.  I can't remember who suggested the 1v1, but I think that might have also been Chris.  Thanks whoever suggested 1 winner only (probably lots of you), although I was going to do that anyway.  Thanks Fat SOB/Flaccid for the WPM idea. Yeah, I know they're not always accurate, but they're just supposed to be used to get a general idea of how you're doing, so quit complaining.  Thanks Rich for not getting too mad at me for stealing your Out of Order idea.  Thanks whoever came up with chat commands, they're pretty cool.  Thanks Steve for the ".hint x" command, that's genius.  Thanks Purely Unreal for informing me of a bug in the chat commands, and also for suggesting I add a cooperative sort of mode.  If i missed anyone.. thanks for your idea, and let me know that I missed you so I can put your name in here.

5.6 - Testing help

A couple people helped me out while I was testing this thing to make sure that it worked.  Coooooolio probably helped me the most by making me laugh when I messed something up, thus keeping me from getting too frustrated.  Thanks Neil (Lien007) for telling everybody that my first scramble would always be test, creating lots of pretyping.  Thanks to anyone who came to a different room when I asked them to in order to help me out.

5.7 - Support

Lots of people encouraged me to make this, and kept me optimistic as I did.  Damian gave me the initial motivation ("VORTEX SUCKS NOW, MAKE A NEW ONE"), thanks for that Damian.  Anyone who gave me a positive comment helped me out; criticisms helped as well.  Here's a list of people who I'd just like to thank for their comments and such.  They're in no particular order, and if I forgot you, I'm sorry.

Dawt Hint
Sos411
Nahtanoj I
Weird0h4me
JerJerGuy
PowerFlame
Kraft Dinner
ShempXVIII
Eat Tophu
DrkBluBenz
XiIllllliX
CL22
Lien007
Neonspark
QuickieKoala
Zfv
Hestah
CSmiles
CanIFriskU
XKarIAmX
The Golem
Jomama37
Twilite979
Xkf
GrEEnSpEEd
DjStoopid
IVlerciful
HeatFan50
RyalFlush1
XR0cKhRsTX
Mike143708
HetrLvShwn
ArgNarf41
IiLoliPoP
SYanksFanS
VixiShirowixiV

---------------------------------------------------------------------------------------------------------------------------------------------

Part 6 - Future features / bug fixes

6.1 - Feature suggestions

If you have any suggestions for a new feature, e-mail me about it.. I'm always happy to listen to ideas about cool new features.  If I like your idea, I'll put it in and give you credit for it.

6.2 - I found a bug! What do I do?

If you think you found a bug, please read the trouble shooting section of this file if you haven't already, and make sure I don't cover it there.  If it's not there, then please e-mail me about, telling me what exactly the bug is, and what you were doing when you noticed it.