staff toolz 1.0 by bliss
-------------------------
programmed by bliss.
e-mail bliss at iolbliss@hotmail.com.
