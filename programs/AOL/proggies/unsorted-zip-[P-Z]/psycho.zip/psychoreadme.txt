		     Psycho Read Me
                     --------------

Note: You must have AOL 4.0 to use this program, some 
features will not work under another version!

Well, it's finally here...psycho realm �.  It took me
like 2 months to finish, a lot of work for me, heh.
I hope you guys like! 
				-lipid

Chat Features:

-9 advertises'
-2 chat eats
-4 macro kills
-2 chat lags
-chat scrollers
-5 bots
-sound hell like a bitch d:D
-room scare
-fake prog maker
-screen name disser
-chat attention
-ghost lettering (what you say appears blank in chat)
-chat ignorer
-chat linker
-aol caption changer
-chat caption changer
-room name changer (says ***You are in "Blah".***)

Mail Features:

-write mail
-mail bomb fix
-count old mail
-open new,old,sent,flash

IM Features:

-im on/off
-im ignorer

Other:

-ghost/unghost
-html editor
-sn decoder (decodes fag names using upper case I's and 
lower case L's)
-hide welcome
-screen saver

Extra Features:

-cool advertise
-kill wait
-kill modal
-sign off
-hide/unhide aol
-clear chat
-buddy view - for those who are lazy to click on the
buddy windows when the chat covers it, this baby opens
it to your view.
-web site - takes you to my site
-room counter

Well that's just about all the features that I included, 
not a lot but these fucking features are useful and 
friendly to the user d:D.  I didn't spend my time on 
stupid shit that peeps are not going to use.  Well
I guess that's all for psycho �, look for psycho � later
this year, latez!

					-lipid
Visit my site at: http://www.lipidonline.cjb.net

		   [Projects to come]

biohazard� - this baby is going to be c-coms, since 
peeps like c-coms better, heh.  I'll have this one out 
pretty soon.

elf � - this one is the next project on my list.  It's 
going to be a c-com chat tool software, this one will 
not last that long to make, heh.

Enjoy Psycho realm �...latez!