read me:

i know this has a few bugs in it BUT deal with it!!@$@%
the only error ive hd recently was some runtime error 
when i was unloading it, and it open happens every now
and then so dont worry about it.  if your aims stop
connecting then reload the program and it should work fine.
AND (most important of all so i dont get bitched out) this
has a 1:15 ratio... that way i get something out of making it.
i didnt add the ratio to be greedy to help me get money faster
so that i can buy a new power supply for my comp since this one
is going bad again.  anyway in the future versions ill add a 
winsock stat check thing where i get an icq notify of your stats
and if you spam a lot ill remove the ratio for you.  the only reason
i didnt add this now is cause i need the money.  but in the new version
i probably wont have a ratio anyways ;P.  anyway i hope you like this
cause most aim spammers wont work for me or they do something gay to 
my aol.  if you got any problems then email me what your problem is.
btw this uses ten aims ;x.

~keith

email: iadyman@aol.com and poopkeith@aol.com