TOS'D BETA 1 (COSMIC VERSION) for aol 5.0
originally by RadiaL (1997)
Revised 2001, by coz

this is beta, not everthing works yet...
works best if you have mail prefs set to
close mail after sending ;)